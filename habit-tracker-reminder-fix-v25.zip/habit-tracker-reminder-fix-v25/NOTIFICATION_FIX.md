# Habit reminder scheduling fix

This update addresses reminders being scheduled for the first habit but not reliably for habits created afterward.

## Changes

- Serializes background reminder synchronization requests so an older, slower sync cannot overwrite a newer habit list.
- Copies habit/day selections for each queued synchronization request.
- Builds the upcoming alarm list across habits and selects alarms by nearest scheduled time, rather than letting early habits consume the alarm limit first.
- Serializes native Android schedule/cancel/restore operations.
- Handles invalid stored alarm entries individually so one bad entry does not prevent later reminders from being scheduled.
- Applies the serialized-sync fix to the bundled WebView JavaScript used by Gradle builds, as well as the TypeScript source.

## Build

Open the `android` folder in Android Studio, let Gradle sync, then use **Build > Build Bundle(s) / APK(s) > Build APK(s)**.

For future UI or TypeScript changes, from the project root run `npm ci` and `npm run build:android` before building the APK in Android Studio. This regenerates the Android bundled web assets from `src/`.

The source and bundled JavaScript syntax checks passed in the preparation environment. A full Gradle/APK build could not be run there because Gradle and npm dependencies could not be downloaded due to unavailable network/DNS access.
