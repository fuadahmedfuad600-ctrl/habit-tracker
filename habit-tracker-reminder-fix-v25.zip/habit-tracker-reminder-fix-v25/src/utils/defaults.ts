import { AppSettings } from '../types';

export const DEFAULT_SETTINGS: AppSettings = {
  theme: 'light',
  notificationsEnabled: true,
  vibrationEnabled: true,
  language: 'en',
  weekStart: 'monday',
  onboardingCompleted: false,
};

export const HABIT_CATEGORIES = [
  'Health',
  'Fitness',
  'Study',
  'Work',
  'Personal',
  'Other',
] as const;

export const CATEGORY_COLORS: Record<string, { bg: string; text: string; border: string }> = {
  Health: { bg: 'bg-emerald-50 dark:bg-emerald-950/40', text: 'text-emerald-700 dark:text-emerald-400', border: 'border-emerald-200 dark:border-emerald-800' },
  Fitness: { bg: 'bg-orange-50 dark:bg-orange-950/40', text: 'text-orange-700 dark:text-orange-400', border: 'border-orange-200 dark:border-orange-800' },
  Study: { bg: 'bg-blue-50 dark:bg-blue-950/40', text: 'text-blue-700 dark:text-blue-400', border: 'border-blue-200 dark:border-blue-800' },
  Work: { bg: 'bg-indigo-50 dark:bg-indigo-950/40', text: 'text-indigo-700 dark:text-indigo-400', border: 'border-indigo-200 dark:border-indigo-800' },
  Personal: { bg: 'bg-purple-50 dark:bg-purple-950/40', text: 'text-purple-700 dark:text-purple-400', border: 'border-purple-200 dark:border-purple-800' },
  Other: { bg: 'bg-slate-100 dark:bg-slate-800/60', text: 'text-slate-700 dark:text-slate-300', border: 'border-slate-200 dark:border-slate-700' },
};

export const COLOR_OPTIONS = [
  // Saturated, high-contrast colours for the colourful habit-card design.
  { id: 'red', label: 'Red', hex: '#dc2626', ring: 'ring-red-500', bg: 'bg-red-600', lightBg: 'bg-red-50 dark:bg-red-950/50', text: 'text-red-700 dark:text-red-300', darkText: false },
  { id: 'rose', label: 'Pink', hex: '#e11d48', ring: 'ring-rose-500', bg: 'bg-rose-600', lightBg: 'bg-rose-50 dark:bg-rose-950/50', text: 'text-rose-700 dark:text-rose-300', darkText: false },
  { id: 'orange', label: 'Orange', hex: '#c2410c', ring: 'ring-orange-500', bg: 'bg-orange-700', lightBg: 'bg-orange-50 dark:bg-orange-950/50', text: 'text-orange-700 dark:text-orange-300', darkText: false },
  { id: 'yellow', label: 'Yellow', hex: '#facc15', ring: 'ring-yellow-500', bg: 'bg-yellow-400', lightBg: 'bg-yellow-50 dark:bg-yellow-950/50', text: 'text-yellow-800 dark:text-yellow-300', darkText: true },
  { id: 'amber', label: 'Gold', hex: '#b45309', ring: 'ring-amber-500', bg: 'bg-amber-700', lightBg: 'bg-amber-50 dark:bg-amber-950/50', text: 'text-amber-700 dark:text-amber-300', darkText: false },
  { id: 'emerald', label: 'Emerald', hex: '#047857', ring: 'ring-emerald-500', bg: 'bg-emerald-700', lightBg: 'bg-emerald-50 dark:bg-emerald-950/50', text: 'text-emerald-700 dark:text-emerald-300', darkText: false },
  { id: 'green', label: 'Green', hex: '#15803d', ring: 'ring-green-500', bg: 'bg-green-700', lightBg: 'bg-green-50 dark:bg-green-950/50', text: 'text-green-700 dark:text-green-300', darkText: false },
  { id: 'teal', label: 'Teal', hex: '#0f766e', ring: 'ring-teal-500', bg: 'bg-teal-700', lightBg: 'bg-teal-50 dark:bg-teal-950/50', text: 'text-teal-700 dark:text-teal-300', darkText: false },
  { id: 'cyan', label: 'Sky', hex: '#0369a1', ring: 'ring-sky-500', bg: 'bg-sky-700', lightBg: 'bg-sky-50 dark:bg-sky-950/50', text: 'text-sky-700 dark:text-sky-300', darkText: false },
  { id: 'blue', label: 'Blue', hex: '#1d4ed8', ring: 'ring-blue-500', bg: 'bg-blue-700', lightBg: 'bg-blue-50 dark:bg-blue-950/50', text: 'text-blue-700 dark:text-blue-300', darkText: false },
  { id: 'indigo', label: 'Indigo', hex: '#4338ca', ring: 'ring-indigo-500', bg: 'bg-indigo-700', lightBg: 'bg-indigo-50 dark:bg-indigo-950/50', text: 'text-indigo-700 dark:text-indigo-300', darkText: false },
  { id: 'violet', label: 'Violet', hex: '#6d28d9', ring: 'ring-violet-500', bg: 'bg-violet-700', lightBg: 'bg-violet-50 dark:bg-violet-950/50', text: 'text-violet-700 dark:text-violet-300', darkText: false },
] as const;

export interface IconOption {
  id: string;
  label: string;
  category: 'Health' | 'Fitness' | 'Mind' | 'Study' | 'Work' | 'Finance' | 'Home' | 'Lifestyle';
}

export const ICON_OPTIONS: IconOption[] = [
  // Health, Hydration & Wellness
  { id: 'droplet', label: 'Drink Water', category: 'Health' },
  { id: 'glass-water', label: 'Glass of Water', category: 'Health' },
  { id: 'heart', label: 'Heart Health', category: 'Health' },
  { id: 'heart-pulse', label: 'Cardio Pulse', category: 'Health' },
  { id: 'pill', label: 'Vitamins / Meds', category: 'Health' },
  { id: 'stethoscope', label: 'Health Check', category: 'Health' },
  { id: 'bath', label: 'Hygiene / Bath', category: 'Health' },
  { id: 'shower-head', label: 'Cold / Hot Shower', category: 'Health' },
  { id: 'moon', label: 'Sleep 8 Hours', category: 'Health' },
  { id: 'bed', label: 'Early Bedtime', category: 'Health' },
  { id: 'sun', label: 'Morning Sunlight', category: 'Health' },
  { id: 'sunrise', label: 'Wake Up Early', category: 'Health' },
  { id: 'sunset', label: 'Evening Routine', category: 'Health' },
  { id: 'scale', label: 'Weigh In', category: 'Health' },
  { id: 'cigarette-off', label: 'No Smoking', category: 'Health' },
  { id: 'wine-off', label: 'No Alcohol / Sober', category: 'Health' },
  { id: 'apple', label: 'Healthy Eating', category: 'Health' },
  { id: 'salad', label: 'Salad & Greens', category: 'Health' },
  { id: 'carrot', label: 'Vegetables', category: 'Health' },
  { id: 'utensils', label: 'Mindful Meals', category: 'Health' },
  { id: 'utensils-crossed', label: 'Home Cooking', category: 'Health' },

  // Fitness & Sports
  { id: 'dumbbell', label: 'Workout / Gym', category: 'Fitness' },
  { id: 'footprints', label: '10k Steps / Walk', category: 'Fitness' },
  { id: 'bike', label: 'Cycling', category: 'Fitness' },
  { id: 'timer', label: 'Plank / HIIT', category: 'Fitness' },
  { id: 'activity', label: 'Active Cardio', category: 'Fitness' },
  { id: 'trophy', label: 'Sports & Competition', category: 'Fitness' },
  { id: 'medal', label: 'Personal Best', category: 'Fitness' },
  { id: 'mountain', label: 'Hiking / Outdoors', category: 'Fitness' },
  { id: 'compass', label: 'Trail Running', category: 'Fitness' },
  { id: 'flame', label: 'Burn Calories', category: 'Fitness' },
  { id: 'zap', label: 'Morning Stretch', category: 'Fitness' },

  // Mind, Spirit & Wellbeing
  { id: 'brain', label: 'Meditation', category: 'Mind' },
  { id: 'feather', label: 'Calm & Peace', category: 'Mind' },
  { id: 'smile', label: 'Gratitude Journal', category: 'Mind' },
  { id: 'wind', label: 'Deep Breathing', category: 'Mind' },
  { id: 'eye', label: 'Screen Rest (20-20-20)', category: 'Mind' },
  { id: 'ear', label: 'Deep Listening', category: 'Mind' },
  { id: 'battery-charging', label: 'Recharge / Rest', category: 'Mind' },
  { id: 'cloud-sun', label: 'Mindful Morning', category: 'Mind' },
  { id: 'sparkles', label: 'Skincare / Self-Care', category: 'Mind' },
  { id: 'shield', label: 'Discipline', category: 'Mind' },
  { id: 'shield-check', label: 'Streak Guard', category: 'Mind' },

  // Learning, Books & Creativity
  { id: 'book-open', label: 'Read 20+ Pages', category: 'Study' },
  { id: 'book', label: 'Daily Chapter', category: 'Study' },
  { id: 'bookmark', label: 'Bookmark Progress', category: 'Study' },
  { id: 'graduation-cap', label: 'Course & Lecture', category: 'Study' },
  { id: 'languages', label: 'Language / Vocab', category: 'Study' },
  { id: 'pen-tool', label: 'Journaling', category: 'Study' },
  { id: 'pencil', label: 'Note Taking', category: 'Study' },
  { id: 'file-text', label: 'Write Daily Essay', category: 'Study' },
  { id: 'newspaper', label: 'Daily News / Article', category: 'Study' },
  { id: 'mic', label: 'Speaking / Podcast', category: 'Study' },
  { id: 'library', label: 'Deep Study', category: 'Study' },
  { id: 'brain-circuit', label: 'Logic & Critical Thinking', category: 'Study' },
  { id: 'puzzle', label: 'Brain Puzzle', category: 'Study' },
  { id: 'lightbulb', label: 'Creative Ideas', category: 'Study' },

  // Work, Productivity & Discipline
  { id: 'briefcase', label: 'Deep Work Block', category: 'Work' },
  { id: 'laptop', label: 'Focus Work', category: 'Work' },
  { id: 'code', label: 'Daily Coding Commit', category: 'Work' },
  { id: 'terminal', label: 'Dev Practice', category: 'Work' },
  { id: 'check-square', label: 'Daily Task List', category: 'Work' },
  { id: 'list-todo', label: 'Priorities First', category: 'Work' },
  { id: 'target', label: 'Hit Key Goal', category: 'Work' },
  { id: 'clock', label: 'Pomodoro Sessions', category: 'Work' },
  { id: 'calendar', label: 'Plan Tomorrow', category: 'Work' },
  { id: 'inbox', label: 'Inbox Zero', category: 'Work' },
  { id: 'send', label: 'Clear Emails', category: 'Work' },
  { id: 'phone-off', label: 'Digital Detox', category: 'Work' },
  { id: 'bell-off', label: 'No Distractions', category: 'Work' },
  { id: 'focus', label: 'Hyper Focus Mode', category: 'Work' },
  { id: 'rocket', label: 'Side Project Progress', category: 'Work' },
  { id: 'coffee', label: 'Coffee / Tea Break', category: 'Work' },

  // Finance & Money
  { id: 'dollar-sign', label: 'Track Daily Budget', category: 'Finance' },
  { id: 'piggy-bank', label: 'Daily Savings', category: 'Finance' },
  { id: 'wallet', label: 'Log Expenses', category: 'Finance' },
  { id: 'credit-card', label: 'Zero Impulse Spending', category: 'Finance' },
  { id: 'trending-up', label: 'Invest / Stocks', category: 'Finance' },
  { id: 'receipt', label: 'Review Receipts', category: 'Finance' },
  { id: 'coins', label: 'Spare Change Save', category: 'Finance' },

  // Home, Pets & Lifestyle
  { id: 'home', label: 'Clean & Tidy Room', category: 'Home' },
  { id: 'leaf', label: 'Water Houseplants', category: 'Home' },
  { id: 'trees', label: 'Garden & Outdoors', category: 'Home' },
  { id: 'shirt', label: 'Laundry & Organization', category: 'Home' },
  { id: 'hammer', label: 'Fix / Home Maintenance', category: 'Home' },
  { id: 'wrench', label: 'DIY Project', category: 'Home' },
  { id: 'dog', label: 'Walk Dog / Pet Care', category: 'Lifestyle' },
  { id: 'cat', label: 'Cat Care', category: 'Lifestyle' },
  { id: 'users', label: 'Quality Family Time', category: 'Lifestyle' },
  { id: 'message-circle', label: 'Call Parents / Friends', category: 'Lifestyle' },
  { id: 'gift', label: 'Daily Act of Kindness', category: 'Lifestyle' },
  { id: 'car', label: 'Drive Safely', category: 'Lifestyle' },
  { id: 'music', label: 'Play Instrument', category: 'Lifestyle' },
  { id: 'headphones', label: 'Listen to Audiobooks', category: 'Lifestyle' },
  { id: 'palette', label: 'Drawing / Painting', category: 'Lifestyle' },
  { id: 'camera', label: 'Take a Photo', category: 'Lifestyle' },
];
