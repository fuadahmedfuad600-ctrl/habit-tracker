import { WeekStartDay } from '../types';
import type { Language } from '../types';
import { getLocale } from './i18n';

export function formatDateKey(date: Date): string {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const day = String(date.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

export function parseDateKey(dateStr: string): Date {
  const [year, month, day] = dateStr.split('-').map(Number);
  return new Date(year, month - 1, day);
}

export function getTodayKey(): string {
  return formatDateKey(new Date());
}

export function getGreeting(language: Language = 'en'): string {
  const hour = new Date().getHours();
  if (hour >= 5 && hour < 12) {
    return language === 'bn' ? 'শুভ সকাল 👋' : language === 'hi' ? 'सुप्रभात 👋' : 'Good Morning 👋';
  } else if (hour >= 12 && hour < 17) {
    return language === 'bn' ? 'শুভ অপরাহ্ণ ☀️' : language === 'hi' ? 'शुभ दोपहर ☀️' : 'Good Afternoon ☀️';
  } else {
    return language === 'bn' ? 'শুভ সন্ধ্যা 🌙' : language === 'hi' ? 'शुभ संध्या 🌙' : 'Good Evening 🌙';
  }
}

export function formatDisplayDate(date: Date, language: Language = 'en'): string {
  return date.toLocaleDateString(getLocale(language), {
    weekday: 'long',
    month: 'long',
    day: 'numeric',
  });
}

export function formatShortDate(date: Date, language: Language = 'en'): string {
  return date.toLocaleDateString(getLocale(language), {
    weekday: 'short',
    month: 'short',
    day: 'numeric',
  });
}

export function formatMonthYear(date: Date, language: Language = 'en'): string {
  return date.toLocaleDateString(getLocale(language), {
    month: 'long',
    year: 'numeric',
  });
}

export function formatTime12h(time24: string, language: Language = 'en'): string {
  if (!time24) return '';
  const [hoursStr, minsStr] = time24.split(':');
  const hours = Number.parseInt(hoursStr, 10);
  const minutes = Number.parseInt(minsStr || '00', 10);
  if (Number.isNaN(hours) || Number.isNaN(minutes)) return time24;
  const d = new Date(2000, 0, 1, hours, minutes);
  return d.toLocaleTimeString(getLocale(language), { hour: 'numeric', minute: '2-digit' });
}

export function getWeekStartOffset(weekStart: WeekStartDay): number {
  switch (weekStart) {
    case 'saturday':
      return 6;
    case 'sunday':
      return 0;
    case 'monday':
    default:
      return 1;
  }
}

export function getWeekDays(referenceDate: Date, weekStart: WeekStartDay): Date[] {
  const dayOfWeek = referenceDate.getDay(); // 0 is Sunday
  const startOffset = getWeekStartOffset(weekStart);
  
  // Calculate difference to start of week
  let diff = dayOfWeek - startOffset;
  if (diff < 0) {
    diff += 7;
  }

  const startDate = new Date(referenceDate);
  startDate.setDate(referenceDate.getDate() - diff);
  startDate.setHours(0, 0, 0, 0);

  const days: Date[] = [];
  for (let i = 0; i < 7; i++) {
    const d = new Date(startDate);
    d.setDate(startDate.getDate() + i);
    days.push(d);
  }
  return days;
}

export function getMonthDaysGrid(year: number, month: number, weekStart: WeekStartDay): { date: Date; isCurrentMonth: boolean }[] {
  const firstDayOfMonth = new Date(year, month, 1);
  const lastDayOfMonth = new Date(year, month + 1, 0);
  
  const startOffset = getWeekStartOffset(weekStart);
  let leadingDays = firstDayOfMonth.getDay() - startOffset;
  if (leadingDays < 0) leadingDays += 7;

  const result: { date: Date; isCurrentMonth: boolean }[] = [];

  // Previous month trailing days
  for (let i = leadingDays; i > 0; i--) {
    const prevDate = new Date(year, month, 1 - i);
    result.push({ date: prevDate, isCurrentMonth: false });
  }

  // Current month days
  for (let d = 1; d <= lastDayOfMonth.getDate(); d++) {
    result.push({ date: new Date(year, month, d), isCurrentMonth: true });
  }

  // Next month leading days to complete full weeks
  const totalCells = Math.ceil(result.length / 7) * 7;
  const trailingDays = totalCells - result.length;
  for (let i = 1; i <= trailingDays; i++) {
    result.push({ date: new Date(year, month + 1, i), isCurrentMonth: false });
  }

  return result;
}

export function getDayNames(weekStart: WeekStartDay, short: boolean = true, language: Language = 'en'): string[] {
  const source = Array.from({ length: 7 }, (_, i) => {
    const d = new Date(2024, 0, 7 + i);
    return d.toLocaleDateString(getLocale(language), { weekday: short ? 'short' : 'long' });
  });
  
  const offset = getWeekStartOffset(weekStart);
  return [...source.slice(offset), ...source.slice(0, offset)];
}
