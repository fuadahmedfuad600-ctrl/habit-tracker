import { Capacitor, registerPlugin } from '@capacitor/core';
import { LocalNotifications } from '@capacitor/local-notifications';
import { Habit, HabitCompletion, InAppNotification } from '../types';
import type { Language } from '../types';
import { getTodayKey } from './date';
import { translate } from './i18n';

/**
 * One repeating reminder per habit. The habit's time and days are stored on the
 * Android side, which schedules the next occurrence after every reminder that
 * fires. That keeps a single pending alarm per habit instead of dozens, so one
 * habit can never push another habit's reminder out of the alarm budget.
 */
interface ReminderRule {
  id: number;
  habitId: string;
  title: string;
  body: string;
  hour: number;
  minute: number;
  daily: boolean;
  days: number[];
}

interface ReminderSettingsPlugin {
  isBatteryOptimizationIgnored(): Promise<{ ignored: boolean }>;
  requestIgnoreBatteryOptimization(): Promise<void>;
  openAppSettings(): Promise<void>;
  scheduleReminders(options: { reminders: ReminderRule[] }): Promise<NativeScheduleResult>;
  getScheduleDebug(): Promise<NativeScheduleResult>;
  getFiredReminders(): Promise<{ reminders: Array<{ id: number; habitId: string; title: string; body: string; timestamp: number }> }>;
  cancelReminders(): Promise<void>;
  setVibrationEnabled(options: { enabled: boolean }): Promise<void>;
}

interface NativeScheduleResult {
  scheduled?: number;
  alarms?: Array<{ habitId: string; alarmId: number; atLocal?: string; nextAtLocal?: string; alarmArmed?: boolean }>;
  notificationsAllowed?: boolean;
  exactAlarmAllowed?: boolean;
}

const ReminderSettings = registerPlugin<ReminderSettingsPlugin>('ReminderSettings');

let vibrationPreference = true;

/** Turns vibration on/off for habit reminders (Android notifications and web notifications). */
export async function setVibrationPreference(enabled: boolean): Promise<void> {
  vibrationPreference = enabled;
  if (!isNativeAndroid()) return;
  try {
    await ReminderSettings.setVibrationEnabled({ enabled });
  } catch (e) {
    console.warn('Could not update vibration setting:', e);
  }
}

export function isNativeAndroid(): boolean {
  return typeof window !== 'undefined' && Capacitor.getPlatform() === 'android';
}

export async function getNativeReminderHistory(): Promise<Array<{ id: number; habitId: string; title: string; body: string; timestamp: number }>> {
  if (!isNativeAndroid()) return [];
  try {
    const result = await ReminderSettings.getFiredReminders();
    return Array.isArray(result.reminders) ? result.reminders : [];
  } catch (error) {
    console.warn('Could not read native reminder history:', error);
    return [];
  }
}

function hashStringToId(str: string): number {
  let hash = 0;
  for (let i = 0; i < str.length; i++) {
    hash = (hash << 5) - hash + str.charCodeAt(i);
    hash |= 0;
  }
  return Math.abs(hash) % 2147483647 || 1;
}

/** Keep every reminder ID unique within one sync batch; Android identifies alarms by PendingIntent ID. */
function uniqueReminderId(seed: string, usedIds: Set<number>): number {
  let id = hashStringToId(seed) || 1;
  while (usedIds.has(id)) {
    id = id >= 2147483646 ? 1 : id + 1;
  }
  usedIds.add(id);
  return id;
}

let channelInitialized = false;

export async function ensureNotificationChannel(): Promise<void> {
  if (!isNativeAndroid() || channelInitialized) return;
  try {
    await LocalNotifications.createChannel({
      id: 'habit_reminders',
      name: 'Habit Reminders',
      description: 'Scheduled alerts for your daily habits',
      importance: 5,
      visibility: 1,
      sound: 'notification.wav',
      vibration: true,
      lights: true,
      lightColor: '#2878f0',
    });
    channelInitialized = true;
  } catch (err) {
    console.warn('Failed to initialize Android notification channel:', err);
  }
}

export async function requestNotificationPermission(): Promise<NotificationPermission> {
  if (isNativeAndroid()) {
    try {
      await ensureNotificationChannel();
      const status = await LocalNotifications.requestPermissions();
      return status.display === 'granted' ? 'granted' : 'denied';
    } catch (e) {
      console.warn('Native permission request failed:', e);
      return 'denied';
    }
  }

  if (typeof window === 'undefined' || !('Notification' in window)) {
    return 'denied';
  }
  try {
    if ('serviceWorker' in navigator) {
      try {
        await navigator.serviceWorker.register('/sw.js');
      } catch (err) {
        console.warn('SW registration attempt during permission request:', err);
      }
    }

    return await Notification.requestPermission();
  } catch (e) {
    console.warn('Error requesting notification permission:', e);
    return 'denied';
  }
}

export function getNotificationPermission(): NotificationPermission {
  if (typeof window === 'undefined' || !('Notification' in window)) {
    return 'denied';
  }
  return Notification.permission;
}

/**
 * Serialize alarm synchronization requests. Habit changes and app foreground
 * events can trigger this function in quick succession; without a queue an
 * older, slower sync could finish last and replace the latest habit list.
 */
let backgroundAlarmSyncQueue: Promise<void> = Promise.resolve();

/**
 * Synchronize native Android system alarms so reminders fire at the scheduled
 * time of every single habit, even while the app is in the background or
 * completely closed.
 */
export function syncBackgroundHabitAlarms(
  habits: Habit[],
  notificationsEnabled: boolean,
  language: Language = 'en'
): Promise<void> {
  if (!isNativeAndroid()) return Promise.resolve();

  // Keep an immutable snapshot for this queued request. React may update the
  // habit collection while an earlier native permission/scheduling call waits.
  const habitsSnapshot = habits.map((habit) => ({
    ...habit,
    selectedDays: Array.isArray(habit.selectedDays) ? [...habit.selectedDays] : [],
  }));

  backgroundAlarmSyncQueue = backgroundAlarmSyncQueue
    .catch((err) => {
      console.warn('Previous background alarm sync failed:', err);
    })
    .then(() => syncBackgroundHabitAlarmsNow(habitsSnapshot, notificationsEnabled, language))
    .catch((err) => {
      console.warn('Error syncing background habit alarms:', err);
    });

  return backgroundAlarmSyncQueue;
}

async function syncBackgroundHabitAlarmsNow(
  habits: Habit[],
  notificationsEnabled: boolean,
  language: Language
): Promise<void> {
  // Every step before the final scheduleReminders() call is best-effort. Previously one
  // failing step (permission prompt, battery prompt, clearing old plugin alarms) made the
  // whole sync return early, so a newly added habit was never armed while the older
  // habit's alarm kept firing. Alarms are now always (re)armed, whatever happens above.
  try {
    await ensureNotificationChannel();
  } catch (err) {
    console.warn('[HabitReminder] channel setup failed:', err);
  }

  try {
    let permission = await LocalNotifications.checkPermissions();
    if (permission.display !== 'granted') {
      permission = await LocalNotifications.requestPermissions();
    }
    if (permission.display !== 'granted') {
      console.warn(
        '[HabitReminder] Android notifications are NOT allowed. Alarms are still scheduled, but nothing will be shown until notifications are enabled for this app.'
      );
      // Send the user to the system settings once instead of failing without a sign.
      try {
        if (localStorage.getItem('notificationSettingsPromptShown') !== '1') {
          localStorage.setItem('notificationSettingsPromptShown', '1');
          await ReminderSettings.openAppSettings();
        }
      } catch (e) {
        console.warn('[HabitReminder] Could not open the Android notification settings:', e);
      }
    }
  } catch (err) {
    console.warn('[HabitReminder] notification permission check failed:', err);
  }

  // Ask once to be exempt from battery optimisation so reminders fire while the app is closed.
  try {
    if (notificationsEnabled && localStorage.getItem('batteryPromptShown') !== '1') {
      const { ignored } = await ReminderSettings.isBatteryOptimizationIgnored();
      localStorage.setItem('batteryPromptShown', '1');
      if (!ignored) await ReminderSettings.requestIgnoreBatteryOptimization();
    }
  } catch (e) {
    console.warn('[HabitReminder] Battery optimisation check failed:', e);
  }

  // Remove reminders created by older versions of the app (plugin-based alarms).
  try {
    const pending = await LocalNotifications.getPending();
    if (pending.notifications.length > 0) {
      await LocalNotifications.cancel({ notifications: pending.notifications });
    }
  } catch (e) {
    console.warn('[HabitReminder] Could not clear old plugin alarms:', e);
  }

  try {
    if (!notificationsEnabled) {
      await ReminderSettings.cancelReminders();
      console.log('[HabitReminder] reminders are switched off: all habit alarms cancelled');
      return;
    }

    // One rule per habit: the habit's own time (and its selected days) is stored
    // natively, which then keeps rescheduling that habit's next reminder.
    const rules: ReminderRule[] = [];
    const usedReminderIds = new Set<number>();

    for (const habit of habits) {
      if (habit.isArchived || !habit.reminderEnabled || !habit.reminderTime) continue;

      const [hoursStr, minutesStr] = habit.reminderTime.trim().split(':');
      const hour = Number.parseInt(hoursStr, 10);
      const minute = Number.parseInt(minutesStr, 10);
      if (Number.isNaN(hour) || Number.isNaN(minute) || hour < 0 || hour > 23 || minute < 0 || minute > 59) {
        console.warn(`[HabitReminder] skipped habitId=${habit.id}: invalid reminder time "${habit.reminderTime}"`);
        continue;
      }

      const daily = habit.frequency === 'daily';
      const allDays: number[] = Array.isArray(habit.selectedDays) ? habit.selectedDays : [];
      const days: number[] = daily
        ? []
        : Array.from(new Set(allDays)).filter((day) => day >= 0 && day <= 6).sort((a, b) => a - b);
      if (!daily && days.length === 0) {
        console.warn(`[HabitReminder] skipped habitId=${habit.id}: no active days selected`);
        continue;
      }

      rules.push({
        id: uniqueReminderId(`habit-${habit.id}`, usedReminderIds),
        habitId: habit.id,
        title: translate(language, 'notification.habitTitle', { name: habit.name }),
        body: translate(language, 'notification.habitBody', { name: habit.name }),
        hour,
        minute,
        daily,
        days,
      });
    }

    console.log(
      `[HabitReminder] syncing ${rules.length} rule(s): ` +
        rules.map((r) => `${r.habitId}@${String(r.hour).padStart(2, '0')}:${String(r.minute).padStart(2, '0')}`).join(', ')
    );
    const result = await ReminderSettings.scheduleReminders({ reminders: rules });
    console.log(
      `[HabitReminder] native armed ${result?.scheduled ?? '?'} alarm(s); ` +
        `notificationsAllowed=${result?.notificationsAllowed} exactAlarmAllowed=${result?.exactAlarmAllowed}`
    );
    (result?.alarms ?? []).forEach((a) =>
      console.log(`[HabitReminder]   habitId=${a.habitId} alarmId=${a.alarmId} next=${a.atLocal}`)
    );
  } catch (err) {
    console.warn('[HabitReminder] Error scheduling habit alarms:', err);
  }
}

export function sendHabitNotification({
  title,
  message,
  habit,
  language = 'en',
}: {
  title: string;
  message: string;
  habit?: Habit;
  language?: Language;
}): InAppNotification {
  const timestamp = Date.now();

  if (isNativeAndroid()) {
    ensureNotificationChannel().then(() => {
      LocalNotifications.schedule({
        notifications: [
          {
            id: Math.floor(Math.random() * 1000000) + 1,
            title,
            body: message,
            channelId: 'habit_reminders',
            sound: 'notification.wav',
            isExactNotification: true,
            isExactMandatory: false,
            smallIcon: 'ic_stat_habit',
            iconColor: '#2878f0',
            // Keep system notification visible even when the web view is open.
            foreground: true,
            autoCancel: true,
            schedule: { at: new Date(timestamp + 100) },
            extra: { habitId: habit?.id, triggeredAt: new Date(timestamp).toISOString() },
          },
        ],
      }).catch((e) => console.warn('Native notification schedule error:', e));
    });
  } else if (typeof window !== 'undefined' && 'Notification' in window && Notification.permission === 'granted') {
    const notifOptions: NotificationOptions & { vibrate?: number[]; badge?: string; renotify?: boolean } = {
      body: message,
      icon: '/icon.svg',
      badge: '/icon.svg',
      tag: habit ? `habit-${habit.id}` : 'general-reminder',
      vibrate: vibrationPreference ? [200, 100, 200] : [],
      renotify: true,
      data: {
        habitId: habit?.id,
        timestamp,
        language,
      },
    };

    if ('serviceWorker' in navigator) {
      navigator.serviceWorker.ready
        .then((reg) => reg.showNotification(title, notifOptions))
        .catch(() => {
          try {
            new Notification(title, notifOptions);
          } catch (e) {
            console.warn('Notification failed:', e);
          }
        });
    } else {
      try {
        new Notification(title, notifOptions);
      } catch (e) {
        console.warn('Direct notification failed:', e);
      }
    }
  }

  return {
    id: `notif-${timestamp}-${Math.random().toString(36).slice(2, 7)}`,
    title,
    message,
    timestamp,
    habitId: habit?.id,
    type: 'reminder',
    read: false,
  };
}

export function checkAndTriggerHabitReminders(
  habits: Habit[],
  notificationsEnabled: boolean,
  alreadyTriggeredSet: Set<string>,
  completions: HabitCompletion[] = [],
  language: Language = 'en'
): { notifications: InAppNotification[]; triggeredKeys: string[] } {
  if (!notificationsEnabled) {
    return { notifications: [], triggeredKeys: [] };
  }

  const now = new Date();
  const currentHours = now.getHours();
  const currentMinutes = now.getMinutes();
  const currentTimeStr = `${String(currentHours).padStart(2, '0')}:${String(currentMinutes).padStart(2, '0')}`;
  const todayKey = getTodayKey();
  const currentDayOfWeek = now.getDay();

  const newNotifications: InAppNotification[] = [];
  const triggeredKeys: string[] = [];

  for (const habit of habits) {
    if (habit.isArchived || !habit.reminderEnabled || !habit.reminderTime) continue;

    if (habit.frequency === 'selected_days' && !habit.selectedDays.includes(currentDayOfWeek)) {
      continue;
    }

    if (completions.some((c) => c.habitId === habit.id && c.date === todayKey && c.completed)) {
      continue;
    }

    const [hoursStr, minutesStr] = habit.reminderTime.trim().split(':');
    const remHours = Number.parseInt(hoursStr, 10);
    const remMinutes = Number.parseInt(minutesStr, 10);
    if (Number.isNaN(remHours) || Number.isNaN(remMinutes)) continue;

    if (remHours === currentHours && remMinutes === currentMinutes) {
      const triggerKey = `${habit.id}-${todayKey}-${currentTimeStr}`;
      if (!alreadyTriggeredSet.has(triggerKey)) {
        triggeredKeys.push(triggerKey);
        newNotifications.push(
          sendHabitNotification({
            title: translate(language, 'notification.habitTitle', { name: habit.name }),
            message: translate(language, 'notification.habitBody', { name: habit.name }),
            habit,
            language,
          })
        );
      }
    }
  }

  return { notifications: newNotifications, triggeredKeys };
}