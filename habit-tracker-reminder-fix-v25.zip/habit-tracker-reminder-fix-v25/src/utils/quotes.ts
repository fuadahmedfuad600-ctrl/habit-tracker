/**
 * Curated offline collection of inspiring quotes on discipline, habits, and focus.
 * Zero network dependencies.
 */

export interface HabitQuote {
  quote: string;
  author: string;
  topic: string;
}

export const OFFLINE_QUOTES: HabitQuote[] = [
  {
    quote: "We are what we repeatedly do. Excellence, then, is not an act, but a habit.",
    author: "Aristotle",
    topic: "Consistency",
  },
  {
    quote: "You do not rise to the level of your goals. You fall to the level of your systems.",
    author: "James Clear",
    topic: "Systems",
  },
  {
    quote: "Small disciplines repeated with consistency every day lead to great achievements gained slowly over time.",
    author: "John C. Maxwell",
    topic: "Patience",
  },
  {
    quote: "First forget inspiration. Habit is more dependable. Habit will sustain you whether you're inspired or not.",
    author: "Octavia Butler",
    topic: "Discipline",
  },
  {
    quote: "Motivation is what gets you started. Habit is what keeps you going.",
    author: "Jim Ryun",
    topic: "Momentum",
  },
  {
    quote: "It takes 21 days to make a habit and 90 days to make it a lifestyle.",
    author: "Robin Sharma",
    topic: "Transformation",
  },
  {
    quote: "The secret of your future is hidden in your daily routine.",
    author: "Mike Murdock",
    topic: "Routine",
  },
  {
    quote: "Success is the sum of small efforts, repeated day-in and day-out.",
    author: "Robert Collier",
    topic: "Dedication",
  },
  {
    quote: "Discipline is choosing between what you want now and what you want most.",
    author: "Abraham Lincoln",
    topic: "Willpower",
  },
  {
    quote: "Don't count the days, make the days count.",
    author: "Muhammad Ali",
    topic: "Action",
  },
];

export function getDailyQuote(date: Date = new Date()): HabitQuote {
  // Deterministic daily quote based on day of year
  const start = new Date(date.getFullYear(), 0, 0);
  const diff = date.getTime() - start.getTime();
  const oneDay = 1000 * 60 * 60 * 24;
  const dayOfYear = Math.floor(diff / oneDay);
  const index = Math.abs(dayOfYear) % OFFLINE_QUOTES.length;
  return OFFLINE_QUOTES[index];
}
