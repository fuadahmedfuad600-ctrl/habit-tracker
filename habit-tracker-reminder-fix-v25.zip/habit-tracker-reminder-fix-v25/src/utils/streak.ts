import { Habit, HabitCompletion } from '../types';
import { formatDateKey, parseDateKey } from './date';

/**
 * Checks if a habit is scheduled for a given day of the week
 */
export function isHabitScheduledForDate(habit: Habit, date: Date): boolean {
  if (habit.frequency === 'daily') {
    return true;
  }
  const dayOfWeek = date.getDay(); // 0 is Sunday, 1 is Monday, ..., 6 is Saturday
  return Array.isArray(habit.selectedDays) && habit.selectedDays.includes(dayOfWeek);
}

/**
 * Checks if a habit was completed on a specific date
 */
export function isHabitCompletedOnDate(
  habitId: string,
  dateKey: string,
  completions: HabitCompletion[]
): boolean {
  return completions.some((c) => c.habitId === habitId && c.date === dateKey && c.completed);
}

/**
 * Checks if a habit is applicable on a specific calendar date.
 * - If habit was completed on this date: always applicable.
 * - If archived and not completed on this date: not applicable.
 * - If the date is before the habit was created (by calendar day): not applicable.
 * - Otherwise: checks the frequency schedule (daily or selected days).
 */
export function isHabitApplicableOnDate(
  habit: Habit,
  date: Date,
  completions: HabitCompletion[] = []
): boolean {
  const dateKey = formatDateKey(date);

  // If completed on this date, it's definitely applicable/active
  if (isHabitCompletedOnDate(habit.id, dateKey, completions)) {
    return true;
  }

  // If archived and not completed, ignore
  if (habit.isArchived) {
    return false;
  }

  // A habit does not exist on dates prior to its creation calendar day
  if (habit.createdAt) {
    const createdKey = formatDateKey(new Date(habit.createdAt));
    if (dateKey < createdKey) {
      return false;
    }
  }

  return isHabitScheduledForDate(habit, date);
}

/**
 * Calculate accurate current streak, best streak, and stats for a habit
 */
export function calculateHabitStats(
  habit: Habit,
  completions: HabitCompletion[],
  asOfDate: Date = new Date()
): {
  currentStreak: number;
  bestStreak: number;
  completionRate: number;
  totalCompleted: number;
  isCompletedToday: boolean;
} {
  const habitCompletions = completions.filter((c) => c.habitId === habit.id && c.completed);
  const completionDateSet = new Set(habitCompletions.map((c) => c.date));

  const todayKey = formatDateKey(asOfDate);
  const isCompletedToday = completionDateSet.has(todayKey);
  const isScheduledToday = isHabitScheduledForDate(habit, asOfDate);

  // 1. Calculate Current Streak
  let currentStreak = 0;
  const cursorDate = new Date(asOfDate);
  cursorDate.setHours(0, 0, 0, 0);

  // If today is scheduled and completed, we start streak count from today
  // If today is scheduled and NOT completed, we start looking backwards from yesterday
  // If today is NOT scheduled, we look backwards from the last scheduled day
  if (isScheduledToday) {
    if (isCompletedToday) {
      currentStreak++;
      cursorDate.setDate(cursorDate.getDate() - 1);
    } else {
      // Not completed yet today; check if yesterday was done (grace period for today)
      cursorDate.setDate(cursorDate.getDate() - 1);
    }
  } else {
    // Today is not a scheduled day, start checking from yesterday
    cursorDate.setDate(cursorDate.getDate() - 1);
  }

  // Count backwards day by day for up to 365 days
  let lookbackDays = 0;
  const maxLookback = 365;

  while (lookbackDays < maxLookback) {
    if (isHabitScheduledForDate(habit, cursorDate)) {
      const dateKey = formatDateKey(cursorDate);
      if (completionDateSet.has(dateKey)) {
        currentStreak++;
      } else {
        // Streak broken
        break;
      }
    }

    cursorDate.setDate(cursorDate.getDate() - 1);
    lookbackDays++;
  }

  // 2. Calculate Historical Best Streak
  let historicalBest = 0;
  if (completionDateSet.size > 0) {
    const sortedDates = Array.from(completionDateSet).sort();
    const firstDate = parseDateKey(sortedDates[0]);
    const lastDate = parseDateKey(todayKey);

    let tempStreak = 0;
    const runCursor = new Date(firstDate);
    runCursor.setHours(0, 0, 0, 0);

    while (runCursor <= lastDate) {
      if (isHabitScheduledForDate(habit, runCursor)) {
        const key = formatDateKey(runCursor);
        if (completionDateSet.has(key)) {
          tempStreak++;
          if (tempStreak > historicalBest) {
            historicalBest = tempStreak;
          }
        } else {
          tempStreak = 0;
        }
      }
      runCursor.setDate(runCursor.getDate() + 1);
    }
  }

  const bestStreak = Math.max(habit.bestStreak || 0, currentStreak, historicalBest);

  // 3. Total completed days
  const totalCompleted = completionDateSet.size;

  // 4. Accurate Consistency / Completion Rate calculation
  const createdDateKey = habit.createdAt ? formatDateKey(new Date(habit.createdAt)) : todayKey;
  let startKey = createdDateKey;
  if (completionDateSet.size > 0) {
    const sortedDates = Array.from(completionDateSet).sort();
    if (sortedDates[0] < startKey) {
      startKey = sortedDates[0];
    }
  }

  const startDate = parseDateKey(startKey);
  const nowDay = parseDateKey(todayKey);

  let scheduledDaysCount = 0;
  let completedScheduledCount = 0;

  const rateCursor = new Date(startDate);
  // Check past scheduled days up to today
  while (rateCursor < nowDay) {
    if (isHabitScheduledForDate(habit, rateCursor)) {
      scheduledDaysCount++;
      const key = formatDateKey(rateCursor);
      if (completionDateSet.has(key)) {
        completedScheduledCount++;
      }
    }
    rateCursor.setDate(rateCursor.getDate() + 1);
  }

  // Include today if today is scheduled
  if (isScheduledToday) {
    scheduledDaysCount++;
    if (isCompletedToday) {
      completedScheduledCount++;
    }
  }

  let completionRate = 0;
  if (scheduledDaysCount > 0) {
    completionRate = Math.min(100, Math.round((completedScheduledCount / scheduledDaysCount) * 100));
  } else {
    // If no scheduled days have arrived yet
    completionRate = totalCompleted > 0 ? 100 : 0;
  }

  return {
    currentStreak,
    bestStreak,
    completionRate,
    totalCompleted,
    isCompletedToday,
  };
}

/**
 * Get daily progress for a specific date (completed / total scheduled)
 * Correctly accounts for habit creation date so newly added habits
 * don't retroactively distort past historical dates.
 */
export function getDailyProgress(
  habits: Habit[],
  completions: HabitCompletion[],
  targetDate: Date
): {
  scheduledHabits: Habit[];
  completedCount: number;
  totalCount: number;
  percentage: number;
} {
  const targetDateKey = formatDateKey(targetDate);
  const scheduledHabits = habits.filter((h) =>
    isHabitApplicableOnDate(h, targetDate, completions)
  );

  const completedCount = scheduledHabits.filter((h) =>
    isHabitCompletedOnDate(h.id, targetDateKey, completions)
  ).length;

  const totalCount = scheduledHabits.length;
  const percentage = totalCount > 0 ? Math.round((completedCount / totalCount) * 100) : 0;

  return {
    scheduledHabits,
    completedCount,
    totalCount,
    percentage,
  };
}
