import React, { createContext, useContext, useEffect, useState, useCallback, useMemo } from 'react';
import confetti from 'canvas-confetti';
import {
  AppSettings,
  Habit,
  HabitCompletion,
  InAppNotification,
  TabType,
} from '../types';
import { formatDateKey, getTodayKey } from '../utils/date';
import { DEFAULT_SETTINGS } from '../utils/defaults';
import {
  checkAndTriggerHabitReminders,
  requestNotificationPermission,
  syncBackgroundHabitAlarms,
  setVibrationPreference,
  getNativeReminderHistory,
  isNativeAndroid,
} from '../utils/notifications';
import { LocalNotifications } from '@capacitor/local-notifications';
import type { Language } from '../types';
import { translate } from '../utils/i18n';
import { calculateHabitStats } from '../utils/streak';

interface HabitContextType {
  habits: Habit[];
  completions: HabitCompletion[];
  settings: AppSettings;
  language: Language;
  t: (key: string, vars?: Record<string, string | number>) => string;
  notifications: InAppNotification[];
  unreadNotificationCount: number;
  activeTab: TabType;
  setActiveTab: (tab: TabType) => void;
  selectedDate: Date;
  setSelectedDate: (date: Date) => void;
  
  // Modals & Panels
  isHabitModalOpen: boolean;
  editingHabit: Habit | null;
  openCreateModal: () => void;
  openEditModal: (habit: Habit) => void;
  closeHabitModal: () => void;
  
  selectedHabitForDetail: Habit | null;
  setSelectedHabitForDetail: (habit: Habit | null) => void;
  
  isNotificationCenterOpen: boolean;
  setIsNotificationCenterOpen: (open: boolean) => void;

  // Theme & Appearance
  isDarkMode: boolean;
  toggleTheme: () => void;

  // Habit operations
  createHabit: (data: Omit<Habit, 'id' | 'createdAt' | 'bestStreak' | 'isArchived'>) => Habit;
  updateHabit: (id: string, updates: Partial<Habit>) => void;
  toggleHabitCompletion: (habitId: string, dateKey?: string) => boolean;
  archiveHabit: (id: string) => void;
  unarchiveHabit: (id: string) => void;
  deleteHabit: (id: string, permanent?: boolean) => void;

  // Settings & notifications
  updateSettings: (updates: Partial<AppSettings>) => void;
  requestNotifications: () => Promise<NotificationPermission>;
  markNotificationAsRead: (id: string) => void;
  markAllNotificationsAsRead: () => void;
  clearNotifications: () => void;

  // Backup & Reset
  exportData: () => void;
  clearAllData: () => void;

  // Offline Notes & Micro-Journaling
  notes: Record<string, string>;
  getHabitNote: (habitId: string, dateKey: string) => string;
  saveHabitNote: (habitId: string, dateKey: string, note: string) => void;
  isNoteModalOpen: boolean;
  noteTarget: { habit: Habit; dateKey: string } | null;
  openNoteModal: (habit: Habit, dateKey?: string) => void;
  closeNoteModal: () => void;

  // Achievements & Milestones
  isAchievementsOpen: boolean;
  setIsAchievementsOpen: (open: boolean) => void;
}

const STORAGE_KEYS = {
  HABITS: 'habit_tracker_habits_v1',
  COMPLETIONS: 'habit_tracker_completions_v1',
  SETTINGS: 'habit_tracker_settings_v1',
  THEME_DEFAULT_MIGRATED: 'habit_tracker_theme_default_migrated_v1',
  NOTIFICATIONS: 'habit_tracker_notifications_v1',
  NOTES: 'habit_tracker_notes_v1',
};


const HabitContext = createContext<HabitContextType | undefined>(undefined);

export const HabitProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // Initialize state with local storage or defaults
  const [habits, setHabits] = useState<Habit[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.HABITS);
      if (saved) {
        const parsed = JSON.parse(saved);
        return Array.isArray(parsed) ? parsed : [];
      }
    } catch (e) {
      console.error('Failed to load habits from storage', e);
    }
    return [];
  });

  const [completions, setCompletions] = useState<HabitCompletion[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.COMPLETIONS);
      if (saved) {
        const parsed = JSON.parse(saved);
        return Array.isArray(parsed) ? parsed : [];
      }
    } catch (e) {
      console.error('Failed to load completions from storage', e);
    }
    return [];
  });

  const [settings, setSettings] = useState<AppSettings>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.SETTINGS);
      if (saved) {
        const parsed = JSON.parse(saved);
        const themeMigrationDone = localStorage.getItem(STORAGE_KEYS.THEME_DEFAULT_MIGRATED) === 'true';
        const isLegacyDefaultTheme = parsed.theme == null || parsed.theme === 'system';
        const initialTheme = !themeMigrationDone && isLegacyDefaultTheme
          ? DEFAULT_SETTINGS.theme
          : parsed.theme ?? DEFAULT_SETTINGS.theme;
        try { localStorage.setItem(STORAGE_KEYS.THEME_DEFAULT_MIGRATED, 'true'); } catch { /* storage may be unavailable */ }
        return {
          ...DEFAULT_SETTINGS,
          // Migrate an old default System theme once, but keep future manual System selections.
          theme: initialTheme,
          notificationsEnabled: parsed.notificationsEnabled ?? DEFAULT_SETTINGS.notificationsEnabled,
          vibrationEnabled: parsed.vibrationEnabled ?? DEFAULT_SETTINGS.vibrationEnabled,
          language: parsed.language === 'bn' || parsed.language === 'hi' ? parsed.language : DEFAULT_SETTINGS.language,
          weekStart: parsed.weekStart ?? DEFAULT_SETTINGS.weekStart,
          onboardingCompleted: parsed.onboardingCompleted ?? DEFAULT_SETTINGS.onboardingCompleted,
        };
      }
    } catch (e) {
      console.error('Failed to load settings', e);
    }
    try { localStorage.setItem(STORAGE_KEYS.THEME_DEFAULT_MIGRATED, 'true'); } catch { /* storage may be unavailable */ }
    return DEFAULT_SETTINGS;
  });

  const [notifications, setNotifications] = useState<InAppNotification[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.NOTIFICATIONS);
      if (saved) {
        const parsed = JSON.parse(saved);
        return Array.isArray(parsed) ? parsed : [];
      }
    } catch {
      // ignore
    }
    return [];
  });

  // UI state
  const [activeTab, setActiveTab] = useState<TabType>('home');
  const [selectedDate, setSelectedDate] = useState<Date>(new Date());
  const [isHabitModalOpen, setIsHabitModalOpen] = useState(false);
  const [editingHabit, setEditingHabit] = useState<Habit | null>(null);
  const [selectedHabitForDetail, setSelectedHabitForDetail] = useState<Habit | null>(null);
  const [isNotificationCenterOpen, setIsNotificationCenterOpen] = useState(false);
  const [triggeredReminders] = useState<Set<string>>(() => new Set());

  const language = settings.language;
  const t = useCallback((key: string, vars?: Record<string, string | number>) => translate(language, key, vars), [language]);

  useEffect(() => {
    document.documentElement.lang = language === 'bn' ? 'bn' : language === 'hi' ? 'hi' : 'en';
  }, [language]);

  // Save to localStorage
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.HABITS, JSON.stringify(habits));
    } catch (e) {
      console.error('Error saving habits', e);
    }
  }, [habits]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.COMPLETIONS, JSON.stringify(completions));
    } catch (e) {
      console.error('Error saving completions', e);
    }
  }, [completions]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.SETTINGS, JSON.stringify(settings));
    } catch (e) {
      console.error('Error saving settings', e);
    }
  }, [settings]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.NOTIFICATIONS, JSON.stringify(notifications));
    } catch (e) {
      console.error('Error saving notifications', e);
    }
  }, [notifications]);

  // Notes state
  const [notes, setNotes] = useState<Record<string, string>>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.NOTES);
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.error('Error loading notes', e);
    }
    return {};
  });

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.NOTES, JSON.stringify(notes));
    } catch (e) {
      console.error('Error saving notes', e);
    }
  }, [notes]);

  const getHabitNote = useCallback(
    (habitId: string, dateKey: string) => {
      return notes[`${habitId}_${dateKey}`] || '';
    },
    [notes]
  );

  const saveHabitNote = useCallback((habitId: string, dateKey: string, note: string) => {
    setNotes((prev) => {
      const next = { ...prev };
      if (!note) {
        delete next[`${habitId}_${dateKey}`];
      } else {
        next[`${habitId}_${dateKey}`] = note;
      }
      return next;
    });
  }, []);

  // Achievements state
  const [isAchievementsOpen, setIsAchievementsOpen] = useState(false);

  // Note modal state
  const [isNoteModalOpen, setIsNoteModalOpen] = useState(false);
  const [noteTarget, setNoteTarget] = useState<{ habit: Habit; dateKey: string } | null>(null);
  const openNoteModal = useCallback(
    (habit: Habit, dateKey?: string) => {
      setNoteTarget({
        habit,
        dateKey: dateKey || formatDateKey(selectedDate),
      });
      setIsNoteModalOpen(true);
    },
    [selectedDate]
  );
  const closeNoteModal = useCallback(() => {
    setIsNoteModalOpen(false);
    setNoteTarget(null);
  }, []);

  // Apply Theme (light, dark, system)
  const [isDarkMode, setIsDarkMode] = useState<boolean>(() => {
    if (typeof window === 'undefined') return false;
    const saved = localStorage.getItem(STORAGE_KEYS.SETTINGS);
    if (saved) {
      const parsed = JSON.parse(saved);
      if (parsed.theme === 'dark') return true;
      if (parsed.theme === 'light') return false;
    }
    return false;
  });

  useEffect(() => {
    const root = document.documentElement;
    const applyTheme = (isDark: boolean) => {
      setIsDarkMode(isDark);
      if (isDark) {
        root.classList.add('dark');
        document.querySelector('meta[name="theme-color"]')?.setAttribute('content', '#020617');
      } else {
        root.classList.remove('dark');
        document.querySelector('meta[name="theme-color"]')?.setAttribute('content', '#2878f0');
      }
    };

    if (settings.theme === 'dark') {
      applyTheme(true);
    } else if (settings.theme === 'light') {
      applyTheme(false);
    } else {
      // System mode
      const mediaQuery = window.matchMedia('(prefers-color-scheme: dark)');
      applyTheme(mediaQuery.matches);

      const handler = (e: MediaQueryListEvent) => applyTheme(e.matches);
      mediaQuery.addEventListener('change', handler);
      return () => mediaQuery.removeEventListener('change', handler);
    }
  }, [settings.theme]);

  const toggleTheme = useCallback(() => {
    setSettings((prev) => {
      const nextTheme = isDarkMode ? 'light' : 'dark';
      return { ...prev, theme: nextTheme };
    });
  }, [isDarkMode]);

  // Reminder Checker Interval (checks immediately and every 10 seconds for timely prompts)
  useEffect(() => {
    // Native Android alarms are the single source of truth for system reminders.
    // Running the JS minute-checker on Android would schedule a second notification.
    if (!settings.notificationsEnabled || isNativeAndroid()) return;

    const check = () => {
      const result = checkAndTriggerHabitReminders(
        habits,
        settings.notificationsEnabled,
        triggeredReminders,
        completions,
        language
      );

      if (result.notifications.length > 0) {
        // On Android the native listener below mirrors system notifications into the bell.
        // Do not add a second in-app item here, otherwise one reminder appears twice.
        if (!isNativeAndroid()) {
          setNotifications((prev) => [...result.notifications, ...prev].slice(0, 50));
        }
        result.triggeredKeys.forEach((key) => triggeredReminders.add(key));
      }
    };

    // Immediate check
    check();

    const interval = setInterval(check, 10000);

    const handleVisibilityOrFocus = () => {
      if (document.visibilityState === 'visible') {
        check();
      }
    };
    document.addEventListener('visibilitychange', handleVisibilityOrFocus);
    window.addEventListener('focus', handleVisibilityOrFocus);

    return () => {
      clearInterval(interval);
      document.removeEventListener('visibilitychange', handleVisibilityOrFocus);
      window.removeEventListener('focus', handleVisibilityOrFocus);
    };
  }, [habits, settings.notificationsEnabled, triggeredReminders, completions, language]);

  // Synchronize native background alarms (Capacitor LocalNotifications / AlarmManager)
  // Ensures notifications fire on time even if the app is completely closed or killed.
  useEffect(() => {
    syncBackgroundHabitAlarms(habits, settings.notificationsEnabled, language);

    // Refresh the upcoming alarms whenever the app comes back to the foreground.
    const onVisible = () => {
      if (document.visibilityState === 'visible') {
        syncBackgroundHabitAlarms(habits, settings.notificationsEnabled, language);
      }
    };
    document.addEventListener('visibilitychange', onVisible);
    return () => document.removeEventListener('visibilitychange', onVisible);
  }, [habits, settings.notificationsEnabled, language]);

  // Tell the notification layer whether reminders should vibrate.
  useEffect(() => {
    void setVibrationPreference(settings.vibrationEnabled);
  }, [settings.vibrationEnabled]);

  // Mirror Android system notifications into the in-app bell history. No in-app toast is shown.
  useEffect(() => {
    if (!isNativeAndroid()) return;
    let listenerHandle: { remove: () => Promise<void> } | null = null;
    let mounted = true;

    const toStoredNotification = (item: { id: number; title: string; body: string; extra?: any }, timestamp: number): InAppNotification => ({
      id: `native-${item.id}`,
      title: item.title,
      message: item.body,
      timestamp,
      habitId: item.extra?.habitId,
      type: 'reminder',
      read: false,
    });

    const hydrate = async () => {
      try {
        const [result, nativeHistory] = await Promise.all([
          LocalNotifications.getDeliveredNotifications(),
          getNativeReminderHistory(),
        ]);
        if (!mounted) return;
        // Remember copied IDs so cleared history stays cleared after the app reopens.
        let seen: string[] = [];
        try {
          seen = JSON.parse(localStorage.getItem('habit_native_seen_v2') || '[]');
        } catch {
          seen = [];
        }
        const seenSet = new Set(seen);
        const pluginHydrated = (result.notifications || [])
          .slice(-50)
          .map((item, index) => toStoredNotification(item, Date.now() - index))
          .filter((n) => !seenSet.has(n.id));
        const alarmHydrated: InAppNotification[] = nativeHistory.slice(-50).map((item) => ({
          id: `native-reminder-${item.id}-${item.timestamp}`,
          title: item.title,
          message: item.body,
          timestamp: item.timestamp,
          habitId: item.habitId || undefined,
          type: 'reminder' as const,
          read: false,
        })).filter((n) => !seenSet.has(n.id));
        const hydrated = [...alarmHydrated, ...pluginHydrated].sort((a, b) => b.timestamp - a.timestamp).slice(0, 50);
        if (hydrated.length === 0) return;
        try {
          localStorage.setItem(
            'habit_native_seen_v2',
            JSON.stringify([...seen, ...hydrated.map((n) => n.id)].slice(-300))
          );
        } catch {
          // ignore storage errors
        }
        setNotifications((prev) => {
          const ids = new Set(prev.map((n) => n.id));
          const additions = hydrated.filter((n) => !ids.has(n.id));
          return [...additions, ...prev].slice(0, 50);
        });
      } catch (error) {
        console.warn('Could not hydrate delivered notifications:', error);
      }
    };

    const listen = async () => {
      try {
        const handle = await LocalNotifications.addListener('localNotificationReceived', (notification) => {
          const item = {
            id: notification.id,
            title: notification.title,
            body: notification.body,
            extra: notification.extra,
          };
          const stored: InAppNotification = {
            ...toStoredNotification(item, Date.now()),
            id: `native-${notification.id}-${Date.now()}`,
          };
          setNotifications((prev) => [stored, ...prev].slice(0, 50));
        });
        listenerHandle = handle;
      } catch (error) {
        console.warn('Could not register notification listener:', error);
      }
    };

    hydrate();
    listen();

    // Alarm notifications are delivered while the app is closed; pick them up when it reopens.
    const onVisible = () => {
      if (document.visibilityState === 'visible') hydrate();
    };
    document.addEventListener('visibilitychange', onVisible);

    return () => {
      document.removeEventListener('visibilitychange', onVisible);
      mounted = false;
      listenerHandle?.remove().catch(() => undefined);
    };
  }, []);

  // Modal Handlers
  const openCreateModal = useCallback(() => {
    // Reset the modal's open state before reopening it. This forces a clean
    // create-form lifecycle even if a previous submit/close was not committed
    // cleanly by the Android WebView.
    setEditingHabit(null);
    setIsHabitModalOpen(false);
    window.setTimeout(() => setIsHabitModalOpen(true), 0);
  }, []);

  const openEditModal = useCallback((habit: Habit) => {
    setEditingHabit(habit);
    setIsHabitModalOpen(true);
  }, []);

  const closeHabitModal = useCallback(() => {
    setIsHabitModalOpen(false);
    setEditingHabit(null);
  }, []);

  // Habit CRUD operations
  const createHabit = useCallback(
    (data: Omit<Habit, 'id' | 'createdAt' | 'bestStreak' | 'isArchived'>): Habit => {
      const newHabit: Habit = {
        ...data,
        id: `habit-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
        createdAt: new Date().toISOString(),
        bestStreak: 0,
        isArchived: false,
      };

      setHabits((prev) => [newHabit, ...prev]);

      // Add feedback notification
      if (settings.notificationsEnabled) {
        const notif: InAppNotification = {
          id: `created-${Date.now()}`,
          title: t('notification.createdTitle'),
          message: t('notification.createdBody', { name: newHabit.name }),
          timestamp: Date.now(),
          type: 'info',
          read: false,
        };
        setNotifications((prev) => [notif, ...prev]);
      }

      return newHabit;
    },
    [settings.notificationsEnabled, t]
  );

  const updateHabit = useCallback((id: string, updates: Partial<Habit>) => {
    setHabits((prev) =>
      prev.map((habit) => (habit.id === id ? { ...habit, ...updates } : habit))
    );
    setSelectedHabitForDetail((current) =>
      current && current.id === id ? { ...current, ...updates } : current
    );
  }, []);

  const archiveHabit = useCallback((id: string) => {
    setHabits((prev) =>
      prev.map((h) => (h.id === id ? { ...h, isArchived: true } : h))
    );
    setSelectedHabitForDetail(null);
  }, []);

  const unarchiveHabit = useCallback((id: string) => {
    setHabits((prev) =>
      prev.map((h) => (h.id === id ? { ...h, isArchived: false } : h))
    );
  }, []);

  const deleteHabit = useCallback((id: string, permanent: boolean = false) => {
    if (permanent) {
      setHabits((prev) => prev.filter((h) => h.id !== id));
      setCompletions((prev) => prev.filter((c) => c.habitId !== id));
    } else {
      // Default to archiving as recommended in PRD Section 19
      setHabits((prev) =>
        prev.map((h) => (h.id === id ? { ...h, isArchived: true } : h))
      );
    }
    setSelectedHabitForDetail(null);
  }, []);

  // Toggle habit completion
  const toggleHabitCompletion = useCallback(
    (habitId: string, dateKey?: string): boolean => {
      const targetDateKey = dateKey || formatDateKey(selectedDate);
      
      let nextCompletedState = false;
      let nextCompletions: HabitCompletion[] = [];

      setCompletions((prev) => {
        const existingIndex = prev.findIndex(
          (c) => c.habitId === habitId && c.date === targetDateKey
        );

        let updated: HabitCompletion[];
        if (existingIndex >= 0) {
          // Toggle existing
          const currentVal = prev[existingIndex].completed;
          nextCompletedState = !currentVal;
          updated = [...prev];
          updated[existingIndex] = {
            ...updated[existingIndex],
            completed: nextCompletedState,
            completedAt: nextCompletedState ? new Date().toISOString() : undefined,
          };
        } else {
          // New completion record
          nextCompletedState = true;
          updated = [
            ...prev,
            {
              id: `comp-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
              habitId,
              date: targetDateKey,
              completed: true,
              completedAt: new Date().toISOString(),
            },
          ];
        }
        nextCompletions = updated;
        return updated;
      });

      // Celebration is visual-only; reminder audio/haptics are handled by the Android notification system.
      if (nextCompletedState) {
        const targetHabit = habits.find((h) => h.id === habitId);
        if (targetHabit) {
          // Calculate streak accurately using the new completions
          const stats = calculateHabitStats(targetHabit, nextCompletions, new Date());
          const newStreak = stats.currentStreak;

          // Update bestStreak if beaten
          if (newStreak > targetHabit.bestStreak) {
            updateHabit(habitId, { bestStreak: newStreak });
          }

          // Milestone celebrations at 3, 7, 14, 21, 30, 50, 100 days
          const milestones = [3, 7, 14, 21, 30, 50, 100];
          if (milestones.includes(newStreak)) {
            confetti({
              particleCount: 80,
              spread: 70,
              origin: { y: 0.7 },
              colors: ['#10b981', '#3b82f6', '#f59e0b', '#ec4899'],
            });

            setNotifications((prevNotifs) => [
              {
                id: `milestone-${Date.now()}`,
                title: t('notification.milestoneTitle', { streak: newStreak }),
                message: t('notification.milestoneBody', { name: targetHabit.name, streak: newStreak }),
                timestamp: Date.now(),
                habitId: targetHabit.id,
                type: 'streak',
                read: false,
              },
              ...prevNotifs,
            ]);
          }
        }
      }

      return nextCompletedState;
    },
    [selectedDate, settings, habits, updateHabit, t]
  );

  // Settings & notifications
  const updateSettings = useCallback((updates: Partial<AppSettings>) => {
    setSettings((prev) => ({ ...prev, ...updates }));
  }, []);

  const requestNotifications = useCallback(async (): Promise<NotificationPermission> => {
    const perm = await requestNotificationPermission();
    if (perm === 'granted') {
      updateSettings({ notificationsEnabled: true });
    }
    return perm;
  }, [updateSettings]);

  const markNotificationAsRead = useCallback((id: string) => {
    setNotifications((prev) =>
      prev.map((n) => (n.id === id ? { ...n, read: true } : n))
    );
  }, []);

  const markAllNotificationsAsRead = useCallback(() => {
    setNotifications((prev) => prev.map((n) => ({ ...n, read: true })));
  }, []);

  const clearNotifications = useCallback(() => {
    setNotifications([]);
  }, []);

  // Data Export (there is intentionally no data-import / demo-data loader in the app).
  const exportData = useCallback(() => {
    const exportPayload = {
      version: '1.0.0',
      exportDate: new Date().toISOString(),
      habits,
      completions,
      settings,
    };

    const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(exportPayload, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute('href', dataStr);
    downloadAnchor.setAttribute('download', `habit-tracker-backup-${getTodayKey()}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  }, [habits, completions, settings]);

  const clearAllData = useCallback(() => {
    setHabits([]);
    setCompletions([]);
    setNotifications([]);
    localStorage.removeItem(STORAGE_KEYS.HABITS);
    localStorage.removeItem(STORAGE_KEYS.COMPLETIONS);
    localStorage.removeItem(STORAGE_KEYS.NOTIFICATIONS);
    setNotes({});
    localStorage.removeItem(STORAGE_KEYS.NOTES);
  }, []);

  const unreadNotificationCount = useMemo(
    () => notifications.filter((n) => !n.read).length,
    [notifications]
  );

  const value = useMemo(
    () => ({
      habits,
      completions,
      settings,
      language,
      t,
      notifications,
      unreadNotificationCount,
      activeTab,
      setActiveTab,
      selectedDate,
      setSelectedDate,
      isHabitModalOpen,
      editingHabit,
      openCreateModal,
      openEditModal,
      closeHabitModal,
      selectedHabitForDetail,
      setSelectedHabitForDetail,
      isNotificationCenterOpen,
      setIsNotificationCenterOpen,
      isDarkMode,
      toggleTheme,
      createHabit,
      updateHabit,
      toggleHabitCompletion,
      archiveHabit,
      unarchiveHabit,
      deleteHabit,
      updateSettings,
      requestNotifications,
      markNotificationAsRead,
      markAllNotificationsAsRead,
      clearNotifications,
      exportData,
      clearAllData,
      notes,
      getHabitNote,
      saveHabitNote,
      isNoteModalOpen,
      noteTarget,
      openNoteModal,
      closeNoteModal,
      isAchievementsOpen,
      setIsAchievementsOpen,
    }),
    [
      habits,
      completions,
      settings,
      language,
      t,
      notifications,
      unreadNotificationCount,
      activeTab,
      selectedDate,
      isHabitModalOpen,
      editingHabit,
      openCreateModal,
      openEditModal,
      closeHabitModal,
      selectedHabitForDetail,
      isNotificationCenterOpen,
      isDarkMode,
      toggleTheme,
      createHabit,
      updateHabit,
      toggleHabitCompletion,
      archiveHabit,
      unarchiveHabit,
      deleteHabit,
      updateSettings,
      requestNotifications,
      markNotificationAsRead,
      markAllNotificationsAsRead,
      clearNotifications,
      exportData,
      clearAllData,
      notes,
      getHabitNote,
      saveHabitNote,
      isNoteModalOpen,
      noteTarget,
      openNoteModal,
      closeNoteModal,
      isAchievementsOpen,
    ]
  );

  return <HabitContext.Provider value={value}>{children}</HabitContext.Provider>;
};

export const useHabit = (): HabitContextType => {
  const context = useContext(HabitContext);
  if (!context) {
    throw new Error('useHabit must be used within a HabitProvider');
  }
  return context;
};
