export type HabitCategory = 'Health' | 'Fitness' | 'Study' | 'Work' | 'Personal' | 'Other' | (string & {});

export type HabitFrequency = 'daily' | 'selected_days';

export interface Habit {
  id: string;
  name: string;
  category: HabitCategory;
  icon: string;
  color: string;
  frequency: HabitFrequency;
  selectedDays: number[]; // 0=Sunday, 1=Monday, ..., 6=Saturday
  reminderEnabled: boolean;
  reminderTime: string; // HH:MM 24-hour format
  createdAt: string; // ISO date string
  isArchived: boolean;
  bestStreak: number;
  description?: string;
}

export interface HabitCompletion {
  id: string;
  habitId: string;
  date: string; // YYYY-MM-DD
  completed: boolean;
  completedAt?: string;
}

export type ThemeMode = 'light' | 'dark' | 'system';
export type Language = 'en' | 'bn' | 'hi';
export type WeekStartDay = 'saturday' | 'sunday' | 'monday';

export interface AppSettings {
  theme: ThemeMode;
  notificationsEnabled: boolean;
  vibrationEnabled: boolean;
  language: Language;
  weekStart: WeekStartDay;
  onboardingCompleted: boolean;
}

export interface InAppNotification {
  id: string;
  title: string;
  message: string;
  timestamp: number;
  habitId?: string;
  type: 'reminder' | 'streak' | 'achievement' | 'info';
  read: boolean;
}

export interface ExportData {
  version: string;
  exportDate: string;
  habits: Habit[];
  completions: HabitCompletion[];
  settings: AppSettings;
}

export type TabType = 'home' | 'habits' | 'calendar' | 'stats' | 'settings';
