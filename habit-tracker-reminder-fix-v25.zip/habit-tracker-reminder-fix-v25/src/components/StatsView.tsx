import React, { useMemo, useState } from 'react';
import { useHabit } from '../context/HabitContext';
import {
  formatDateKey,
  formatDisplayDate,
  formatMonthYear,
  formatShortDate,
  getDayNames,
  getTodayKey,
  getWeekDays,
} from '../utils/date';
import {
  calculateHabitStats,
  getDailyProgress,
  isHabitCompletedOnDate,
  isHabitScheduledForDate,
} from '../utils/streak';
import { COLOR_OPTIONS } from '../utils/defaults';
import {
  DynamicIcon,
  Flame,
  BarChart3,
  Target,
  Calendar as CalendarIcon,
  Check,
} from './DynamicIcon';

interface HeatmapDay {
  date: Date;
  dateKey: string;
  isToday: boolean;
  isFuture: boolean;
  completedCount: number;
  totalCount: number;
  percentage: number;
  intensity: number;
  scheduledHabits: any[];
  completedHabitIds: string[];
}

interface HeatmapWeek {
  weekIndex: number; // 0 to 6
  weekLabel: string;
  isCurrentWeek: boolean;
  days: HeatmapDay[];
}

export const StatsView: React.FC = () => {
  const { habits, completions, settings, language, t, toggleHabitCompletion } = useHabit();

  const activeHabits = habits.filter((h) => !h.isArchived);
  const weeklyBarColors = ['bg-rose-500', 'bg-amber-500', 'bg-sky-500', 'bg-violet-500', 'bg-emerald-500', 'bg-orange-500', 'bg-teal-500'];
  const today = new Date();
  const todayKey = getTodayKey();

  // 1. Overall Stats calculation
  const overallStats = useMemo(() => {
    const todayProgress = getDailyProgress(habits, completions, today);

    // This week completion rate
    const currentWeekDays = getWeekDays(today, settings.weekStart);
    let weekScheduled = 0;
    let weekCompleted = 0;
    currentWeekDays.forEach((day) => {
      const p = getDailyProgress(habits, completions, day);
      weekScheduled += p.totalCount;
      weekCompleted += p.completedCount;
    });
    const weekRate = weekScheduled > 0 ? Math.round((weekCompleted / weekScheduled) * 100) : 0;

    // This month completion rate
    const currentYear = today.getFullYear();
    const currentMonth = today.getMonth();
    const daysInMonth = new Date(currentYear, currentMonth + 1, 0).getDate();
    
    let monthScheduled = 0;
    let monthCompleted = 0;
    for (let d = 1; d <= daysInMonth; d++) {
      const dayDate = new Date(currentYear, currentMonth, d);
      if (dayDate <= today) {
        const p = getDailyProgress(habits, completions, dayDate);
        monthScheduled += p.totalCount;
        monthCompleted += p.completedCount;
      }
    }
    const monthRate = monthScheduled > 0 ? Math.round((monthCompleted / monthScheduled) * 100) : 0;

    // Best overall streak across all habits
    let maxBestStreak = 0;
    let bestHabitName = 'None';
    let bestHabitRate = 0;

    activeHabits.forEach((h) => {
      const s = calculateHabitStats(h, completions, today);
      if (s.bestStreak > maxBestStreak) {
        maxBestStreak = s.bestStreak;
      }
      if (s.completionRate > bestHabitRate) {
        bestHabitRate = s.completionRate;
        bestHabitName = h.name;
      }
    });

    const totalCompletionsCount = completions.filter((c) => c.completed).length;

    return {
      totalHabits: activeHabits.length,
      todayRate: todayProgress.percentage,
      weekRate,
      monthRate,
      monthCompleted,
      monthMissed: Math.max(0, monthScheduled - monthCompleted),
      maxBestStreak,
      bestHabitName,
      totalCompletionsCount,
    };
  }, [habits, completions, activeHabits, today, settings.weekStart]);

  // 2. Weekly Bar Chart Data
  const weeklyData = useMemo(() => {
    const currentWeekDays = getWeekDays(today, settings.weekStart);
    return currentWeekDays.map((day) => {
      const p = getDailyProgress(habits, completions, day);
      const isToday = formatDateKey(day) === todayKey;
      const dayName = day.toLocaleDateString(language === 'bn' ? 'bn-BD' : language === 'hi' ? 'hi-IN' : 'en-US', { weekday: 'short' });
      return {
        date: day,
        dayName,
        percentage: p.percentage,
        completed: p.completedCount,
        total: p.totalCount,
        isToday,
      };
    });
  }, [today, habits, completions, settings.weekStart, todayKey]);

  // Selected date in heatmap for detail inspection
  const [selectedHeatmapDateKey, setSelectedHeatmapDateKey] = useState<string>(todayKey);

  // 3. Contribution Heatmap (Last 1 Month = 4 full weeks aligned by weekStart)
  const oneMonthData = useMemo(() => {
    const todayZero = new Date(today);
    todayZero.setHours(0, 0, 0, 0);

    const currentWeekDays = getWeekDays(todayZero, settings.weekStart);
    const currentWeekStart = currentWeekDays[0];

    const weeks: HeatmapWeek[] = [];
    let totalScheduled1M = 0;
    let totalCompleted1M = 0;
    let daysWithCompletion1M = 0;
    let perfectDays1M = 0;
    const WEEKS_COUNT = 4; // 1 month of data (28 days)

    for (let w = WEEKS_COUNT - 1; w >= 0; w--) {
      const weekStartDate = new Date(currentWeekStart);
      weekStartDate.setDate(weekStartDate.getDate() - w * 7);

      const days: HeatmapDay[] = [];
      for (let d = 0; d < 7; d++) {
        const dayDate = new Date(weekStartDate);
        dayDate.setDate(weekStartDate.getDate() + d);
        dayDate.setHours(0, 0, 0, 0);

        const key = formatDateKey(dayDate);
        const isToday = key === todayKey;
        const isFuture = dayDate > todayZero;

        const progress = getDailyProgress(habits, completions, dayDate);
        const completedHabitIds = progress.scheduledHabits
          .filter((h) => isHabitCompletedOnDate(h.id, key, completions))
          .map((h) => h.id);

        let intensity = 0;
        if (isFuture) {
          intensity = -1;
        } else if (progress.completedCount > 0) {
          if (progress.percentage === 100) {
            intensity = 4;
            perfectDays1M++;
          } else if (progress.percentage >= 67) {
            intensity = 3;
          } else if (progress.percentage >= 34) {
            intensity = 2;
          } else {
            intensity = 1;
          }
        }

        if (!isFuture && progress.totalCount > 0) {
          totalScheduled1M += progress.totalCount;
          totalCompleted1M += progress.completedCount;
          if (progress.completedCount > 0) {
            daysWithCompletion1M++;
          }
        }

        days.push({
          date: dayDate,
          dateKey: key,
          isToday,
          isFuture,
          completedCount: progress.completedCount,
          totalCount: progress.totalCount,
          percentage: progress.percentage,
          intensity,
          scheduledHabits: progress.scheduledHabits,
          completedHabitIds,
        });
      }

      const isCurrentWeek = w === 0;
      const monthDayStr = weekStartDate.toLocaleDateString(language === 'bn' ? 'bn-BD' : language === 'hi' ? 'hi-IN' : 'en-US', {
        month: 'short',
        day: 'numeric',
      });
      const weekLabel = isCurrentWeek ? t('stats.thisWeekShort') : monthDayStr;

      weeks.push({
        weekIndex: (WEEKS_COUNT - 1) - w,
        weekLabel,
        isCurrentWeek,
        days,
      });
    }

    const overall1MConsistency =
      totalScheduled1M > 0 ? Math.round((totalCompleted1M / totalScheduled1M) * 100) : 0;

    return {
      weeks,
      overall1MConsistency,
      totalCompleted1M,
      totalScheduled1M,
      daysWithCompletion1M,
      perfectDays1M,
    };
  }, [today, todayKey, settings.weekStart, habits, completions, language, t]);

  // Find currently inspected day from the 1 month grid
  const inspectedDay = useMemo(() => {
    for (const week of oneMonthData.weeks) {
      const match = week.days.find((d) => d.dateKey === selectedHeatmapDateKey);
      if (match) return match;
    }
    // Fallback to today
    for (const week of oneMonthData.weeks) {
      const match = week.days.find((d) => d.isToday);
      if (match) return match;
    }
    return oneMonthData.weeks[oneMonthData.weeks.length - 1]?.days[0] || null;
  }, [oneMonthData, selectedHeatmapDateKey]);

  const weekdayHeaders = useMemo(() => {
    return getDayNames(settings.weekStart, true, language);
  }, [settings.weekStart, language]);

  return (
    <div className="space-y-4 pb-24 animate-fade-in">
      {/* KPI Cards Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
        <div className="p-4 bg-gradient-to-br from-emerald-50 to-white dark:from-emerald-950/35 dark:to-slate-900 rounded-2xl border border-emerald-200/70 dark:border-emerald-900/60 shadow-sm">
          <span className="text-xs font-semibold text-slate-500 dark:text-slate-400 block">
            {t('stats.todayCompletion')}
          </span>
          <div className="text-2xl font-extrabold text-emerald-600 dark:text-emerald-400 mt-1 tabular-nums">
            {overallStats.todayRate}%
          </div>
          <span className="text-[11px] text-slate-400 mt-0.5 block">
            {t('stats.dailyPace')}
          </span>
        </div>

        <div className="p-4 bg-gradient-to-br from-sky-50 to-white dark:from-sky-950/35 dark:to-slate-900 rounded-2xl border border-sky-200/70 dark:border-sky-900/60 shadow-sm">
          <span className="text-xs font-semibold text-slate-500 dark:text-slate-400 block">
            This Week
          </span>
          <div className="text-2xl font-extrabold text-blue-600 dark:text-blue-400 mt-1 tabular-nums">
            {overallStats.weekRate}%
          </div>
          <span className="text-[11px] text-slate-400 mt-0.5 block">
            Weekly average
          </span>
        </div>

        <div className="p-4 bg-gradient-to-br from-violet-50 to-white dark:from-violet-950/35 dark:to-slate-900 rounded-2xl border border-violet-200/70 dark:border-violet-900/60 shadow-sm">
          <span className="text-xs font-semibold text-slate-500 dark:text-slate-400 block">
            This Month
          </span>
          <div className="text-2xl font-extrabold text-indigo-600 dark:text-indigo-400 mt-1 tabular-nums">
            {overallStats.monthRate}%
          </div>
          <span className="text-[11px] text-slate-400 mt-0.5 block">
            Monthly consistency
          </span>
        </div>

        <div className="p-4 bg-gradient-to-br from-amber-50 to-white dark:from-amber-950/35 dark:to-slate-900 rounded-2xl border border-amber-200/70 dark:border-amber-900/60 shadow-sm">
          <span className="text-xs font-semibold text-slate-500 dark:text-slate-400 block">
            Longest Streak
          </span>
          <div className="flex items-center gap-1 text-2xl font-extrabold text-amber-500 mt-1 tabular-nums">
            <Flame className="w-5 h-5 fill-amber-500 text-amber-500" />
            <span>{overallStats.maxBestStreak} days</span>
          </div>
          <span className="text-[11px] text-slate-400 mt-0.5 block">
            Personal best record
          </span>
        </div>

        <div className="p-4 bg-gradient-to-br from-blue-50 to-white dark:from-blue-950/35 dark:to-slate-900 rounded-2xl border border-blue-200/70 dark:border-blue-900/60 shadow-sm">
          <span className="text-xs font-semibold text-slate-500 dark:text-slate-400 block">
            Total Habits
          </span>
          <div className="text-2xl font-extrabold text-slate-900 dark:text-white mt-1 tabular-nums">
            {overallStats.totalHabits}
          </div>
          <span className="text-[11px] text-slate-400 mt-0.5 block">
            Currently active
          </span>
        </div>

        <div className="p-4 bg-gradient-to-br from-rose-50 to-white dark:from-rose-950/35 dark:to-slate-900 rounded-2xl border border-rose-200/70 dark:border-rose-900/60 shadow-sm">
          <span className="text-xs font-semibold text-slate-500 dark:text-slate-400 block">
            Total Completions
          </span>
          <div className="text-2xl font-extrabold text-teal-600 dark:text-teal-400 mt-1 tabular-nums">
            {overallStats.totalCompletionsCount}
          </div>
          <span className="text-[11px] text-slate-400 mt-0.5 block">
            Lifetime check-ins
          </span>
        </div>
      </div>

      {/* Weekly Progress Bar Chart */}
      <div className="bg-white dark:bg-slate-900 rounded-3xl p-5 border border-slate-200/90 dark:border-slate-800 shadow-sm">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h3 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
              <BarChart3 className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
              <span>{t('stats.weeklyChart')}</span>
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              {t('stats.weeklyChartText')}
            </p>
          </div>
        </div>

        <div className="space-y-3">
          {weeklyData.map((d, idx) => (
            <div key={idx} className="flex items-center gap-3">
              <span
                className={`w-9 text-xs font-semibold tabular-nums ${
                  d.isToday
                    ? 'text-emerald-600 dark:text-emerald-400 font-bold'
                    : 'text-slate-600 dark:text-slate-400'
                }`}
              >
                {d.dayName}
              </span>

              {/* Progress Bar Container */}
              <div className="flex-1 bg-slate-100 dark:bg-slate-800 h-6 rounded-xl overflow-hidden p-0.5 flex items-center">
                <div
                  className={`h-full rounded-lg transition-all duration-500 flex items-center justify-end px-2 ${
                    d.percentage > 0 ? `${weeklyBarColors[idx % weeklyBarColors.length]} text-white` : 'bg-transparent text-transparent'
                  } ${d.isToday ? 'ring-2 ring-white/70' : ''}`}
                  style={{ width: `${Math.max(d.percentage, 8)}%` }}
                >
                  {d.percentage > 0 && (
                    <span className="text-[10px] font-bold tabular-nums">
                      {d.percentage}%
                    </span>
                  )}
                </div>
              </div>

              <span className="w-12 text-right text-xs font-medium text-slate-500 dark:text-slate-400 tabular-nums">
                {d.completed}/{d.total}
              </span>
            </div>
          ))}
        </div>
      </div>

      {/* Monthly Statistics Summary (PRD Section 13) */}
      <div className="bg-white dark:bg-slate-900 rounded-3xl p-5 border border-slate-200/90 dark:border-slate-800 shadow-sm">
        <h3 className="text-sm font-bold text-slate-900 dark:text-white mb-3">
          {t('stats.monthlyOverview', { month: formatMonthYear(today, language) })}
        </h3>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-center">
          <div className="p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/50">
            <span className="text-[11px] font-medium text-slate-500 dark:text-slate-400">
              Completion Rate
            </span>
            <div className="text-xl font-bold text-emerald-600 dark:text-emerald-400 mt-1 tabular-nums">
              {overallStats.monthRate}%
            </div>
          </div>

          <div className="p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/50">
            <span className="text-[11px] font-medium text-slate-500 dark:text-slate-400">
              Completed Habits
            </span>
            <div className="text-xl font-bold text-slate-900 dark:text-white mt-1 tabular-nums">
              {overallStats.monthCompleted}
            </div>
          </div>

          <div className="p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/50">
            <span className="text-[11px] font-medium text-slate-500 dark:text-slate-400">
              Missed Habits
            </span>
            <div className="text-xl font-bold text-slate-500 dark:text-slate-400 mt-1 tabular-nums">
              {overallStats.monthMissed}
            </div>
          </div>

          <div className="p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/50">
            <span className="text-[11px] font-medium text-slate-500 dark:text-slate-400">
              Best Performing
            </span>
            <div className="text-xs font-bold text-slate-900 dark:text-white mt-1 truncate">
              {overallStats.bestHabitName}
            </div>
          </div>
        </div>
      </div>

      {/* Habit Heatmap (1 Month / 4 Weeks - PRD Section 14) */}
      <div className="bg-white dark:bg-slate-900 rounded-3xl p-4 sm:p-5 border border-slate-200/90 dark:border-slate-800 shadow-sm overflow-hidden">
        {/* Heatmap Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2.5 mb-4">
          <div>
            <div className="flex items-center gap-2">
              <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                {t('stats.heatmap')}
              </h3>
              <span className="text-[11px] font-semibold text-emerald-700 dark:text-emerald-300 bg-emerald-50 dark:bg-emerald-950/60 px-2 py-0.5 rounded-full border border-emerald-200 dark:border-emerald-800">
                1 Month
              </span>
            </div>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
              {t('stats.heatmapText')}
            </p>
          </div>

          {/* Quick 1-Month Stats Badges */}
          <div className="flex items-center gap-2 flex-wrap">
            <span className="text-[11px] font-medium px-2 py-1 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300">
              Avg: <strong className="text-emerald-600 dark:text-emerald-400 tabular-nums">{oneMonthData.overall1MConsistency}%</strong>
            </span>
            <span className="text-[11px] font-medium px-2 py-1 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300">
              Active: <strong className="text-amber-500 tabular-nums">{oneMonthData.daysWithCompletion1M}d</strong>
            </span>
            <span className="text-[11px] font-medium px-2 py-1 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300">
              100%: <strong className="text-emerald-500 tabular-nums">{oneMonthData.perfectDays1M}d</strong>
            </span>
          </div>
        </div>

        {/* 1-Month Heatmap Grid (4 Weeks) */}
        <div className="overflow-x-auto pb-2">
          <div className="min-w-[280px]">
            {/* Week Column Headers (4 Weeks) */}
            <div className="heatmap-grid-columns grid grid-cols-5 gap-1.5 mb-1.5 text-center items-center">
              {/* Corner spacer for weekday labels */}
              <div className="heatmap-column-label text-[10px] font-bold text-slate-400 text-left pl-1">
                Day
              </div>
              {oneMonthData.weeks.map((week) => (
                <div
                  key={week.weekIndex}
                  className={`heatmap-column-label text-[10px] font-bold tracking-tight truncate ${
                    week.isCurrentWeek
                      ? 'text-emerald-600 dark:text-emerald-400 font-extrabold'
                      : 'text-slate-400 dark:text-slate-500'
                  }`}
                >
                  {week.weekLabel}
                </div>
              ))}
            </div>

            {/* 7 Rows for each day of the week */}
            <div className="space-y-1.5">
              {[0, 1, 2, 3, 4, 5, 6].map((dayIndex) => {
                const dayName = weekdayHeaders[dayIndex] || '';

                return (
                  <div key={dayIndex} className="heatmap-grid-columns grid grid-cols-5 gap-1.5 items-center">
                    {/* Weekday Row Header */}
                    <div className="heatmap-column-label text-[11px] font-semibold text-slate-400 dark:text-slate-500 pl-1 text-left">
                      {dayName}
                    </div>

                    {/* 4 Week Cells for this day */}
                    {oneMonthData.weeks.map((week) => {
                      const day = week.days[dayIndex];
                      if (!day) return <div key={week.weekIndex} />;

                      const isSelected = inspectedDay?.dateKey === day.dateKey;

                      // Cell background styling based on intensity
                      let cellStyle = '';
                      if (day.isFuture) {
                        cellStyle =
                          'bg-slate-100/40 dark:bg-slate-800/20 border border-dashed border-slate-200 dark:border-slate-800 text-slate-300 dark:text-slate-700 cursor-not-allowed';
                      } else if (day.intensity === 4) {
                        cellStyle =
                          'bg-emerald-600 text-white dark:bg-emerald-500 shadow-xs font-bold';
                      } else if (day.intensity === 3) {
                        cellStyle =
                          'bg-sky-500 text-white dark:bg-sky-600 font-semibold';
                      } else if (day.intensity === 2) {
                        cellStyle =
                          'bg-amber-300 text-amber-950 dark:bg-amber-700 dark:text-amber-100 font-medium';
                      } else if (day.intensity === 1) {
                        cellStyle =
                          'bg-rose-100 text-rose-900 dark:bg-rose-950 dark:text-rose-300 border border-rose-200/70 dark:border-rose-800/50';
                      } else {
                        // intensity === 0
                        if (day.totalCount > 0) {
                          // Scheduled but 0 completed -> missed
                          cellStyle =
                            'bg-red-50 dark:bg-red-950/30 text-red-400 border border-red-200/70 dark:border-red-900/40';
                        } else {
                          // Rest day / no habits scheduled
                          cellStyle =
                            'bg-slate-100 dark:bg-slate-800/60 text-slate-400 dark:text-slate-500 border border-slate-200/60 dark:border-slate-700/60';
                        }
                      }

                      return (
                        <button
                          key={day.dateKey}
                          type="button"
                          onClick={() => {
                            if (!day.isFuture) {
                              setSelectedHeatmapDateKey(day.dateKey);
                            }
                          }}
                          disabled={day.isFuture}
                          title={`${day.dateKey}: ${day.completedCount}/${day.totalCount} completed (${day.percentage}%)`}
                          className={`heatmap-cell h-7 sm:h-8 rounded-lg flex flex-col items-center justify-center text-[10px] transition-all relative ${cellStyle} ${
                            isSelected
                              ? 'heatmap-cell-selected'
                              : day.isToday
                              ? 'heatmap-cell-today'
                              : ''
                          }`}
                        >
                          <span className="tabular-nums leading-none">{day.date.getDate()}</span>
                        </button>
                      );
                    })}
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Legend */}
        <div className="flex items-center justify-between pt-3 border-t border-slate-100 dark:border-slate-800 text-[10px] text-slate-500 dark:text-slate-400 flex-wrap gap-2">
          <span>{t('stats.consistency')}</span>
          <div className="flex items-center gap-1.5 flex-wrap">
            <div className="flex items-center gap-1">
              <span className="w-2.5 h-2.5 rounded-xs bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700" />
              <span>0%</span>
            </div>
            <div className="flex items-center gap-1">
              <span className="w-2.5 h-2.5 rounded-xs bg-rose-100 dark:bg-rose-950" />
              <span>1-33%</span>
            </div>
            <div className="flex items-center gap-1">
              <span className="w-2.5 h-2.5 rounded-xs bg-amber-300 dark:bg-amber-700" />
              <span>34-66%</span>
            </div>
            <div className="flex items-center gap-1">
              <span className="w-2.5 h-2.5 rounded-xs bg-sky-500" />
              <span>67-99%</span>
            </div>
            <div className="flex items-center gap-1">
              <span className="w-2.5 h-2.5 rounded-xs bg-emerald-600 dark:bg-emerald-500" />
              <span>100%</span>
            </div>
          </div>
        </div>

        {/* Day Inspector Card */}
        {inspectedDay && (
          <div className="mt-3.5 p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200/80 dark:border-slate-800 animate-fade-in">
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-2">
                <CalendarIcon className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
                <span className="text-xs font-bold text-slate-900 dark:text-white">
                  {formatDisplayDate(inspectedDay.date, language)}
                </span>
                {inspectedDay.isToday && (
                  <span className="text-[10px] font-bold text-emerald-700 dark:text-emerald-300 bg-emerald-100 dark:bg-emerald-950 px-2 py-0.5 rounded-full">
                    Today
                  </span>
                )}
              </div>

              <span className="text-xs font-bold text-emerald-600 dark:text-emerald-400 tabular-nums">
                {inspectedDay.completedCount} / {inspectedDay.totalCount} {t('stats.completed')} ({inspectedDay.percentage}%)
              </span>
            </div>

            {/* List of habits for inspected day */}
            {inspectedDay.scheduledHabits.length > 0 ? (
              <div className="space-y-1.5 mt-2">
                <div className="text-[10px] text-slate-400 dark:text-slate-500 font-medium">
                  Tap any habit to toggle completion for this day:
                </div>
                <div className="flex flex-wrap gap-1.5">
                  {inspectedDay.scheduledHabits.map((habit) => {
                    const isDone = inspectedDay.completedHabitIds.includes(habit.id);
                    return (
                      <button
                        type="button"
                        key={habit.id}
                        onClick={() => toggleHabitCompletion(habit.id, inspectedDay.dateKey)}
                        title={`Click to mark ${habit.name} as ${isDone ? 'incomplete' : 'complete'}`}
                        className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-xl text-[11px] font-medium transition-all hover:scale-105 active:scale-95 cursor-pointer ${
                          isDone
                            ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300 border border-emerald-300/40 dark:border-emerald-800/40 shadow-xs'
                            : 'bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-400 border border-slate-200 dark:border-slate-700 hover:border-emerald-400 dark:hover:border-emerald-600'
                        }`}
                      >
                        <DynamicIcon name={habit.icon} className="w-3.5 h-3.5 shrink-0" />
                        {isDone ? (
                          <Check className="w-3 h-3 text-emerald-600 dark:text-emerald-400 stroke-[3]" />
                        ) : (
                          <span className="w-2 h-2 rounded-full border border-slate-400 dark:border-slate-500" />
                        )}
                        <span>{habit.name}</span>
                      </button>
                    );
                  })}
                </div>
              </div>
            ) : (
              <p className="text-xs text-slate-400 mt-1">
                {t('stats.noHabitsDateSimple')}
              </p>
            )}
          </div>
        )}
      </div>

      {/* Individual Habit Streaks Ranking */}
      <div className="bg-white dark:bg-slate-900 rounded-3xl p-5 border border-slate-200/90 dark:border-slate-800 shadow-sm">
        <h3 className="text-sm font-bold text-slate-900 dark:text-white mb-3">
          {t('stats.ranking')}
        </h3>

        <div className="space-y-2.5">
          {activeHabits
            .map((h) => ({
              habit: h,
              stats: calculateHabitStats(h, completions, today),
              colorConfig: COLOR_OPTIONS.find((c) => c.id === h.color) || COLOR_OPTIONS[0],
            }))
            .sort((a, b) => b.stats.currentStreak - a.stats.currentStreak)
            .map(({ habit, stats, colorConfig }, i) => (
              <div
                key={habit.id}
                className="flex items-center justify-between p-3 rounded-xl bg-slate-50 dark:bg-slate-800/50 border border-slate-100 dark:border-slate-800"
              >
                <div className="flex items-center gap-3 min-w-0 flex-1">
                  <span className="text-xs font-bold text-slate-400 w-4">
                    #{i + 1}
                  </span>
                  <div
                    className={`w-8 h-8 rounded-lg flex items-center justify-center shrink-0 ${colorConfig.lightBg} ${colorConfig.text}`}
                  >
                    <DynamicIcon name={habit.icon} className="w-4 h-4 stroke-[2]" />
                  </div>
                  <div className="min-w-0 flex-1">
                    <h4 className="text-xs font-semibold text-slate-900 dark:text-white truncate">
                      {habit.name}
                    </h4>
                    <p className="text-[10px] text-slate-500">
                      {habit.category} · {stats.completionRate}% rate
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-1 font-bold text-xs text-amber-500 tabular-nums shrink-0">
                  <Flame className="w-3.5 h-3.5 fill-amber-500 text-amber-500" />
                  <span>{stats.currentStreak} d</span>
                </div>
              </div>
            ))}
        </div>
      </div>
    </div>
  );
};
