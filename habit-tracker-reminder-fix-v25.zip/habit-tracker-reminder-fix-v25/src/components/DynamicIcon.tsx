import React from 'react';
import {
  Droplet,
  GlassWater,
  Dumbbell,
  BookOpen,
  Book,
  Bookmark,
  Brain,
  BrainCircuit,
  Moon,
  Heart,
  HeartPulse,
  Apple,
  Salad,
  Carrot,
  Briefcase,
  Code,
  PenTool,
  Pencil,
  FileText,
  Newspaper,
  Mic,
  Library,
  Flame,
  Footprints,
  Target,
  Sparkles,
  Smile,
  Music,
  Headphones,
  Pill,
  Stethoscope,
  Bike,
  Timer,
  Activity,
  Trophy,
  Medal,
  Mountain,
  Compass,
  Coffee,
  Utensils,
  UtensilsCrossed,
  Sun,
  Sunrise,
  Sunset,
  CloudSun,
  Wind,
  Eye,
  Ear,
  BatteryCharging,
  Feather,
  GraduationCap,
  Languages,
  CheckSquare,
  ListTodo,
  Lightbulb,
  Palette,
  Camera,
  DollarSign,
  PiggyBank,
  Wallet,
  CreditCard,
  TrendingUp,
  Receipt,
  Coins,
  Home,
  Leaf,
  Trees,
  Bath,
  ShowerHead,
  Scale,
  CigaretteOff,
  WineOff,
  Shield,
  ShieldCheck,
  Bed,
  Zap,
  Rocket,
  Focus,
  Inbox,
  Send,
  PhoneOff,
  BellOff,
  Terminal,
  Puzzle,
  Dog,
  Cat,
  Users,
  MessageCircle,
  Gift,
  Car,
  Hammer,
  Wrench,
  Shirt,
  Check,
  CheckCircle2,
  Calendar,
  BarChart3,
  Settings,
  Bell,
  Plus,
  ArrowLeft,
  ChevronLeft,
  ChevronRight,
  Archive,
  Trash2,
  Edit2,
  Clock,
  Moon as DarkMoon,
  Laptop,
  Download,
  Upload,
  RotateCcw,
  X,
  Search,
  Play,
  Pause,
  Quote,
  Smartphone,
  LucideProps,
} from 'lucide-react';

interface DynamicIconProps extends LucideProps {
  name: string;
}

export const DynamicIcon: React.FC<DynamicIconProps> = ({ name, ...props }) => {
  switch (name.toLowerCase()) {
    // Health & Hydration
    case 'droplet':
    case 'water':
      return <Droplet {...props} />;
    case 'glass-water':
    case 'glasswater':
      return <GlassWater {...props} />;
    case 'heart':
    case 'health':
      return <Heart {...props} />;
    case 'heart-pulse':
    case 'heartpulse':
    case 'pulse':
      return <HeartPulse {...props} />;
    case 'pill':
    case 'vitamins':
    case 'medicine':
      return <Pill {...props} />;
    case 'stethoscope':
    case 'checkup':
      return <Stethoscope {...props} />;
    case 'bath':
    case 'hygiene':
      return <Bath {...props} />;
    case 'shower-head':
    case 'showerhead':
    case 'shower':
      return <ShowerHead {...props} />;
    case 'sun':
    case 'morning':
    case 'sunlight':
      return <Sun {...props} />;
    case 'sunrise':
      return <Sunrise {...props} />;
    case 'sunset':
      return <Sunset {...props} />;
    case 'moon':
    case 'sleep':
      return <Moon {...props} />;
    case 'bed':
    case 'rest':
      return <Bed {...props} />;
    case 'scale':
    case 'weight':
      return <Scale {...props} />;
    case 'cigarette-off':
    case 'cigaretteoff':
    case 'quitsmoking':
      return <CigaretteOff {...props} />;
    case 'wine-off':
    case 'wineoff':
    case 'sober':
      return <WineOff {...props} />;

    // Fitness & Sports
    case 'dumbbell':
    case 'exercise':
    case 'fitness':
    case 'gym':
      return <Dumbbell {...props} />;
    case 'footprints':
    case 'walking':
    case 'steps':
      return <Footprints {...props} />;
    case 'bike':
    case 'cycling':
      return <Bike {...props} />;
    case 'timer':
    case 'hiit':
    case 'plank':
      return <Timer {...props} />;
    case 'activity':
    case 'cardio':
      return <Activity {...props} />;
    case 'trophy':
    case 'sports':
    case 'challenge':
      return <Trophy {...props} />;
    case 'medal':
    case 'award':
      return <Medal {...props} />;
    case 'mountain':
    case 'hiking':
      return <Mountain {...props} />;
    case 'compass':
    case 'outdoors':
      return <Compass {...props} />;

    // Nutrition & Food
    case 'apple':
    case 'nutrition':
    case 'diet':
      return <Apple {...props} />;
    case 'salad':
      return <Salad {...props} />;
    case 'carrot':
    case 'vegetables':
      return <Carrot {...props} />;
    case 'utensils':
    case 'meals':
      return <Utensils {...props} />;
    case 'utensils-crossed':
    case 'utensilscrossed':
    case 'cooking':
      return <UtensilsCrossed {...props} />;
    case 'coffee':
    case 'tea':
    case 'break':
      return <Coffee {...props} />;

    // Mind & Wellness
    case 'brain':
    case 'meditation':
      return <Brain {...props} />;
    case 'feather':
    case 'peace':
    case 'calm':
      return <Feather {...props} />;
    case 'smile':
    case 'gratitude':
    case 'happiness':
      return <Smile {...props} />;
    case 'wind':
    case 'breathing':
      return <Wind {...props} />;
    case 'eye':
    case 'screenbreak':
      return <Eye {...props} />;
    case 'ear':
    case 'listening':
      return <Ear {...props} />;
    case 'battery-charging':
    case 'batterycharging':
    case 'recharge':
      return <BatteryCharging {...props} />;
    case 'cloud-sun':
    case 'cloudsun':
      return <CloudSun {...props} />;
    case 'sparkles':
    case 'selfcare':
    case 'skincare':
      return <Sparkles {...props} />;

    // Learning, Books & Creativity
    case 'book-open':
    case 'bookopen':
    case 'reading':
      return <BookOpen {...props} />;
    case 'book':
      return <Book {...props} />;
    case 'bookmark':
      return <Bookmark {...props} />;
    case 'graduation-cap':
    case 'graduationcap':
    case 'course':
    case 'study':
      return <GraduationCap {...props} />;
    case 'languages':
    case 'vocab':
      return <Languages {...props} />;
    case 'pen-tool':
    case 'pentool':
    case 'journal':
      return <PenTool {...props} />;
    case 'pencil':
    case 'notes':
      return <Pencil {...props} />;
    case 'file-text':
    case 'filetext':
      return <FileText {...props} />;
    case 'newspaper':
    case 'news':
      return <Newspaper {...props} />;
    case 'mic':
    case 'podcast':
      return <Mic {...props} />;
    case 'library':
      return <Library {...props} />;
    case 'brain-circuit':
    case 'braincircuit':
    case 'logic':
      return <BrainCircuit {...props} />;
    case 'puzzle':
      return <Puzzle {...props} />;
    case 'lightbulb':
    case 'ideas':
    case 'creative':
      return <Lightbulb {...props} />;

    // Work & Productivity
    case 'briefcase':
    case 'work':
    case 'job':
      return <Briefcase {...props} />;
    case 'laptop':
    case 'computer':
      return <Laptop {...props} />;
    case 'code':
    case 'coding':
    case 'programming':
      return <Code {...props} />;
    case 'terminal':
      return <Terminal {...props} />;
    case 'check-square':
    case 'checksquare':
    case 'tasks':
      return <CheckSquare {...props} />;
    case 'list-todo':
    case 'listtodo':
    case 'todo':
      return <ListTodo {...props} />;
    case 'target':
    case 'goal':
      return <Target {...props} />;
    case 'clock':
    case 'pomodoro':
      return <Clock {...props} />;
    case 'calendar':
      return <Calendar {...props} />;
    case 'inbox':
      return <Inbox {...props} />;
    case 'send':
    case 'email':
      return <Send {...props} />;
    case 'phone-off':
    case 'phoneoff':
    case 'detox':
      return <PhoneOff {...props} />;
    case 'bell-off':
    case 'belloff':
    case 'dnd':
      return <BellOff {...props} />;
    case 'focus':
      return <Focus {...props} />;
    case 'rocket':
    case 'launch':
      return <Rocket {...props} />;
    case 'zap':
    case 'energy':
      return <Zap {...props} />;
    case 'flame':
    case 'streak':
      return <Flame {...props} />;
    case 'shield':
    case 'discipline':
      return <Shield {...props} />;
    case 'shield-check':
    case 'shieldcheck':
      return <ShieldCheck {...props} />;

    // Finance & Money
    case 'dollar-sign':
    case 'dollarsign':
    case 'money':
    case 'budget':
      return <DollarSign {...props} />;
    case 'piggy-bank':
    case 'piggybank':
    case 'saving':
      return <PiggyBank {...props} />;
    case 'wallet':
      return <Wallet {...props} />;
    case 'credit-card':
    case 'creditcard':
      return <CreditCard {...props} />;
    case 'trending-up':
    case 'trendingup':
    case 'investing':
      return <TrendingUp {...props} />;
    case 'receipt':
    case 'bills':
      return <Receipt {...props} />;
    case 'coins':
      return <Coins {...props} />;

    // Home, Lifestyle & Hobbies
    case 'home':
    case 'chores':
      return <Home {...props} />;
    case 'leaf':
    case 'plants':
      return <Leaf {...props} />;
    case 'trees':
    case 'garden':
      return <Trees {...props} />;
    case 'music':
      return <Music {...props} />;
    case 'headphones':
    case 'audio':
      return <Headphones {...props} />;
    case 'palette':
    case 'art':
    case 'drawing':
      return <Palette {...props} />;
    case 'camera':
    case 'photo':
      return <Camera {...props} />;
    case 'dog':
    case 'pet':
      return <Dog {...props} />;
    case 'cat':
      return <Cat {...props} />;
    case 'users':
    case 'family':
      return <Users {...props} />;
    case 'message-circle':
    case 'messagecircle':
    case 'social':
      return <MessageCircle {...props} />;
    case 'gift':
    case 'kindness':
      return <Gift {...props} />;
    case 'car':
      return <Car {...props} />;
    case 'hammer':
    case 'craft':
      return <Hammer {...props} />;
    case 'wrench':
    case 'fix':
      return <Wrench {...props} />;
    case 'shirt':
    case 'laundry':
      return <Shirt {...props} />;

    default:
      return <Sparkles {...props} />;
  }
};

export {
  Check,
  CheckCircle2,
  Calendar,
  BarChart3,
  Settings,
  Bell,
  Plus,
  ArrowLeft,
  ChevronLeft,
  ChevronRight,
  Archive,
  Trash2,
  Edit2,
  Clock,
  Sun,
  DarkMoon,
  Laptop,
  Download,
  Upload,
  RotateCcw,
  ShieldCheck,
  X,
  Flame,
  Target,
  Sparkles,
  Search,
  Timer,
  Trophy,
  Medal,
  FileText,
  Play,
  Pause,
  Quote,
  Smartphone,
};
