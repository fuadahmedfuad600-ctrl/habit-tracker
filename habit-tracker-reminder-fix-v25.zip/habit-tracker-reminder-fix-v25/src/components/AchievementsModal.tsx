import React from 'react';
import { useHabit } from '../context/HabitContext';
import { calculateHabitStats, getDailyProgress } from '../utils/streak';
import { Trophy, Medal, X, Flame, Check, Sparkles, Target } from './DynamicIcon';
import { getTodayKey } from '../utils/date';

interface AchievementsModalProps {
  onClose: () => void;
}

interface Achievement {
  id: string;
  title: string;
  description: string;
  icon: string;
  unlocked: boolean;
  progressText: string;
  progressPercent: number;
}

export const AchievementsModal: React.FC<AchievementsModalProps> = ({ onClose }) => {
  const { habits, completions, t } = useHabit();
  const todayKey = getTodayKey();

  // Calculate stats for achievements
  const totalCompletions = completions.filter((c) => c.completed).length;
  const maxStreak = habits.reduce((max, h) => {
    const s = calculateHabitStats(h, completions);
    return Math.max(max, s.bestStreak, s.currentStreak);
  }, 0);

  const todayProgress = getDailyProgress(habits, completions, new Date());
  const isFlawlessDay = todayProgress.totalCount > 0 && todayProgress.completedCount === todayProgress.totalCount;

  const achievements: Achievement[] = [
    {
      id: 'first_step',
      title: t('achievement.firstStep'),
      description: t('achievement.firstStepDesc'),
      icon: '🚀',
      unlocked: totalCompletions >= 1,
      progressText: `${Math.min(totalCompletions, 1)} / 1`,
      progressPercent: totalCompletions >= 1 ? 100 : 0,
    },
    {
      id: 'streak_3',
      title: t('achievement.streak3'),
      description: t('achievement.streak3Desc'),
      icon: '🔥',
      unlocked: maxStreak >= 3,
      progressText: `${Math.min(maxStreak, 3)} / 3 ${t('achievement.days')}`,
      progressPercent: Math.min(100, Math.round((maxStreak / 3) * 100)),
    },
    {
      id: 'streak_7',
      title: t('achievement.streak7'),
      description: t('achievement.streak7Desc'),
      icon: '⚡',
      unlocked: maxStreak >= 7,
      progressText: `${Math.min(maxStreak, 7)} / 7 ${t('achievement.days')}`,
      progressPercent: Math.min(100, Math.round((maxStreak / 7) * 100)),
    },
    {
      id: 'streak_21',
      title: t('achievement.streak21'),
      description: t('achievement.streak21Desc'),
      icon: '👑',
      unlocked: maxStreak >= 21,
      progressText: `${Math.min(maxStreak, 21)} / 21 ${t('achievement.days')}`,
      progressPercent: Math.min(100, Math.round((maxStreak / 21) * 100)),
    },
    {
      id: 'flawless_day',
      title: t('achievement.flawless'),
      description: t('achievement.flawlessDesc'),
      icon: '🌟',
      unlocked: isFlawlessDay,
      progressText: isFlawlessDay ? t('achievement.achieved') : `${todayProgress.completedCount}/${todayProgress.totalCount} ${t('achievement.today')}`,
      progressPercent: todayProgress.percentage,
    },
    {
      id: 'centurion',
      title: t('achievement.centurion'),
      description: t('achievement.centurionDesc'),
      icon: '💯',
      unlocked: totalCompletions >= 100,
      progressText: `${Math.min(totalCompletions, 100)} / 100 ${t('achievement.checkIns')}`,
      progressPercent: Math.min(100, Math.round((totalCompletions / 100) * 100)),
    },
    {
      id: 'multi_tasker',
      title: t('achievement.multi'),
      description: t('achievement.multiDesc'),
      icon: '🎯',
      unlocked: habits.length >= 4,
      progressText: `${Math.min(habits.length, 4)} / 4 ${t('achievement.habits')}`,
      progressPercent: Math.min(100, Math.round((habits.length / 4) * 100)),
    },
    {
      id: 'ten_checkins',
      title: t('achievement.decathlon'),
      description: t('achievement.decathlonDesc'),
      icon: '🏆',
      unlocked: totalCompletions >= 10,
      progressText: `${Math.min(totalCompletions, 10)} / 10 ${t('achievement.checkIns')}`,
      progressPercent: Math.min(100, Math.round((totalCompletions / 10) * 100)),
    },
  ];

  const unlockedCount = achievements.filter((a) => a.unlocked).length;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 overlay-center-safe bg-slate-950/70 backdrop-blur-sm animate-fade-in">
      <div className="bg-white dark:bg-slate-900 w-full max-w-lg rounded-3xl shadow-2xl border-2 border-slate-200 dark:border-slate-800 p-6 flex flex-col dialog-safe max-h-[85vh] overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-slate-100 dark:border-slate-800">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-amber-500/10 text-amber-500 flex items-center justify-center">
              <Trophy className="w-6 h-6 fill-amber-500" />
            </div>
            <div>
              <h2 className="text-base font-bold text-slate-900 dark:text-white">
                {t('achievement.title')}
              </h2>
              <p className="text-xs text-slate-400">
                {t('achievement.unlockedOf', { count: unlockedCount, total: achievements.length })}
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full flex items-center justify-center text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Progress Bar Header */}
        <div className="py-3">
          <div className="flex items-center justify-between text-xs font-semibold mb-1">
            <span className="text-slate-600 dark:text-slate-400">{t('achievement.overall')}</span>
            <span className="text-amber-600 dark:text-amber-400">
              {Math.round((unlockedCount / achievements.length) * 100)}%
            </span>
          </div>
          <div className="w-full bg-slate-100 dark:bg-slate-800 h-2.5 rounded-full overflow-hidden">
            <div
              className="bg-amber-500 h-full rounded-full transition-all duration-500"
              style={{ width: `${(unlockedCount / achievements.length) * 100}%` }}
            />
          </div>
        </div>

        {/* Achievements List */}
        <div className="overflow-y-auto space-y-2.5 pr-1 py-1 flex-1">
          {achievements.map((item) => (
            <div
              key={item.id}
              className={`p-3.5 rounded-2xl border-2 transition-all flex items-center justify-between gap-3 ${
                item.unlocked
                  ? 'border-amber-400/70 bg-amber-50/60 dark:bg-amber-950/30 text-slate-900 dark:text-white shadow-xs'
                  : 'border-slate-200 dark:border-slate-800/80 bg-slate-50/40 dark:bg-slate-800/30 opacity-70'
              }`}
            >
              <div className="flex items-center gap-3 min-w-0 flex-1">
                <span className="text-2xl shrink-0">{item.icon}</span>
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-1.5">
                    <h3 className="text-xs font-bold text-slate-900 dark:text-white truncate">
                      {item.title}
                    </h3>
                    {item.unlocked && (
                      <span className="text-[10px] font-extrabold text-amber-700 dark:text-amber-300 bg-amber-100 dark:bg-amber-900/60 px-1.5 py-0.2 rounded-md">
                        {t('achievement.unlocked')}
                      </span>
                    )}
                  </div>
                  <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5 truncate">
                    {item.description}
                  </p>
                </div>
              </div>

              {/* Progress pill */}
              <div className="text-right shrink-0">
                <span className="text-[11px] font-bold tabular-nums text-slate-600 dark:text-slate-300 block">
                  {item.progressText}
                </span>
                <div className="w-16 bg-slate-200 dark:bg-slate-700 h-1.5 rounded-full overflow-hidden mt-1">
                  <div
                    className={`h-full rounded-full ${
                      item.unlocked ? 'bg-amber-500' : 'bg-slate-400'
                    }`}
                    style={{ width: `${item.progressPercent}%` }}
                  />
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
