import React from 'react';
import { useHabit } from '../context/HabitContext';
import { ThemeMode, WeekStartDay } from '../types';
import { LANGUAGE_OPTIONS } from '../utils/i18n';
import { getNotificationPermission, isNativeAndroid } from '../utils/notifications';
import { Sun, DarkMoon, Laptop, ShieldCheck } from './DynamicIcon';

export const SettingsView: React.FC = () => {
  const {
    settings,
    updateSettings,
    requestNotifications,
    t,
    language,
  } = useHabit();

  const permission = getNotificationPermission();

  const handleNotificationToggle = async (enabled: boolean) => {
    if (enabled && permission !== 'granted' && !isNativeAndroid()) {
      const result = await requestNotifications();
      if (result === 'granted') updateSettings({ notificationsEnabled: true });
      return;
    }

    if (enabled) {
      const result = await requestNotifications();
      if (result === 'granted') updateSettings({ notificationsEnabled: true });
      return;
    }

    updateSettings({ notificationsEnabled: false });
  };

  const themeOptions: { id: ThemeMode; label: string; icon: React.ComponentType<{ className?: string }> }[] = [
    { id: 'light', label: t('settings.light'), icon: Sun },
    { id: 'dark', label: t('settings.dark'), icon: DarkMoon },
    { id: 'system', label: t('settings.system'), icon: Laptop },
  ];

  const weekOptions: { id: WeekStartDay; label: string }[] = [
    { id: 'saturday', label: t('settings.saturday') },
    { id: 'sunday', label: t('settings.sunday') },
    { id: 'monday', label: t('settings.monday') },
  ];

  return (
    <div className="space-y-4 pb-24 animate-fade-in">
      {/* Appearance */}
      <div className="bg-white dark:bg-slate-900 rounded-3xl p-5 border border-slate-200/90 dark:border-slate-800 shadow-sm transition-all duration-200 hover:shadow-md">
        <h3 className="text-sm font-bold text-slate-900 dark:text-white mb-1">{t('settings.appearance')}</h3>
        <p className="text-xs text-slate-500 dark:text-slate-400 mb-3.5">{t('settings.appearanceText')}</p>

        <div className="grid grid-cols-3 gap-2.5">
          {themeOptions.map((item) => {
            const isSelected = settings.theme === item.id;
            const Icon = item.icon;
            return (
              <button
                key={item.id}
                onClick={() => updateSettings({ theme: item.id })}
                className={`py-3 px-3 rounded-2xl border flex flex-col items-center gap-2 transition-all duration-200 active:scale-95 ${
                  isSelected
                    ? (item.id === 'light' ? 'border-amber-400 bg-amber-50 dark:bg-amber-950/35 text-amber-800 dark:text-amber-300 ring-1 ring-amber-300 shadow-xs' : item.id === 'dark' ? 'border-violet-500 bg-violet-50 dark:bg-violet-950/40 text-violet-700 dark:text-violet-300 ring-1 ring-violet-400 shadow-xs' : 'border-sky-400 bg-sky-50 dark:bg-sky-950/35 text-sky-700 dark:text-sky-300 ring-1 ring-sky-300 shadow-xs')
                    : 'border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800'
                }`}
              >
                <Icon className="w-5 h-5" />
                <span className="text-xs font-semibold">{item.label}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Language */}
      <div className="bg-white dark:bg-slate-900 rounded-3xl p-5 border border-slate-200/90 dark:border-slate-800 shadow-sm transition-all duration-200 hover:shadow-md">
        <h3 className="text-sm font-bold text-slate-900 dark:text-white mb-1">{t('settings.language')}</h3>
        <p className="text-xs text-slate-500 dark:text-slate-400 mb-3.5">{t('settings.languageText')}</p>
        <div className="grid grid-cols-3 gap-2.5">
          {LANGUAGE_OPTIONS.map((item) => {
            const selected = language === item.id;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => updateSettings({ language: item.id })}
                className={`py-3 px-2 rounded-2xl border flex flex-col items-center gap-1.5 transition-all duration-200 active:scale-95 ${
                  selected
                    ? (item.id === 'en' ? 'border-sky-400 bg-sky-50 dark:bg-sky-950/35 text-sky-700 dark:text-sky-300 ring-1 ring-sky-300 shadow-xs' : item.id === 'bn' ? 'border-emerald-400 bg-emerald-50 dark:bg-emerald-950/35 text-emerald-700 dark:text-emerald-300 ring-1 ring-emerald-300 shadow-xs' : 'border-orange-400 bg-orange-50 dark:bg-orange-950/35 text-orange-700 dark:text-orange-300 ring-1 ring-orange-300 shadow-xs')
                    : 'border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800'
                }`}
              >
                <span className="text-sm font-bold">{item.nativeLabel}</span>
                <span className="text-[10px] text-slate-400 dark:text-slate-500">{item.label}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Notifications */}
      <div className="bg-white dark:bg-slate-900 rounded-3xl p-5 border border-slate-200/90 dark:border-slate-800 shadow-sm transition-all duration-200 hover:shadow-md">
        <h3 className="text-sm font-bold text-slate-900 dark:text-white mb-1">{t('settings.notifications')}</h3>
        <p className="text-xs text-slate-500 dark:text-slate-400 mb-3.5">{t('settings.notificationsText')}</p>

        <div className="space-y-3.5">
          <div className="flex items-center justify-between gap-3">
            <div>
              <span className="text-xs font-semibold text-slate-900 dark:text-white block">{t('settings.allowReminders')}</span>
              <span className="text-[11px] text-slate-400">{t('settings.receiveReminders')}</span>
            </div>
            <label className="relative inline-flex items-center cursor-pointer shrink-0">
              <input
                type="checkbox"
                checked={settings.notificationsEnabled}
                onChange={(e) => handleNotificationToggle(e.target.checked)}
                className="sr-only peer"
              />
              <div className="w-11 h-6 bg-slate-200 peer-focus:outline-none rounded-full peer dark:bg-slate-700 peer-checked:after:translate-x-full after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-rose-500" />
            </label>
          </div>

          <div className="flex items-center justify-between gap-3">
            <div>
              <span className="text-xs font-semibold text-slate-900 dark:text-white block">{t('settings.vibration')}</span>
              <span className="text-[11px] text-slate-400">{t('settings.vibrationText')}</span>
            </div>
            <label className="relative inline-flex items-center cursor-pointer shrink-0">
              <input
                type="checkbox"
                checked={settings.vibrationEnabled}
                onChange={(e) => updateSettings({ vibrationEnabled: e.target.checked })}
                className="sr-only peer"
                aria-label={t('settings.vibration')}
              />
              <div className="w-11 h-6 bg-slate-200 peer-focus:outline-none rounded-full peer dark:bg-slate-700 peer-checked:after:translate-x-full after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-amber-500" />
            </label>
          </div>
        </div>
      </div>

      {/* Week Start */}
      <div className="bg-white dark:bg-slate-900 rounded-3xl p-5 border border-slate-200/90 dark:border-slate-800 shadow-sm transition-all duration-200 hover:shadow-md">
        <h3 className="text-sm font-bold text-slate-900 dark:text-white mb-1">{t('settings.weekStart')}</h3>
        <p className="text-xs text-slate-500 dark:text-slate-400 mb-3.5">{t('settings.weekStartText')}</p>

        <div className="grid grid-cols-3 gap-2">
          {weekOptions.map((w) => {
            const isSelected = settings.weekStart === w.id;
            return (
              <button
                key={w.id}
                onClick={() => updateSettings({ weekStart: w.id })}
                className={`py-2.5 text-xs font-semibold rounded-xl border transition-all duration-200 active:scale-95 ${
                  isSelected
                    ? (w.id === 'saturday' ? 'border-rose-400 bg-rose-50 dark:bg-rose-950/35 text-rose-700 dark:text-rose-300 ring-1 ring-rose-300 shadow-xs' : w.id === 'sunday' ? 'border-amber-400 bg-amber-50 dark:bg-amber-950/35 text-amber-800 dark:text-amber-300 ring-1 ring-amber-300 shadow-xs' : 'border-violet-400 bg-violet-50 dark:bg-violet-950/35 text-violet-700 dark:text-violet-300 ring-1 ring-violet-300 shadow-xs')
                    : 'border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800'
                }`}
              >
                {w.label}
              </button>
            );
          })}
        </div>
      </div>

      {/* About */}
      <div className="bg-white dark:bg-slate-900 rounded-3xl p-5 border border-slate-200/90 dark:border-slate-800 shadow-sm transition-all duration-200 hover:shadow-md text-center">
        <div className="w-10 h-10 mx-auto rounded-full bg-gradient-to-br from-rose-100 via-amber-100 to-violet-100 dark:from-rose-950/60 dark:via-amber-950/50 dark:to-violet-950/60 text-violet-700 dark:text-violet-300 flex items-center justify-center mb-2">
          <ShieldCheck className="w-5 h-5" />
        </div>
        <h4 className="text-sm font-bold text-slate-900 dark:text-white">{t('settings.version')}</h4>
        <p className="text-xs text-slate-500 dark:text-slate-400 max-w-sm mx-auto mt-1 leading-relaxed">{t('settings.aboutText')}</p>
      </div>
    </div>
  );
};
