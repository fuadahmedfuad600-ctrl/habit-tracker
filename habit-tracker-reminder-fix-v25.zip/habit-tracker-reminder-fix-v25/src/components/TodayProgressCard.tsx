import React from 'react';
import { useHabit } from '../context/HabitContext';
import { formatDateKey, getTodayKey } from '../utils/date';
import { getDailyProgress } from '../utils/streak';

export const TodayProgressCard: React.FC = () => {
  const { habits, completions, selectedDate, t } = useHabit();
  const progress = getDailyProgress(habits, completions, selectedDate);
  const isToday = formatDateKey(selectedDate) === getTodayKey();
  const radius = 36;
  const circumference = 2 * Math.PI * radius;
  const strokeDashoffset = circumference - (circumference * progress.percentage) / 100;
  const remainingCount = Math.max(0, progress.totalCount - progress.completedCount);

  const getMotivationalMessage = () => {
    if (progress.totalCount === 0) return t('progress.none');
    if (progress.percentage === 100) return t('progress.outstanding');
    if (progress.percentage >= 70) return t('progress.almost');
    if (progress.percentage >= 40) return t('progress.good');
    if (progress.percentage > 0) return t('progress.start');
    return t('progress.ready');
  };

  return (
    <section className="relative overflow-hidden rounded-[26px] border border-slate-200/80 bg-white p-4 shadow-sm transition-all duration-300 hover:shadow-md dark:border-slate-800 dark:bg-slate-900 sm:p-5">
      <div aria-hidden="true" className="pointer-events-none absolute -right-12 -top-14 h-36 w-36 rounded-full bg-gradient-to-br from-rose-200/60 via-amber-100/50 to-sky-200/50 blur-2xl dark:from-rose-900/15 dark:via-amber-900/10 dark:to-sky-900/15" />
      <div className="relative z-10 flex items-center justify-between gap-3.5">
        <div className="min-w-0 flex-1">
          <div className="flex items-center gap-2">
            <span className="h-2 w-2 rounded-full bg-rose-500" />
            <span className="text-[11px] font-extrabold uppercase tracking-[0.13em] text-rose-600 dark:text-rose-300">{isToday ? t('progress.today') : t('progress.day')}</span>
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-3xl font-extrabold tracking-tight tabular-nums text-emerald-600 dark:text-emerald-400">{progress.completedCount}</span>
            <span className="text-sm font-semibold text-slate-500 dark:text-slate-400">{t('progress.completed', { count: progress.totalCount })}</span>
          </div>
          <p className="mt-2 max-w-[230px] text-xs font-medium leading-relaxed text-slate-600 dark:text-slate-300">{getMotivationalMessage()}</p>
        </div>

        <div className="relative flex h-[94px] w-[94px] shrink-0 items-center justify-center sm:h-[104px] sm:w-[104px]">
          <svg className="h-full w-full -rotate-90" viewBox="0 0 88 88" role="img" aria-label={`${progress.percentage}% progress`}>
            <defs>
              <linearGradient id="daily-progress-gradient" x1="0" y1="0" x2="1" y2="1">
                <stop offset="0%" stopColor="#e11d48" />
                <stop offset="48%" stopColor="#f59e0b" />
                <stop offset="100%" stopColor="#0d9488" />
              </linearGradient>
            </defs>
            <circle cx="44" cy="44" r={radius} stroke="currentColor" className="text-slate-100 dark:text-slate-800" strokeWidth="8" fill="none" />
            <circle cx="44" cy="44" r={radius} stroke="url(#daily-progress-gradient)" strokeWidth="8" strokeDasharray={circumference} strokeDashoffset={strokeDashoffset} strokeLinecap="round" fill="none" className="transition-all duration-500 ease-out" />
          </svg>
          <div className="absolute flex flex-col items-center">
            <span className="text-xl font-extrabold tracking-tight tabular-nums text-slate-900 dark:text-white">{progress.percentage}%</span>
            <span className="text-[9px] font-bold uppercase tracking-wider text-slate-400">{t('stats.progress')}</span>
          </div>
        </div>
      </div>

      <div className="relative z-10 mt-4">
        <div className="h-2 overflow-hidden rounded-full bg-slate-100 dark:bg-slate-800">
          <div className="h-full rounded-full transition-all duration-500 ease-out" style={{ width: `${progress.percentage}%`, background: 'linear-gradient(90deg, #e11d48 0%, #f59e0b 48%, #0d9488 100%)' }} />
        </div>
        <div className="mt-2.5 flex items-center justify-between gap-3 text-[10px] font-semibold">
          <span className="inline-flex items-center gap-1.5 text-emerald-700 dark:text-emerald-300"><span className="h-2 w-2 rounded-full bg-emerald-500" />{progress.completedCount} {t('stats.completedHabits')}</span>
          <span className="inline-flex items-center gap-1.5 text-amber-700 dark:text-amber-300"><span className="h-2 w-2 rounded-full bg-amber-400" />{remainingCount} {t('stats.remainingHabits')}</span>
        </div>
      </div>
    </section>
  );
};
