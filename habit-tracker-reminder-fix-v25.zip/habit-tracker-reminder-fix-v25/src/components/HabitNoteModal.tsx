import React, { useState, useEffect } from 'react';
import { useHabit } from '../context/HabitContext';
import { Habit } from '../types';
import { DynamicIcon, X, Check } from './DynamicIcon';
import { COLOR_OPTIONS } from '../utils/defaults';
import { formatShortDate } from '../utils/date';

interface HabitNoteModalProps {
  habit: Habit;
  dateKey: string;
  onClose: () => void;
}

const QUICK_TAGS = ['🔥 High Energy', '🎯 Hit Goal', '💪 Personal Best', '✨ Felt Great', '🧘 Calm Focus'];

export const HabitNoteModal: React.FC<HabitNoteModalProps> = ({ habit, dateKey, onClose }) => {
  const { getHabitNote, saveHabitNote, language, t } = useHabit();
  const [noteText, setNoteText] = useState('');
  const [isSaved, setIsSaved] = useState(false);

  const colorConfig = COLOR_OPTIONS.find((c) => c.id === habit.color) || COLOR_OPTIONS[0];

  useEffect(() => {
    const existing = getHabitNote(habit.id, dateKey);
    setNoteText(existing || '');
  }, [habit.id, dateKey, getHabitNote]);

  const handleSave = () => {
    saveHabitNote(habit.id, dateKey, noteText.trim());
    setIsSaved(true);
    setTimeout(() => {
      onClose();
    }, 400);
  };

  const handleAddTag = (tag: string) => {
    setNoteText((prev) => (prev ? `${prev} · ${tag}` : tag));
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 overlay-center-safe bg-slate-950/70 backdrop-blur-sm animate-fade-in">
      <div className="bg-white dark:bg-slate-900 w-full max-w-md rounded-3xl shadow-2xl border-2 border-slate-200 dark:border-slate-800 p-6 flex flex-col relative overflow-y-auto dialog-safe">
        {/* Header */}
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-3">
            <div
              className={`w-10 h-10 rounded-xl flex items-center justify-center ${colorConfig.lightBg} ${colorConfig.text}`}
            >
              <DynamicIcon name={habit.icon} className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                {habit.name}
              </h3>
              <p className="text-xs text-slate-400">
                {t('note.date', { date: formatShortDate(new Date(dateKey + 'T00:00:00'), language) })}
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full flex items-center justify-center text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Quick Tag Suggestions */}
        <div className="mb-3">
          <span className="text-[11px] font-semibold text-slate-400 block mb-1.5">
            {t('note.quickInsights')}
          </span>
          <div className="flex items-center gap-1.5 flex-wrap">
            {QUICK_TAGS.map((tag) => (
              <button
                key={tag}
                type="button"
                onClick={() => handleAddTag(tag)}
                className="px-2 py-1 text-[11px] font-medium rounded-lg bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-blue-50 dark:hover:bg-blue-950/60 hover:text-blue-700 dark:hover:text-blue-300 border border-slate-200 dark:border-slate-700 transition-colors"
              >
                {tag}
              </button>
            ))}
          </div>
        </div>

        {/* Note Textarea */}
        <div className="mb-4">
          <textarea
            value={noteText}
            onChange={(e) => setNoteText(e.target.value)}
            rows={4}
            placeholder={t('note.placeholder')}
            className="w-full p-3.5 rounded-2xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white text-xs placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500 leading-relaxed resize-none"
            autoFocus
          />
        </div>

        {/* Actions */}
        <div className="flex items-center justify-end gap-2">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 text-xs font-semibold rounded-xl text-slate-500 hover:text-slate-700 dark:hover:text-slate-300 transition-colors"
          >
            {t('note.cancel')}
          </button>

          <button
            type="button"
            onClick={handleSave}
            className="px-5 py-2 text-xs font-bold rounded-xl bg-blue-600 hover:bg-blue-700 text-white shadow-sm flex items-center gap-1.5 transition-all"
          >
            {isSaved ? <Check className="w-4 h-4 stroke-[3]" /> : null}
            <span>{isSaved ? t('note.saved') : t('note.save')}</span>
          </button>
        </div>
      </div>
    </div>
  );
};
