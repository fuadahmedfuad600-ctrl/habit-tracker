import React, { useState, useEffect, useMemo } from 'react';
import { useHabit } from '../context/HabitContext';
import { HabitCategory, HabitFrequency } from '../types';
import { COLOR_OPTIONS, HABIT_CATEGORIES, ICON_OPTIONS } from '../utils/defaults';
import { DynamicIcon, X, Clock, Bell, Search } from './DynamicIcon';

// 0=Sun, 1=Mon, 2=Tue, 3=Wed, 4=Thu, 5=Fri, 6=Sat
const CATEGORY_COLOR_CYCLE: Record<string, string[]> = {
  Health: ['red', 'rose', 'emerald', 'teal'],
  Fitness: ['orange', 'green', 'blue'],
  Study: ['blue', 'violet', 'yellow', 'cyan'],
  Work: ['indigo', 'blue', 'rose'],
  Personal: ['rose', 'violet', 'yellow'],
  Other: ['teal', 'green', 'orange', 'cyan'],
};

const CATEGORY_SELECTED_STYLE: Record<string, string> = {
  Health: 'bg-rose-600 text-white shadow-sm',
  Fitness: 'bg-orange-600 text-white shadow-sm',
  Study: 'bg-sky-600 text-white shadow-sm',
  Work: 'bg-violet-600 text-white shadow-sm',
  Personal: 'bg-pink-600 text-white shadow-sm',
  Other: 'bg-teal-700 text-white shadow-sm',
};

const DAYS_OF_WEEK = [
  { dayIndex: 1, label: 'Mon', full: 'Monday' },
  { dayIndex: 2, label: 'Tue', full: 'Tuesday' },
  { dayIndex: 3, label: 'Wed', full: 'Wednesday' },
  { dayIndex: 4, label: 'Thu', full: 'Thursday' },
  { dayIndex: 5, label: 'Fri', full: 'Friday' },
  { dayIndex: 6, label: 'Sat', full: 'Saturday' },
  { dayIndex: 0, label: 'Sun', full: 'Sunday' },
];

export const HabitModal: React.FC = () => {
  const {
    isHabitModalOpen,
    editingHabit,
    habits,
    closeHabitModal,
    createHabit,
    updateHabit,
    settings,
    updateSettings,
    requestNotifications,
    t,
    language,
  } = useHabit();

  const [name, setName] = useState('');
  const [category, setCategory] = useState<HabitCategory>('Health');
  const [customCategory, setCustomCategory] = useState('');
  const [icon, setIcon] = useState('droplet');
  const [color, setColor] = useState('red');
  const [colorTouched, setColorTouched] = useState(false);
  const [frequency, setFrequency] = useState<HabitFrequency>('daily');
  const [selectedDays, setSelectedDays] = useState<number[]>([]);
  const [reminderEnabled, setReminderEnabled] = useState(false);
  const [reminderTime, setReminderTime] = useState('08:00');
  const [description, setDescription] = useState('');
  const [error, setError] = useState('');

  // Icon filtering state
  const [iconSearch, setIconSearch] = useState('');
  const [iconCategory, setIconCategory] = useState<string>('All');

  const filteredIcons = useMemo(() => {
    return ICON_OPTIONS.filter((item) => {
      const matchesCat = iconCategory === 'All' || item.category === iconCategory;
      const q = iconSearch.trim().toLowerCase();
      const matchesSearch =
        !q ||
        item.label.toLowerCase().includes(q) ||
        item.id.toLowerCase().includes(q);
      return matchesCat && matchesSearch;
    });
  }, [iconCategory, iconSearch]);

  const suggestedColorForCategory = (categoryName: string): string => {
    const palette = CATEGORY_COLOR_CYCLE[categoryName] || CATEGORY_COLOR_CYCLE.Other;
    const sameCategory = habits.filter((habit) => !habit.isArchived && habit.category === categoryName);
    const used = new Set(sameCategory.map((habit) => habit.color));
    return palette.find((colorId) => !used.has(colorId)) || palette[sameCategory.length % palette.length];
  };

  // Populate when editing or reset when creating. New habits get a category-aware colour,
  // cycling through unused colours so the dashboard naturally becomes multi-colour.
  useEffect(() => {
    if (editingHabit) {
      setName(editingHabit.name);
      if (['Health', 'Fitness', 'Study', 'Work', 'Personal'].includes(editingHabit.category)) {
        setCategory(editingHabit.category);
        setCustomCategory('');
      } else {
        setCategory('Other');
        setCustomCategory(editingHabit.category === 'Other' ? '' : editingHabit.category);
      }
      setIcon(editingHabit.icon);
      setColor(editingHabit.color);
      setColorTouched(true);
      setFrequency(editingHabit.frequency);
      setSelectedDays(editingHabit.selectedDays);
      setReminderEnabled(editingHabit.reminderEnabled);
      setReminderTime(editingHabit.reminderTime || '08:00');
      setDescription(editingHabit.description || '');
    } else {
      setName('');
      setCategory('Health');
      setCustomCategory('');
      setIcon('droplet');
      setColor(suggestedColorForCategory('Health'));
      setColorTouched(false);
      setFrequency('daily');
      setSelectedDays([]);
      setReminderEnabled(false);
      setReminderTime('08:00');
      setDescription('');
    }
    setError('');
  }, [editingHabit, isHabitModalOpen]);

  if (!isHabitModalOpen) return null;

  const toggleDay = (dayIndex: number) => {
    if (selectedDays.includes(dayIndex)) {
      setSelectedDays(selectedDays.filter((d) => d !== dayIndex));
    } else {
      setSelectedDays([...selectedDays, dayIndex].sort());
    }
    setError('');
  };


  const adjustReminderTime = (deltaMinutes: number) => {
    const [rawHour, rawMinute] = reminderTime.split(':');
    const currentMinutes = (Number.parseInt(rawHour || '8', 10) * 60) + Number.parseInt(rawMinute || '0', 10);
    const nextMinutes = (currentMinutes + deltaMinutes + 1440) % 1440;
    const nextHour = Math.floor(nextMinutes / 60);
    const nextMinute = nextMinutes % 60;
    setReminderTime(`${String(nextHour).padStart(2, '0')}:${String(nextMinute).padStart(2, '0')}`);
  };

  const handleReminderToggle = async (enabled: boolean) => {
    setReminderEnabled(enabled);
    if (enabled) {
      updateSettings({ notificationsEnabled: true });
      if (typeof window !== 'undefined' && 'Notification' in window && Notification.permission !== 'granted') {
        await requestNotifications();
      }
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) {
      setError(t('habit.errorName'));
      return;
    }

    if (frequency === 'selected_days' && selectedDays.length === 0) {
      setError(t('habit.errorDay'));
      return;
    }

    if (category === 'Other' && !customCategory.trim()) {
      setError(t('habit.errorCategory'));
      return;
    }

    const finalCategory =
      category === 'Other' && customCategory.trim()
        ? customCategory.trim()
        : category;

    if (editingHabit) {
      updateHabit(editingHabit.id, {
        name: name.trim(),
        category: finalCategory,
        icon,
        color,
        frequency,
        selectedDays: frequency === 'daily' ? [0, 1, 2, 3, 4, 5, 6] : selectedDays,
        reminderEnabled,
        reminderTime,
        description: description.trim() || undefined,
      });
    } else {
      createHabit({
        name: name.trim(),
        category: finalCategory,
        icon,
        color,
        frequency,
        selectedDays: frequency === 'daily' ? [0, 1, 2, 3, 4, 5, 6] : selectedDays,
        reminderEnabled,
        reminderTime,
        description: description.trim() || undefined,
      });
    }

    closeHabitModal();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4 overlay-safe bg-slate-950/60 backdrop-blur-sm animate-fade-in">
      <div className="bg-white dark:bg-slate-900 w-full max-w-lg rounded-t-3xl sm:rounded-3xl shadow-2xl border border-slate-200 dark:border-slate-800 sheet-safe max-h-[92vh] flex flex-col overflow-hidden">
        {/* Modal Header */}
        <div className="flex items-center justify-between px-6 pt-5 pb-4 border-b border-slate-100 dark:border-slate-800">
          <div>
            <h2 className="text-lg font-bold text-slate-900 dark:text-white">
              {editingHabit ? t('habit.edit') : t('habit.create')}
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              {editingHabit ? t('habit.updateDetails') : t('habit.setupRoutine')}
            </p>
          </div>
          <button
            onClick={closeHabitModal}
            className="w-9 h-9 rounded-full flex items-center justify-center text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-6 overflow-y-auto space-y-5 flex-1">
          {error && (
            <div className="p-3 text-xs rounded-xl bg-red-50 dark:bg-red-950/50 text-red-600 dark:text-red-400 border border-red-200 dark:border-red-900 font-medium">
              {error}
            </div>
          )}

          {/* Habit Name */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 uppercase tracking-wider mb-1.5">
              {t('habit.name')}
            </label>
            <input
              type="text"
              value={name}
              onChange={(e) => {
                setName(e.target.value);
                setError('');
              }}
              placeholder={t('habit.namePlaceholder')}
              className="w-full px-4 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white placeholder:text-slate-400 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 transition-colors"
              autoFocus
            />
          </div>

          {/* Category */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 uppercase tracking-wider mb-1.5">
              {t('habit.category')}
            </label>
            <div className="grid grid-cols-3 sm:grid-cols-6 gap-1.5">
              {HABIT_CATEGORIES.map((cat) => (
                <button
                  type="button"
                  key={cat}
                  onClick={() => { setCategory(cat); if (!editingHabit && !colorTouched) setColor(suggestedColorForCategory(cat)); }}
                  className={`py-2 px-2 text-xs font-semibold rounded-xl transition-all active:scale-95 ${
                    category === cat
                      ? (CATEGORY_SELECTED_STYLE[cat] || CATEGORY_SELECTED_STYLE.Other)
                      : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-200 dark:hover:bg-slate-700'
                  }`}
                >
                  {t(`category.${cat}`)}
                </button>
              ))}
            </div>

            {/* Custom Category Input if "Other" is selected */}
            {category === 'Other' && (
              <div className="mt-2.5 animate-fade-in p-3 rounded-2xl bg-blue-50/50 dark:bg-blue-950/20 border border-blue-200/80 dark:border-blue-800/60">
                <label className="block text-[11px] font-bold text-blue-800 dark:text-blue-300 uppercase tracking-wider mb-1">
                  {t('habit.customCategory')} *
                </label>
                <input
                  type="text"
                  value={customCategory}
                  onChange={(e) => setCustomCategory(e.target.value)}
                  placeholder={t('habit.customCategoryPlaceholder')}
                  className="w-full px-3.5 py-2 text-xs rounded-xl border border-blue-300 dark:border-blue-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500 font-medium"
                  autoFocus
                />
              </div>
            )}
          </div>

          {/* Icon Picker (86+ Icons with Search & Categories) */}
          <div>
            <div className="flex items-center justify-between mb-1.5">
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 uppercase tracking-wider">
                {t('habit.icon')} ({ICON_OPTIONS.length})
              </label>
              <div className="flex items-center gap-1.5 text-xs font-semibold text-blue-600 dark:text-blue-400">
                <DynamicIcon name={icon} className="w-4 h-4" />
                <span>{ICON_OPTIONS.find((item) => item.id === icon)?.label || t('habit.selected')}</span>
              </div>
            </div>

            {/* Search & Category Filter Bar */}
            <div className="space-y-2 mb-2">
              <div className="relative">
                <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                <input
                  type="text"
                  value={iconSearch}
                  onChange={(e) => setIconSearch(e.target.value)}
                  placeholder={t('habit.searchIcons')}
                  className="w-full pl-9 pr-3 py-1.5 text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
                {iconSearch && (
                  <button
                    type="button"
                    onClick={() => setIconSearch('')}
                    className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 text-xs"
                  >
                    ✕
                  </button>
                )}
              </div>

              {/* Category Pills */}
              <div className="flex items-center gap-1 overflow-x-auto pb-1 no-scrollbar">
                {['All', 'Health', 'Fitness', 'Mind', 'Study', 'Work', 'Finance', 'Home', 'Lifestyle'].map(
                  (cat) => (
                    <button
                      type="button"
                      key={cat}
                      onClick={() => setIconCategory(cat)}
                      className={`px-2.5 py-1 text-[11px] font-medium rounded-lg whitespace-nowrap transition-colors ${
                        iconCategory === cat
                          ? 'bg-blue-600 text-white shadow-xs'
                          : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
                      }`}
                    >
                      {t(`category.${cat}`)}
                    </button>
                  )
                )}
              </div>
            </div>

            {/* Icons Grid */}
            <div className="grid grid-cols-6 sm:grid-cols-8 gap-2 p-2.5 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200/80 dark:border-slate-800 max-h-48 overflow-y-auto">
              {filteredIcons.length > 0 ? (
                filteredIcons.map((item) => (
                  <button
                    type="button"
                    key={item.id}
                    onClick={() => setIcon(item.id)}
                    title={`${item.label} (${item.category})`}
                    className={`h-10 rounded-xl flex items-center justify-center transition-all ${
                      icon === item.id
                        ? 'bg-gradient-to-br from-rose-500 via-violet-600 to-blue-600 text-white shadow-sm ring-2 ring-violet-400 scale-105'
                        : 'text-slate-600 dark:text-slate-400 hover:bg-slate-200 dark:hover:bg-slate-700/60'
                    }`}
                  >
                    <DynamicIcon name={item.id} className="w-5 h-5 stroke-[2]" />
                  </button>
                ))
              ) : (
                <div className="col-span-full py-4 text-center text-xs text-slate-400">
                  {t('habit.noIcons', { query: iconSearch })}
                </div>
              )}
            </div>
          </div>

          {/* Color Picker */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 uppercase tracking-wider mb-1.5">
              {t('habit.colorTheme')}
            </label>
            <div className="flex items-center gap-2.5 flex-wrap">
              {COLOR_OPTIONS.map((c) => (
                <button
                  type="button"
                  key={c.id}
                  onClick={() => { setColor(c.id); setColorTouched(true); }}
                  className={`w-8 h-8 rounded-full ${c.bg} transition-all ${
                    color === c.id
                      ? 'ring-4 ring-offset-2 ring-slate-400 dark:ring-offset-slate-900 scale-110'
                      : 'hover:scale-105 opacity-80 hover:opacity-100'
                  }`}
                  aria-label={c.label}
                />
              ))}
            </div>
          </div>

          {/* Frequency: Daily vs Selected Days */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 uppercase tracking-wider mb-1.5">
              {t('habit.frequency')}
            </label>
            <div className="grid grid-cols-2 gap-2 p-1 bg-slate-100 dark:bg-slate-800 rounded-xl">
              <button
                type="button"
                onClick={() => setFrequency('daily')}
                className={`py-2 text-xs font-medium rounded-lg transition-colors ${
                  frequency === 'daily'
                    ? 'bg-white dark:bg-slate-700 text-slate-900 dark:text-white shadow-sm'
                    : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
                }`}
              >
                {t('habit.everyDay')}
              </button>
              <button
                type="button"
                onClick={() => {
                  // Start with no day selected (an "every day" habit stores all 7 days).
                  if (frequency === 'daily' && selectedDays.length === 7) setSelectedDays([]);
                  setFrequency('selected_days');
                }}
                className={`py-2 text-xs font-medium rounded-lg transition-colors ${
                  frequency === 'selected_days'
                    ? 'bg-white dark:bg-slate-700 text-slate-900 dark:text-white shadow-sm'
                    : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
                }`}
              >
                {t('habit.selectedDays')}
              </button>
            </div>

            {/* Selected days row */}
            {frequency === 'selected_days' && (
              <div className="mt-3 grid grid-cols-7 gap-1">
                {DAYS_OF_WEEK.map((d) => {
                  const isSelected = selectedDays.includes(d.dayIndex);
                  return (
                    <button
                      type="button"
                      key={d.dayIndex}
                      onClick={() => toggleDay(d.dayIndex)}
                      className={`py-2 text-xs font-semibold rounded-xl border transition-all ${
                        isSelected
                          ? 'bg-blue-600 text-white border-blue-600 shadow-sm'
                          : 'bg-white dark:bg-slate-800 text-slate-500 border-slate-200 dark:border-slate-700'
                      }`}
                    >
                      {new Date(2024, 0, 7 + d.dayIndex).toLocaleDateString(language === 'bn' ? 'bn-BD' : language === 'hi' ? 'hi-IN' : 'en-US', { weekday: 'short' })}
                    </button>
                  );
                })}
              </div>
            )}
          </div>

          {/* Reminder Section */}
          <div className="pt-2 border-t border-slate-100 dark:border-slate-800">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <Bell className="w-4 h-4 text-blue-600 dark:text-blue-400" />
                <span className="text-xs font-semibold text-slate-700 dark:text-slate-300 uppercase tracking-wider">
                  {t('habit.reminder')}
                </span>
              </div>
              <label className="relative inline-flex items-center cursor-pointer">
                <input
                  type="checkbox"
                  checked={reminderEnabled}
                  onChange={(e) => handleReminderToggle(e.target.checked)}
                  className="sr-only peer"
                />
                <div className="w-11 h-6 bg-slate-200 peer-focus:outline-none rounded-full peer dark:bg-slate-700 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
              </label>
            </div>

            {reminderEnabled && (
              <div className="p-3.5 bg-gradient-to-r from-blue-50 via-white to-amber-50 dark:from-blue-950/35 dark:via-slate-800/70 dark:to-amber-950/20 rounded-2xl border border-blue-100 dark:border-blue-900/60 animate-fade-in space-y-3">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-xl bg-blue-100 dark:bg-blue-900/60 text-blue-700 dark:text-blue-300 flex items-center justify-center shrink-0">
                    <Clock className="w-4 h-4" />
                  </div>
                  <div className="min-w-0 flex-1">
                    <span className="text-xs font-bold text-slate-800 dark:text-slate-100 block">{t('habit.time')}</span>
                    <span className="text-[10px] text-slate-500 dark:text-slate-400">{t('habit.adjustTimeHint')}</span>
                  </div>
                  <input
                    type="time"
                    aria-label={t('habit.time')}
                    value={reminderTime}
                    onChange={(e) => setReminderTime(e.target.value || '08:00')}
                    className="min-w-0 w-[118px] px-2 py-2 rounded-xl border border-blue-200 dark:border-blue-800 bg-white dark:bg-slate-900 text-sm font-bold text-blue-700 dark:text-blue-300 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div className="rounded-xl bg-white/90 dark:bg-slate-900/70 border border-blue-100 dark:border-slate-700 p-2.5">
                    <div className="text-[10px] uppercase tracking-wider text-slate-500 dark:text-slate-400 font-bold text-center mb-2">{t('habit.hour')}</div>
                    <div className="flex items-center justify-between gap-2">
                      <button type="button" onClick={() => adjustReminderTime(-60)} aria-label={t('habit.decreaseHour')} className="w-9 h-9 rounded-xl bg-blue-100 hover:bg-blue-200 dark:bg-blue-900/60 dark:hover:bg-blue-800 text-blue-700 dark:text-blue-200 text-xl font-bold transition-colors active:scale-95">−</button>
                      <span className="text-xl font-extrabold tabular-nums text-slate-900 dark:text-white">{reminderTime.split(':')[0] || '08'}</span>
                      <button type="button" onClick={() => adjustReminderTime(60)} aria-label={t('habit.increaseHour')} className="w-9 h-9 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xl font-bold transition-colors active:scale-95">+</button>
                    </div>
                  </div>
                  <div className="rounded-xl bg-white/90 dark:bg-slate-900/70 border border-amber-100 dark:border-slate-700 p-2.5">
                    <div className="text-[10px] uppercase tracking-wider text-slate-500 dark:text-slate-400 font-bold text-center mb-2">{t('habit.minuteStep')}</div>
                    <div className="flex items-center justify-between gap-2">
                      <button type="button" onClick={() => adjustReminderTime(-5)} aria-label={t('habit.decreaseMinute')} className="w-9 h-9 rounded-xl bg-amber-100 hover:bg-amber-200 dark:bg-amber-900/60 dark:hover:bg-amber-800 text-amber-800 dark:text-amber-200 text-xl font-bold transition-colors active:scale-95">−</button>
                      <span className="text-xl font-extrabold tabular-nums text-slate-900 dark:text-white">{reminderTime.split(':')[1] || '00'}</span>
                      <button type="button" onClick={() => adjustReminderTime(5)} aria-label={t('habit.increaseMinute')} className="w-9 h-9 rounded-xl bg-amber-400 hover:bg-amber-500 text-amber-950 text-xl font-bold transition-colors active:scale-95">+</button>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Optional notes */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 uppercase tracking-wider mb-1.5">
              {t('habit.description')}
            </label>
            <input
              type="text"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder={t('habit.descriptionPlaceholder')}
              className="w-full px-4 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white text-xs placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>

          {/* Bottom Action Buttons */}
          <div className="pt-4 flex items-center gap-3">
            <button
              type="button"
              onClick={closeHabitModal}
              className="flex-1 py-3 px-4 text-sm font-semibold rounded-xl border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
            >
              {t('habit.cancel')}
            </button>
            <button
              type="submit"
              className="flex-1 py-3 px-4 text-sm font-bold rounded-xl bg-gradient-to-r from-rose-500 via-violet-600 to-blue-600 hover:brightness-105 text-white shadow-md shadow-violet-600/20 transition-all active:scale-[0.99]"
            >
              {editingHabit ? t('habit.saveChanges') : t('habit.createAction')}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
