import React, { useState, useMemo } from 'react';
import { useHabit } from '../context/HabitContext';
import { COLOR_OPTIONS, HABIT_CATEGORIES } from '../utils/defaults';
import { calculateHabitStats } from '../utils/streak';
import { formatTime12h } from '../utils/date';
import { translateCategory } from '../utils/i18n';
import { DynamicIcon, Plus, Flame, Clock, Edit2, Archive, RotateCcw, Target } from './DynamicIcon';

export const HabitsManagerView: React.FC = () => {
  const { habits, completions, openCreateModal, openEditModal, setSelectedHabitForDetail, archiveHabit, unarchiveHabit, language, t } = useHabit();
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [viewTab, setViewTab] = useState<'active' | 'archived'>('active');

  const categories = useMemo(() => {
    const list = new Set<string>(['All', ...HABIT_CATEGORIES]);
    habits.forEach((h) => h.category && list.add(h.category));
    return Array.from(list);
  }, [habits]);

  const filteredHabits = habits.filter((h) => {
    const matchesArchived = viewTab === 'active' ? !h.isArchived : h.isArchived;
    return matchesArchived && (selectedCategory === 'All' || h.category === selectedCategory);
  });

  return (
    <div className="space-y-4 pb-24 animate-fade-in">
      <div className="flex items-center justify-between gap-3">
        <div className="flex p-1 bg-slate-200/70 dark:bg-slate-800 rounded-xl min-w-0">
          <button onClick={() => setViewTab('active')} className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-all ${viewTab === 'active' ? 'bg-white dark:bg-slate-700 text-slate-900 dark:text-white shadow-xs' : 'text-slate-600 dark:text-slate-400'}`}>
            {t('manager.active', { count: habits.filter((h) => !h.isArchived).length })}
          </button>
          <button onClick={() => setViewTab('archived')} className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-all ${viewTab === 'archived' ? 'bg-white dark:bg-slate-700 text-slate-900 dark:text-white shadow-xs' : 'text-slate-600 dark:text-slate-400'}`}>
            {t('manager.archived', { count: habits.filter((h) => h.isArchived).length })}
          </button>
        </div>
        <button onClick={openCreateModal} className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-gradient-to-r from-rose-500 via-violet-600 to-blue-600 hover:brightness-105 text-white text-xs font-bold shadow-md shadow-violet-900/15 transition-all duration-200 active:scale-95 shrink-0">
          <Plus className="w-3.5 h-3.5 stroke-[2.5]" /><span>{t('manager.newHabit')}</span>
        </button>
      </div>

      <div className="flex items-center gap-1.5 overflow-x-auto pb-1 no-scrollbar">
        {categories.map((cat) => (
          <button key={cat} onClick={() => setSelectedCategory(cat)} className={`px-3 py-1.5 text-xs font-medium rounded-xl whitespace-nowrap transition-all duration-200 active:scale-95 ${selectedCategory === cat ? 'bg-gradient-to-r from-rose-500 via-violet-600 to-blue-600 text-white shadow-sm border border-transparent' : 'bg-white dark:bg-slate-900 text-slate-600 dark:text-slate-400 border border-slate-200/90 dark:border-slate-800 hover:border-rose-300 dark:hover:border-rose-800 hover:text-slate-900'}`}>
            {cat === 'All' ? t('manager.all') : translateCategory(language, cat)}
          </button>
        ))}
      </div>

      {filteredHabits.length > 0 ? (
        <div className="space-y-3">
          {filteredHabits.map((habit) => {
            const stats = calculateHabitStats(habit, completions, new Date());
            const colorConfig = COLOR_OPTIONS.find((c) => c.id === habit.color) || COLOR_OPTIONS[0];
            return (
              <div key={habit.id} onClick={() => setSelectedHabitForDetail(habit)} style={{ borderLeft: `4px solid ${colorConfig.hex}`, backgroundImage: `linear-gradient(100deg, ${colorConfig.hex}14 0%, transparent 68%)` }} className="group p-4 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/90 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700 shadow-sm hover:shadow-md transition-all duration-200 cursor-pointer animate-slide-up">
                <div className="flex items-center justify-between gap-3">
                  <div className="flex items-center gap-3.5 min-w-0 flex-1">
                    <div className={`w-11 h-11 rounded-xl flex items-center justify-center shrink-0 ${colorConfig.lightBg} ${colorConfig.text}`}><DynamicIcon name={habit.icon} className="w-5 h-5 stroke-[2]" /></div>
                    <div className="min-w-0 flex-1">
                      <h3 className="text-sm font-bold text-slate-900 dark:text-white truncate">{habit.name}</h3>
                      <div className="flex items-center flex-wrap gap-x-2 gap-y-0.5 mt-0.5 text-xs text-slate-500 dark:text-slate-400">
                        <span>{translateCategory(language, habit.category)}</span><span aria-hidden="true">·</span>
                        <span>{habit.frequency === 'daily' ? t('manager.daily') : t('manager.selectedDays')}</span>
                        {habit.reminderEnabled && habit.reminderTime && <><span aria-hidden="true">·</span><span className="inline-flex items-center gap-1 text-slate-400"><Clock className="w-3 h-3" /><span>{formatTime12h(habit.reminderTime, language)}</span></span></>}
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center gap-1 shrink-0" onClick={(e) => e.stopPropagation()}>
                    <button onClick={() => openEditModal(habit)} title={t('manager.edit')} aria-label={t('manager.edit')} className="p-2 rounded-xl text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"><Edit2 className="w-4 h-4" /></button>
                    {habit.isArchived ? <button onClick={() => unarchiveHabit(habit.id)} title={t('manager.restore')} aria-label={t('manager.restore')} className="p-2 rounded-xl text-slate-400 hover:text-blue-600 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"><RotateCcw className="w-4 h-4" /></button> : <button onClick={() => archiveHabit(habit.id)} title={t('manager.archive')} aria-label={t('manager.archive')} className="p-2 rounded-xl text-slate-400 hover:text-amber-600 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"><Archive className="w-4 h-4" /></button>}
                  </div>
                </div>
                <div className="mt-3 pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-xs text-slate-500 dark:text-slate-400">
                  <div className="flex items-center gap-1 font-semibold text-amber-500 tabular-nums"><Flame className="w-3.5 h-3.5 fill-amber-500" /><span>{t('manager.dayStreak', { count: stats.currentStreak })}</span></div>
                  <div className="flex items-center gap-3"><span>{t('manager.best')} <strong className="text-slate-700 dark:text-slate-300 tabular-nums">{stats.bestStreak}d</strong></span><span>{t('manager.rate')} <strong className="text-violet-600 dark:text-violet-400 tabular-nums">{stats.completionRate}%</strong></span></div>
                </div>
              </div>
            );
          })}
        </div>
      ) : (
        <div className="p-8 text-center bg-white dark:bg-slate-900 rounded-3xl border border-slate-200/90 dark:border-slate-800 shadow-sm text-slate-500 animate-slide-up">
          <Target className="w-8 h-8 mx-auto text-slate-400 mb-2" />
          <p className="text-sm font-semibold text-slate-700 dark:text-slate-300">{t('manager.noHabits')}</p>
          <p className="text-xs text-slate-400 mt-1">{t('manager.adjustFilter')}</p>
        </div>
      )}
    </div>
  );
};
