import React from 'react';
import { useHabit } from '../context/HabitContext';
import { getGreeting, formatDisplayDate } from '../utils/date';
import { Bell, Sun, DarkMoon, Trophy } from './DynamicIcon';

export const Header: React.FC = () => {
  const {
    unreadNotificationCount,
    setIsNotificationCenterOpen,
    isDarkMode,
    toggleTheme,
    activeTab,
    setIsAchievementsOpen,
    language,
    t,
  } = useHabit();

  const greeting = getGreeting(language);
  const todayFormatted = formatDisplayDate(new Date(), language);

  const getHeaderTitle = () => {
    switch (activeTab) {
      case 'habits': return t('header.myHabits');
      case 'calendar': return t('header.completionCalendar');
      case 'stats': return t('header.progressStats');
      case 'settings': return t('header.settings');
      case 'home':
      default: return greeting;
    }
  };

  const getHeaderSubtitle = () => {
    switch (activeTab) {
      case 'habits': return t('header.manageHabits');
      case 'calendar': return t('header.viewConsistency');
      case 'stats': return t('header.metrics');
      case 'settings': return t('header.customize');
      case 'home':
      default: return todayFormatted;
    }
  };

  return (
    <header className="sticky top-0 z-30 safe-top bg-slate-50/95 dark:bg-slate-950/95 backdrop-blur-md border-b border-slate-200/80 dark:border-slate-800/80 transition-colors">
      <div className="max-w-2xl mx-auto px-4 py-3.5 flex items-center justify-between gap-2">
        <div className="min-w-0">
          <h1 className="text-xl font-extrabold tracking-tight text-slate-900 dark:text-white truncate">{getHeaderTitle()}</h1>
          <p className="text-xs font-medium text-slate-500 dark:text-slate-400 mt-0.5 truncate">{getHeaderSubtitle()}</p>
          <div aria-hidden="true" className="mt-1.5 flex h-1 gap-1"><span className="w-5 rounded-full bg-rose-500" /><span className="w-3 rounded-full bg-amber-400" /><span className="w-4 rounded-full bg-emerald-500" /><span className="w-3 rounded-full bg-sky-500" /></div>
        </div>

        <div className="flex items-center gap-1 sm:gap-1.5 shrink-0">
          <button
            onClick={() => setIsAchievementsOpen(true)}
            title={t('header.achievements')}
            aria-label={t('header.achievements')}
            className="w-9 h-9 rounded-xl flex items-center justify-center text-amber-500 hover:bg-amber-50 dark:hover:bg-amber-950/40 transition-colors"
          >
            <Trophy className="w-4 h-4 fill-amber-500" />
          </button>

          <button
            onClick={toggleTheme}
            aria-label={t('header.toggleTheme')}
            className="w-9 h-9 rounded-xl flex items-center justify-center text-slate-600 dark:text-slate-300 hover:bg-slate-200/70 dark:hover:bg-slate-800/70 transition-colors"
          >
            {isDarkMode ? <Sun className="w-4 h-4 text-amber-400" /> : <DarkMoon className="w-4 h-4 text-slate-700" />}
          </button>

          <button
            onClick={() => setIsNotificationCenterOpen(true)}
            aria-label={t('header.notifications')}
            className="relative w-9 h-9 rounded-xl flex items-center justify-center text-rose-600 dark:text-rose-300 hover:bg-rose-50 dark:hover:bg-rose-950/40 transition-colors"
          >
            <Bell className="w-4 h-4" />
            {unreadNotificationCount > 0 && (
              <span className="absolute top-1.5 right-1.5 w-2 h-2 rounded-full bg-blue-500 ring-2 ring-slate-50 dark:ring-slate-950 animate-pulse" />
            )}
          </button>
        </div>
      </div>
    </header>
  );
};
