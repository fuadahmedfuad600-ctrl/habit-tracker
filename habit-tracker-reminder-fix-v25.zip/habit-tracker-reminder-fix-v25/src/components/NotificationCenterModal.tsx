import React from 'react';
import { useHabit } from '../context/HabitContext';
import { Bell, X, Flame, Sparkles, Trash2 } from './DynamicIcon';

export const NotificationCenterModal: React.FC = () => {
  const { isNotificationCenterOpen, setIsNotificationCenterOpen, notifications, markNotificationAsRead, markAllNotificationsAsRead, clearNotifications, t, language } = useHabit();
  if (!isNotificationCenterOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4 overlay-safe bg-slate-950/60 backdrop-blur-sm animate-fade-in">
      <div className="bg-white dark:bg-slate-900 w-full max-w-md rounded-t-3xl sm:rounded-3xl shadow-2xl border border-slate-200 dark:border-slate-800 sheet-safe max-h-[85vh] flex flex-col overflow-hidden animate-slide-up">
        <div className="flex items-center justify-between px-5 py-4 border-b border-slate-100 dark:border-slate-800">
          <div className="flex items-center gap-2"><Bell className="w-5 h-5 text-rose-600 dark:text-rose-300" /><h2 className="text-base font-bold text-slate-900 dark:text-white">{t('notification.title')}</h2></div>
          <div className="flex items-center gap-2">
            {notifications.length > 0 && <button onClick={markAllNotificationsAsRead} className="text-xs font-bold text-violet-600 dark:text-violet-300 hover:underline mr-1">{t('notification.markRead')}</button>}
            <button onClick={() => setIsNotificationCenterOpen(false)} aria-label={t('detail.close')} className="w-8 h-8 rounded-full flex items-center justify-center text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"><X className="w-4 h-4" /></button>
          </div>
        </div>

        <div className="p-4 overflow-y-auto space-y-2.5 flex-1">
          {notifications.length > 0 ? notifications.map((notif) => {
            const dateStr = new Date(notif.timestamp).toLocaleTimeString(language === 'bn' ? 'bn-BD' : language === 'hi' ? 'hi-IN' : 'en-US', { hour: '2-digit', minute: '2-digit' });
            return (
              <div key={notif.id} onClick={() => markNotificationAsRead(notif.id)} className={`p-3.5 rounded-2xl border transition-all cursor-pointer ${notif.read ? 'bg-slate-50/70 dark:bg-slate-800/40 border-slate-200/60 dark:border-slate-800/60 opacity-80' : 'bg-gradient-to-r from-rose-50/80 via-white to-violet-50/70 dark:from-rose-950/25 dark:via-slate-900 dark:to-violet-950/25 border-rose-200 dark:border-rose-900/70'}`}>
                <div className="flex items-start gap-3">
                  <div className="mt-0.5 shrink-0">
                    {notif.type === 'streak' ? <div className="w-8 h-8 rounded-full bg-amber-100 dark:bg-amber-950/60 text-amber-500 flex items-center justify-center"><Flame className="w-4 h-4 fill-amber-500" /></div> : notif.type === 'reminder' ? <div className="w-8 h-8 rounded-full bg-rose-100 dark:bg-rose-950/60 text-rose-600 dark:text-rose-300 flex items-center justify-center"><Bell className="w-4 h-4" /></div> : <div className="w-8 h-8 rounded-full bg-violet-100 dark:bg-violet-950/60 text-violet-600 dark:text-violet-300 flex items-center justify-center"><Sparkles className="w-4 h-4" /></div>}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between gap-1"><h4 className="text-xs font-bold text-slate-900 dark:text-white truncate">{notif.title}</h4><span className="text-[10px] text-slate-400 shrink-0 tabular-nums">{dateStr}</span></div>
                    <p className="text-xs text-slate-600 dark:text-slate-300 mt-1 leading-relaxed">{notif.message}</p>
                  </div>
                </div>
              </div>
            );
          }) : <div className="p-8 text-center text-slate-400 text-xs"><Bell className="w-8 h-8 mx-auto mb-2 opacity-30" />{t('notification.empty')}</div>}
        </div>

        {notifications.length > 0 && <div className="p-3 border-t border-slate-100 dark:border-slate-800 bg-slate-50 dark:bg-slate-900/60 flex justify-end"><button onClick={clearNotifications} className="text-xs text-slate-500 hover:text-red-500 flex items-center gap-1 font-medium transition-colors"><Trash2 className="w-3.5 h-3.5" /><span>{t('notification.clear')}</span></button></div>}
      </div>
    </div>
  );
};
