import React, { useEffect } from 'react';

const SHOW_MS = 2000; // the splash stays for 2 seconds in total
const FADE_MS = 450;

/**
 * The splash itself lives in index.html (so it is visible from the very first frame and is
 * never re-created). This component only hides it after 2 seconds with a smooth fade.
 */
export const SplashScreen: React.FC = () => {
  useEffect(() => {
    const el = document.getElementById('splash');
    if (!el) return;

    const wait = Math.max(0, SHOW_MS - performance.now());
    const hideTimer = window.setTimeout(() => el.classList.add('hide'), wait);
    const removeTimer = window.setTimeout(() => el.remove(), wait + FADE_MS + 50);
    return () => {
      window.clearTimeout(hideTimer);
      window.clearTimeout(removeTimer);
    };
  }, []);

  return null;
};
