import React from 'react';
import { useHabit } from '../context/HabitContext';
import { formatDateKey, formatShortDate, getTodayKey } from '../utils/date';
import { isHabitApplicableOnDate } from '../utils/streak';
import { DateStrip } from './DateStrip';
import { TodayProgressCard } from './TodayProgressCard';
import { HabitCard } from './HabitCard';
import { Plus, Target } from './DynamicIcon';

export const HomeView: React.FC = () => {
  const { habits, completions, selectedDate, openCreateModal, t, language } = useHabit();

  const scheduledHabits = habits.filter((h) => isHabitApplicableOnDate(h, selectedDate, completions));
  const activeHabits = habits.filter((h) => !h.isArchived);
  const isToday = formatDateKey(selectedDate) === getTodayKey();

  return (
    <div className="space-y-4 pb-24 animate-fade-in">
      <DateStrip />
      <TodayProgressCard />

      <div className="flex items-center justify-between pt-1 px-1 gap-3">
        <div className="min-w-0">
          <h2 className="text-base font-bold text-slate-900 dark:text-white truncate">
            {isToday ? t('home.todayHabits') : t('home.habitsFor', { date: formatShortDate(selectedDate, language) })}
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            {t('home.scheduled', { count: scheduledHabits.length, plural: scheduledHabits.length === 1 ? '' : 's' })}
          </p>
        </div>
        <button
          onClick={openCreateModal}
          className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-gradient-to-r from-rose-500 via-violet-600 to-blue-600 hover:brightness-105 text-white text-xs font-bold shadow-md shadow-violet-900/15 transition-all duration-200 active:scale-95 shrink-0"
        >
          <Plus className="w-3.5 h-3.5 stroke-[2.5]" />
          <span>{t('home.addHabit')}</span>
        </button>
      </div>

      {scheduledHabits.length > 0 ? (
        <div className="grid grid-cols-2 gap-3 sm:gap-3.5">
          {scheduledHabits.map((habit) => <HabitCard key={habit.id} habit={habit} />)}
        </div>
      ) : activeHabits.length === 0 ? (
        <div className="p-8 text-center bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm mt-4 animate-slide-up">
          <div className="w-16 h-16 mx-auto rounded-2xl bg-gradient-to-br from-amber-100 via-rose-100 to-violet-100 text-violet-700 dark:from-amber-950/50 dark:via-rose-950/40 dark:to-violet-950/50 dark:text-violet-300 flex items-center justify-center mb-4">
            <Target className="w-8 h-8 stroke-[1.8]" />
          </div>
          <h3 className="text-lg font-bold text-slate-900 dark:text-white mb-1">{t('home.noHabits')}</h3>
          <p className="text-xs text-slate-500 dark:text-slate-400 max-w-xs mx-auto mb-6 leading-relaxed">{t('home.noHabitsText')}</p>
          <button
            onClick={openCreateModal}
            className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-rose-500 via-violet-600 to-blue-600 hover:brightness-105 text-white font-bold text-xs shadow-md shadow-violet-900/15 transition-all duration-200 active:scale-95"
          >
            + {t('home.createFirst')}
          </button>
        </div>
      ) : (
        <div className="p-8 text-center bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 text-slate-500 animate-slide-up">
          <p className="text-sm font-semibold text-slate-700 dark:text-slate-300">{t('home.noScheduled')}</p>
          <p className="text-xs text-slate-400 mt-1">{t('home.restDay')}</p>
        </div>
      )}
    </div>
  );
};
