import React from 'react';
import { useHabit } from '../context/HabitContext';
import { Plus } from './DynamicIcon';

export const FloatingActionButton: React.FC = () => {
  const { activeTab, openCreateModal } = useHabit();

  // Show FAB only on 'home' and 'habits' tabs
  if (activeTab !== 'home' && activeTab !== 'habits') {
    return null;
  }

  return (
    <div className="fixed fab-safe right-4 sm:right-6 md:right-8 z-30">
      <button
        onClick={openCreateModal}
        aria-label="Create new habit"
        className="w-14 h-14 rounded-full bg-gradient-to-br from-rose-500 via-pink-500 to-violet-600 hover:brightness-105 active:scale-95 text-white shadow-lg shadow-rose-900/25 dark:shadow-black/50 border border-white/25 flex items-center justify-center transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-rose-500 focus:ring-offset-2 dark:focus:ring-offset-slate-950"
      >
        <Plus className="w-6 h-6 stroke-[2.5]" />
      </button>
    </div>
  );
};
