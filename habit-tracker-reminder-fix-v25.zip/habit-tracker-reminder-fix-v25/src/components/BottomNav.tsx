import React from 'react';
import { useHabit } from '../context/HabitContext';
import { TabType } from '../types';
import { CheckCircle2, Target, Calendar, BarChart3, Settings } from './DynamicIcon';

interface NavItem {
  id: TabType;
  labelKey: string;
  icon: React.ComponentType<{ className?: string }>;
}

const NAV_ITEMS: NavItem[] = [
  { id: 'home', labelKey: 'nav.today', icon: CheckCircle2 },
  { id: 'habits', labelKey: 'nav.habits', icon: Target },
  { id: 'calendar', labelKey: 'nav.calendar', icon: Calendar },
  { id: 'stats', labelKey: 'nav.stats', icon: BarChart3 },
  { id: 'settings', labelKey: 'nav.settings', icon: Settings },
];

export const BottomNav: React.FC = () => {
  const { activeTab, setActiveTab, t } = useHabit();

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-40 safe-bottom bg-white/95 dark:bg-slate-900/95 backdrop-blur-lg border-t border-slate-200 dark:border-slate-800 transition-colors">
      <div className="max-w-2xl mx-auto px-2">
        <div className="grid grid-cols-5 h-16 items-center">
          {NAV_ITEMS.map((item) => {
            const isActive = activeTab === item.id;
            const Icon = item.icon;
            return (
              <button
                key={item.id}
                onClick={() => setActiveTab(item.id)}
                className={`relative flex flex-col items-center justify-center h-full min-h-[44px] transition-all duration-200 active:scale-95 ${
                  isActive
                    ? 'text-blue-600 dark:text-blue-400 font-semibold'
                    : 'text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200'
                }`}
              >
                <Icon className={`w-5 h-5 transition-transform duration-200 ${isActive ? 'scale-110 stroke-[2.4]' : 'scale-100'}`} />
                <span className="text-[11px] font-medium tracking-tight mt-1">{t(item.labelKey)}</span>
              </button>
            );
          })}
        </div>
      </div>
    </nav>
  );
};
