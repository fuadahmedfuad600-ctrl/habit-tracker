import React, { useState, useMemo } from 'react';
import { useHabit } from '../context/HabitContext';
import { formatDateKey, formatMonthYear, formatShortDate, getDayNames, getMonthDaysGrid, getTodayKey } from '../utils/date';
import { getDailyProgress, isHabitApplicableOnDate } from '../utils/streak';
import { HabitCard } from './HabitCard';
import { ChevronLeft, ChevronRight, Calendar as CalendarIcon, Check } from './DynamicIcon';

type CalendarFilter = 'all' | 'completed' | 'partial' | 'none';

export const CalendarView: React.FC = () => {
  const { habits, completions, settings, language, t } = useHabit();
  const [currentDate, setCurrentDate] = useState<Date>(new Date());
  const [selectedDay, setSelectedDay] = useState<Date>(new Date());
  const [activeFilter, setActiveFilter] = useState<CalendarFilter>('all');

  const year = currentDate.getFullYear();
  const month = currentDate.getMonth();
  const monthGrid = getMonthDaysGrid(year, month, settings.weekStart);
  const dayHeaders = getDayNames(settings.weekStart, true, language);

  const prevMonth = () => setCurrentDate(new Date(year, month - 1, 1));
  const nextMonth = () => setCurrentDate(new Date(year, month + 1, 1));
  const jumpToCurrentMonth = () => { setCurrentDate(new Date()); setSelectedDay(new Date()); };

  const selectedDayKey = formatDateKey(selectedDay);
  const todayKey = getTodayKey();
  const scheduledForSelected = habits.filter((h) => isHabitApplicableOnDate(h, selectedDay, completions));
  const selectedDayProgress = getDailyProgress(habits, completions, selectedDay);

  const monthStats = useMemo(() => {
    let completedDays = 0, partialDays = 0, noCompletionDays = 0, restDays = 0;
    monthGrid.forEach(({ date, isCurrentMonth }) => {
      if (!isCurrentMonth) return;
      const key = formatDateKey(date);
      const progress = getDailyProgress(habits, completions, date);
      if (progress.totalCount === 0) restDays++;
      else if (progress.completedCount === progress.totalCount) completedDays++;
      else if (progress.completedCount > 0) partialDays++;
      else if (key <= todayKey) noCompletionDays++;
      // Future scheduled dates are intentionally not counted as missed.
    });
    return { completedDays, partialDays, noCompletionDays, restDays };
  }, [monthGrid, habits, completions, todayKey]);

  return (
    <div className="space-y-4 pb-24 animate-fade-in">
      <div className="bg-white dark:bg-slate-900 rounded-3xl p-4 sm:p-5 border border-slate-200 dark:border-slate-800 shadow-sm transition-all duration-200 hover:shadow-md">
        <div className="flex items-center justify-between mb-4 gap-3">
          <div className="min-w-0">
            <h2 className="text-lg font-bold text-slate-900 dark:text-white truncate">{formatMonthYear(currentDate, language)}</h2>
            <p className="text-xs text-slate-500 dark:text-slate-400">{t('calendar.openDay')}</p>
          </div>
          <div className="flex items-center gap-1.5 shrink-0">
            <button onClick={jumpToCurrentMonth} className="text-xs font-bold px-3 py-1.5 rounded-xl border border-rose-300 dark:border-rose-700 bg-rose-50 dark:bg-rose-950/60 text-rose-700 dark:text-rose-300 hover:bg-rose-100 dark:hover:bg-rose-900/60 transition-all duration-200 active:scale-95">{t('calendar.today')}</button>
            <div className="flex items-center gap-1 bg-slate-100 dark:bg-slate-800 p-1 rounded-xl border border-slate-200 dark:border-slate-700">
              <button onClick={prevMonth} aria-label={t('calendar.previousMonth')} className="w-7 h-7 rounded-lg flex items-center justify-center text-slate-700 dark:text-slate-200 hover:bg-white dark:hover:bg-slate-700 transition-colors"><ChevronLeft className="w-4 h-4" /></button>
              <button onClick={nextMonth} aria-label={t('calendar.nextMonth')} className="w-7 h-7 rounded-lg flex items-center justify-center text-slate-700 dark:text-slate-200 hover:bg-white dark:hover:bg-slate-700 transition-colors"><ChevronRight className="w-4 h-4" /></button>
            </div>
          </div>
        </div>

        <div className="mb-4 pb-3 border-b border-slate-100 dark:border-slate-800">
          <div className="text-[11px] font-semibold text-slate-500 dark:text-slate-400 mb-2">{t('calendar.filter')}</div>
          <div className="flex items-center gap-2 flex-wrap">
            <button type="button" onClick={() => setActiveFilter('all')} className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all border ${activeFilter === 'all' ? 'border-slate-900 bg-slate-900 text-white dark:border-white dark:bg-white dark:text-slate-900 shadow-sm' : 'border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700'}`}>{t('calendar.allDays')}</button>
            <button type="button" onClick={() => setActiveFilter(activeFilter === 'completed' ? 'all' : 'completed')} className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all border flex items-center gap-1.5 ${activeFilter === 'completed' ? 'border-emerald-600 bg-emerald-600 text-white shadow-sm' : 'border-emerald-400 bg-emerald-50/90 text-emerald-800 dark:bg-emerald-950/60 dark:border-emerald-500 dark:text-emerald-300 hover:bg-emerald-100'}`}><span className="w-2.5 h-2.5 rounded-full bg-emerald-500 shrink-0" /><span>{t('calendar.completed', { count: monthStats.completedDays })}</span></button>
            <button type="button" onClick={() => setActiveFilter(activeFilter === 'partial' ? 'all' : 'partial')} className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all border flex items-center gap-1.5 ${activeFilter === 'partial' ? 'border-amber-600 bg-amber-600 text-white shadow-sm' : 'border-amber-400 bg-amber-50/90 text-amber-800 dark:bg-amber-950/60 dark:border-amber-500 dark:text-amber-300 hover:bg-amber-100'}`}><span className="w-2.5 h-2.5 rounded-full bg-amber-500 shrink-0" /><span>{t('calendar.partial', { count: monthStats.partialDays })}</span></button>
            <button type="button" onClick={() => setActiveFilter(activeFilter === 'none' ? 'all' : 'none')} className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all border flex items-center gap-1.5 ${activeFilter === 'none' ? 'border-rose-600 bg-rose-600 text-white shadow-sm' : 'border-rose-400 bg-rose-50/90 text-rose-800 dark:bg-rose-950/60 dark:border-rose-400 dark:text-rose-300 hover:bg-rose-100'}`}><span className="w-2.5 h-2.5 rounded-full bg-rose-500 shrink-0" /><span>{t('calendar.none', { count: monthStats.noCompletionDays })}</span></button>
          </div>
        </div>

        <div className="grid grid-cols-7 gap-1.5 text-center mb-1.5">
          {dayHeaders.map((dh, i) => <div key={i} className="text-[10px] font-extrabold uppercase tracking-wide text-slate-500 dark:text-slate-400 py-1">{dh}</div>)}
        </div>

        <div className="grid grid-cols-7 gap-1.5 sm:gap-2">
          {monthGrid.map(({ date, isCurrentMonth }) => {
            const dateKey = formatDateKey(date);
            const isSelected = dateKey === selectedDayKey;
            const isToday = dateKey === todayKey;
            const isFuture = dateKey > todayKey;
            const progress = getDailyProgress(habits, completions, date);
            const isFullyDone = progress.totalCount > 0 && progress.completedCount === progress.totalCount;
            const isPartiallyDone = progress.completedCount > 0 && !isFullyDone;
            const isMissed = progress.totalCount > 0 && progress.completedCount === 0 && !isFuture;
            const hasScheduledHabits = progress.totalCount > 0;
            let matchesFilter = true;
            if (activeFilter === 'completed') matchesFilter = isFullyDone;
            else if (activeFilter === 'partial') matchesFilter = isPartiallyDone;
            else if (activeFilter === 'none') matchesFilter = isMissed;

            let statusStyle = 'border border-slate-200 bg-white text-slate-700 dark:border-slate-800 dark:bg-slate-900 dark:text-slate-300';
            if (isFullyDone) statusStyle = 'border border-emerald-400 bg-emerald-50 text-emerald-950 dark:bg-emerald-950/50 dark:border-emerald-500 dark:text-emerald-100 font-bold';
            else if (isPartiallyDone) statusStyle = 'border border-amber-400 bg-amber-50 text-amber-950 dark:bg-amber-950/50 dark:border-amber-500 dark:text-amber-100 font-bold';
            else if (isMissed) statusStyle = 'border border-slate-200 bg-slate-50 text-slate-700 dark:border-slate-800 dark:bg-slate-900 dark:text-slate-300';

            return (
              <button
                key={`${dateKey}-${isCurrentMonth ? 'm' : 'o'}`}
                type="button"
                onClick={() => setSelectedDay(date)}
                className={`calendar-day min-h-[56px] sm:min-h-[62px] p-1.5 rounded-xl flex flex-col items-center justify-between transition-all duration-200 relative ${statusStyle} ${!isCurrentMonth ? 'opacity-35' : ''} ${!matchesFilter && isCurrentMonth ? 'opacity-20' : ''} ${isSelected ? 'calendar-day-selected z-10 shadow-sm' : isToday ? 'calendar-day-today' : 'hover:-translate-y-0.5 hover:shadow-sm'}`}
              >
                <div className="w-full flex items-center justify-between px-0.5">
                  <span className="text-xs font-bold tabular-nums">{date.getDate()}</span>
                  {isToday && <span className="w-1.5 h-1.5 rounded-full bg-emerald-600 dark:bg-emerald-400 animate-pulse" />}
                </div>
                <div className="w-full flex items-center justify-center gap-1 py-0.5">
                  {progress.totalCount === 0 ? <span className="text-[9px] text-slate-400 font-medium">·</span> : isFullyDone ? <span className="inline-flex items-center gap-0.5 px-1 rounded-md bg-emerald-500 text-white text-[9px] font-bold"><Check className="w-2.5 h-2.5 stroke-[3]" /><span>{progress.completedCount}</span></span> : isPartiallyDone ? <span className="inline-flex items-center px-1 rounded-md bg-amber-500 text-white text-[9px] font-bold tabular-nums">{progress.completedCount}/{progress.totalCount}</span> : isMissed && hasScheduledHabits ? <span className="inline-flex items-center px-1 rounded-md bg-slate-300 text-slate-700 dark:bg-slate-700 dark:text-slate-200 text-[9px] font-bold tabular-nums">0/{progress.totalCount}</span> : <span className="text-[9px] text-slate-400 font-medium">{progress.totalCount}</span>}
                </div>
              </button>
            );
          })}
        </div>
      </div>

      <div className="space-y-3">
        <div className="flex items-center justify-between px-1">
          <div>
            <h3 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-1.5">
              <CalendarIcon className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
              <span>{formatShortDate(selectedDay, language)}</span>
              {selectedDayKey === todayKey && <span className="text-[10px] font-bold text-emerald-700 dark:text-emerald-300 bg-emerald-50 dark:bg-emerald-950/60 px-2 py-0.5 rounded-full border border-emerald-400 dark:border-emerald-600">{t('calendar.todayBadge')}</span>}
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">{t('calendar.dayProgress', { completed: selectedDayProgress.completedCount, total: selectedDayProgress.totalCount, percent: selectedDayProgress.percentage })}</p>
          </div>
        </div>

        {scheduledForSelected.length > 0 ? (
          <div className="grid grid-cols-2 gap-3 sm:gap-3.5">{scheduledForSelected.map((habit) => <HabitCard key={habit.id} habit={habit} />)}</div>
        ) : (
          <div className="p-6 text-center bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 text-slate-500 animate-slide-up">
            <p className="text-xs font-semibold text-slate-700 dark:text-slate-300">{t('calendar.noHabits', { date: formatShortDate(selectedDay, language) })}</p>
          </div>
        )}
      </div>
    </div>
  );
};
