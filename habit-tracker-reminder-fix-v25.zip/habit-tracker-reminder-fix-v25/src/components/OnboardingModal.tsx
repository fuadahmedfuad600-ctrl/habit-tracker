import React, { useState } from 'react';
import { useHabit } from '../context/HabitContext';
import { Target, Flame, BarChart3, ChevronRight, Check } from './DynamicIcon';

export const OnboardingModal: React.FC = () => {
  const { settings, updateSettings, requestNotifications, t } = useHabit();
  const [currentStep, setCurrentStep] = useState(0);

  if (settings.onboardingCompleted) return null;

  const steps = [
    { title: t('onboarding.buildTitle'), description: t('onboarding.buildText'), icon: Target, iconColor: 'bg-blue-100 dark:bg-blue-950/60 text-blue-600 dark:text-blue-400' },
    { title: t('onboarding.consistentTitle'), description: t('onboarding.consistentText'), icon: Flame, iconColor: 'bg-amber-100 dark:bg-amber-950/60 text-amber-500' },
    { title: t('onboarding.progressTitle'), description: t('onboarding.progressText'), icon: BarChart3, iconColor: 'bg-blue-100 dark:bg-blue-950/60 text-blue-600 dark:text-blue-400' },
  ];

  const handleFinish = async () => {
    updateSettings({ onboardingCompleted: true });
    await requestNotifications();
  };

  const nextStep = () => {
    if (currentStep < steps.length - 1) setCurrentStep((step) => step + 1);
    else void handleFinish();
  };

  const step = steps[currentStep];
  const StepIcon = step.icon;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 overlay-center-safe bg-slate-950/70 backdrop-blur-md animate-fade-in">
      <div className="bg-white dark:bg-slate-900 w-full max-w-sm rounded-3xl p-6 shadow-2xl border border-slate-200 dark:border-slate-800 text-center flex flex-col items-center animate-slide-up dialog-safe overflow-y-auto">
        <div className="w-full flex justify-end">
          <button onClick={() => void handleFinish()} className="text-xs font-semibold text-slate-400 hover:text-slate-600 dark:hover:text-slate-200">{t('onboarding.skip')}</button>
        </div>

        <div className={`w-20 h-20 rounded-3xl flex items-center justify-center my-6 ${step.iconColor} shadow-md animate-pop-in`}>
          <StepIcon className="w-10 h-10 stroke-[2]" />
        </div>

        <h2 className="text-xl font-extrabold text-slate-900 dark:text-white mb-2">{step.title}</h2>
        <p className="text-xs text-slate-500 dark:text-slate-400 max-w-[260px] leading-relaxed mb-6">{step.description}</p>

        <div className="flex items-center gap-1.5 mb-6">
          {steps.map((_, i) => <div key={i} className={`h-1.5 rounded-full transition-all duration-300 ${i === currentStep ? 'w-6 bg-blue-600 dark:bg-blue-400' : 'w-1.5 bg-slate-200 dark:bg-slate-700'}`} />)}
        </div>

        <button onClick={nextStep} className="w-full py-3.5 px-4 rounded-2xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-sm shadow-lg shadow-blue-600/30 flex items-center justify-center gap-2 transition-all active:scale-95">
          <span>{currentStep === steps.length - 1 ? t('onboarding.getStarted') : t('onboarding.continue')}</span>
          {currentStep === steps.length - 1 ? <Check className="w-4 h-4 stroke-[3]" /> : <ChevronRight className="w-4 h-4" />}
        </button>
      </div>
    </div>
  );
};
