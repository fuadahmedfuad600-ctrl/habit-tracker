import React, { useMemo, useState } from 'react';
import { useHabit } from '../context/HabitContext';
import { formatDateKey, formatMonthYear, formatTime12h, getMonthDaysGrid, getDayNames } from '../utils/date';
import { COLOR_OPTIONS } from '../utils/defaults';
import { translateCategory } from '../utils/i18n';
import { calculateHabitStats, isHabitCompletedOnDate, isHabitScheduledForDate } from '../utils/streak';
import {
  DynamicIcon,
  X,
  Edit2,
  Archive,
  Trash2,
  Flame,
  ChevronLeft,
  ChevronRight,
  Clock,
  RotateCcw,
  FileText,
} from './DynamicIcon';

export const HabitDetailModal: React.FC = () => {
  const {
    selectedHabitForDetail,
    setSelectedHabitForDetail,
    completions,
    toggleHabitCompletion,
    openEditModal,
    archiveHabit,
    unarchiveHabit,
    deleteHabit,
    settings,
    language,
    t,
    openNoteModal,
    getHabitNote,
  } = useHabit();

  const [viewDate, setViewDate] = useState<Date>(new Date());
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);

  const habit = selectedHabitForDetail;

  const stats = useMemo(() => {
    if (!habit) return null;
    return calculateHabitStats(habit, completions, new Date());
  }, [habit, completions]);

  if (!habit || !stats) return null;

  const colorConfig = COLOR_OPTIONS.find((c) => c.id === habit.color) || COLOR_OPTIONS[0];

  const year = viewDate.getFullYear();
  const month = viewDate.getMonth();

  const monthGrid = getMonthDaysGrid(year, month, settings.weekStart);

  const prevMonth = () => {
    setViewDate(new Date(year, month - 1, 1));
  };

  const nextMonth = () => {
    setViewDate(new Date(year, month + 1, 1));
  };

  const handleEdit = () => {
    openEditModal(habit);
    setSelectedHabitForDetail(null);
  };

  const handleArchive = () => {
    if (habit.isArchived) {
      unarchiveHabit(habit.id);
    } else {
      archiveHabit(habit.id);
    }
  };

  const handleDeletePermanent = () => {
    deleteHabit(habit.id, true);
    setShowDeleteConfirm(false);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4 overlay-safe bg-slate-950/60 backdrop-blur-sm animate-fade-in">
      <div className="bg-white dark:bg-slate-900 w-full max-w-lg rounded-t-3xl sm:rounded-3xl shadow-2xl border border-slate-200 dark:border-slate-800 sheet-safe max-h-[92vh] flex flex-col overflow-hidden">
        {/* Top Header */}
        <div className="flex items-center justify-between p-5 border-b border-slate-100 dark:border-slate-800">
          <div className="flex items-center gap-3">
            <div
              className={`w-11 h-11 rounded-xl flex items-center justify-center ${colorConfig.lightBg} ${colorConfig.text}`}
            >
              <DynamicIcon name={habit.icon} className="w-6 h-6 stroke-[2]" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-lg font-bold text-slate-900 dark:text-white">
                  {habit.name}
                </h2>
                {habit.isArchived && (
                  <span className="text-[11px] font-semibold text-amber-600 dark:text-amber-400 bg-amber-50 dark:bg-amber-950/50 px-2 py-0.5 rounded-full border border-amber-200 dark:border-amber-800">
                    {t('detail.archived')}
                  </span>
                )}
              </div>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                {translateCategory(language, habit.category)} · {habit.frequency === 'daily' ? t('detail.daily') : t('habit.selectedDays')}
                {habit.reminderEnabled && habit.reminderTime && (
                  <> · {formatTime12h(habit.reminderTime, language)}</>
                )}
              </p>
            </div>
          </div>

          <button
            onClick={() => setSelectedHabitForDetail(null)}
            className="w-9 h-9 rounded-full flex items-center justify-center text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-5 overflow-y-auto space-y-5 flex-1">
          {/* 4 Key Stat Cards */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
            <div className="p-3 bg-slate-50 dark:bg-slate-800/60 rounded-2xl border border-slate-200/80 dark:border-slate-800 text-center">
              <span className="text-[11px] font-medium text-slate-500 dark:text-slate-400 block">
                {t('detail.currentStreak')}
              </span>
              <div className="flex items-center justify-center gap-1 mt-1 font-bold text-lg text-amber-500">
                <Flame className="w-4 h-4 fill-amber-500 text-amber-500" />
                <span className="tabular-nums">{stats.currentStreak} d</span>
              </div>
            </div>

            <div className="p-3 bg-slate-50 dark:bg-slate-800/60 rounded-2xl border border-slate-200/80 dark:border-slate-800 text-center">
              <span className="text-[11px] font-medium text-slate-500 dark:text-slate-400 block">
                {t('detail.bestStreak')}
              </span>
              <div className="flex items-center justify-center gap-1 mt-1 font-bold text-lg text-slate-800 dark:text-slate-200">
                <span className="tabular-nums">{stats.bestStreak} days</span>
              </div>
            </div>

            <div className="p-3 bg-slate-50 dark:bg-slate-800/60 rounded-2xl border border-slate-200/80 dark:border-slate-800 text-center">
              <span className="text-[11px] font-medium text-slate-500 dark:text-slate-400 block">
                {t('detail.consistency')}
              </span>
              <div className={`mt-1 font-bold text-lg tabular-nums ${colorConfig.text}`}>
                {stats.completionRate}%
              </div>
            </div>

            <div className="p-3 bg-slate-50 dark:bg-slate-800/60 rounded-2xl border border-slate-200/80 dark:border-slate-800 text-center">
              <span className="text-[11px] font-medium text-slate-500 dark:text-slate-400 block">
                {t('detail.totalDays')}
              </span>
              <div className="mt-1 font-bold text-lg text-slate-800 dark:text-slate-200 tabular-nums">
                {stats.totalCompleted}
              </div>
            </div>
          </div>

          {habit.description && (
            <div style={{ backgroundColor: `${colorConfig.hex}14`, borderColor: `${colorConfig.hex}55` }} className="p-3 border rounded-xl text-xs text-slate-700 dark:text-slate-200">
              💡 {habit.description}
            </div>
          )}

          {/* Month Completion Calendar */}
          <div className="bg-slate-50 dark:bg-slate-800/40 rounded-2xl p-4 border border-slate-200/80 dark:border-slate-800">
            <div className="flex items-center justify-between mb-3">
              <span className="text-xs font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400">
                {formatMonthYear(viewDate, language)}
              </span>
              <div className="flex items-center gap-1">
                <button
                  onClick={prevMonth}
                  className="p-1 rounded-lg hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-600 dark:text-slate-300"
                >
                  <ChevronLeft className="w-4 h-4" />
                </button>
                <button
                  onClick={nextMonth}
                  className="p-1 rounded-lg hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-600 dark:text-slate-300"
                >
                  <ChevronRight className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Grid */}
            <div className="grid grid-cols-7 gap-1 text-center">
              {getDayNames(settings.weekStart, true, language).map((dayLetter, i) => (
                <div key={i} className="text-[10px] font-bold text-slate-400 pb-1">
                  {dayLetter}
                </div>
              ))}

              {monthGrid.map(({ date, isCurrentMonth }, idx) => {
                const dateKey = formatDateKey(date);
                const isScheduled = isHabitScheduledForDate(habit, date);
                const isCompleted = isHabitCompletedOnDate(habit.id, dateKey, completions);
                const isPastOrToday = date <= new Date();

                return (
                  <button
                    key={idx}
                    type="button"
                    onClick={() => {
                      if (isPastOrToday) {
                        toggleHabitCompletion(habit.id, dateKey);
                      }
                    }}
                    title={`${dateKey}: ${isCompleted ? t('detail.completed') : t('detail.notCompleted')}`}
                    disabled={!isPastOrToday}
                    className={`h-8 rounded-lg flex flex-col items-center justify-center text-xs transition-all ${
                      !isCurrentMonth ? 'opacity-20' : ''
                    } ${
                      isCompleted
                        ? 'font-extrabold shadow-sm'
                        : isScheduled && isPastOrToday
                        ? 'bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-slate-700'
                        : 'text-slate-400 dark:text-slate-600'
                    }`}
                    style={isCompleted ? { backgroundColor: colorConfig.hex, color: colorConfig.darkText ? '#3d3108' : '#ffffff' } : undefined}
                  >
                    <span>{date.getDate()}</span>
                  </button>
                );
              })}
            </div>

            <p className="text-[11px] text-slate-400 dark:text-slate-500 mt-3 text-center">
              {t('detail.tapDate')}
            </p>
          </div>

          {/* Delete Confirmation Box */}
          {showDeleteConfirm && (
            <div className="p-4 bg-red-50 dark:bg-red-950/40 border border-red-200 dark:border-red-900 rounded-2xl space-y-3">
              <p className="text-xs font-medium text-red-700 dark:text-red-300">
                {t('detail.confirmDelete', { name: habit.name })}
              </p>
              <div className="flex gap-2">
                <button
                  onClick={() => setShowDeleteConfirm(false)}
                  className="flex-1 py-1.5 px-3 rounded-lg text-xs font-semibold bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-slate-700"
                >
                  {t('habit.cancel')}
                </button>
                <button
                  onClick={handleDeletePermanent}
                  className="flex-1 py-1.5 px-3 rounded-lg text-xs font-semibold bg-red-600 text-white hover:bg-red-500"
                >
                  {t('detail.deletePermanent')}
                </button>
              </div>
            </div>
          )}

          {/* Quick Offline Action: Daily Log Note */}
          <div className="pt-1">
            <button
              onClick={() => {
                openNoteModal(habit);
                setSelectedHabitForDetail(null);
              }}
              style={{ borderColor: `${colorConfig.hex}bb`, backgroundColor: `${colorConfig.hex}16`, color: colorConfig.hex }} className="w-full py-2.5 px-3 rounded-2xl border-2 flex items-center justify-center gap-2 text-xs font-bold transition-all shadow-xs hover:brightness-95"
            >
              <FileText className="w-4 h-4" />
              <span>{t('detail.reflection')}</span>
            </button>
          </div>

          {/* Action Buttons */}
          <div className="flex items-center gap-2 pt-2">
            <button
              onClick={handleEdit}
              className="flex-1 py-2.5 px-3 rounded-xl border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 flex items-center justify-center gap-1.5 text-xs font-semibold"
            >
              <Edit2 className="w-3.5 h-3.5" />
              {t('detail.edit')}
            </button>

            <button
              onClick={handleArchive}
              className="flex-1 py-2.5 px-3 rounded-xl border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 flex items-center justify-center gap-1.5 text-xs font-semibold"
            >
              {habit.isArchived ? (
                <>
                  <RotateCcw className="w-3.5 h-3.5" />
                  {t('detail.restore')}
                </>
              ) : (
                <>
                  <Archive className="w-3.5 h-3.5" />
                  {t('detail.archive')}
                </>
              )}
            </button>

            <button
              onClick={() => setShowDeleteConfirm(true)}
              className="py-2.5 px-3 rounded-xl border border-red-200 dark:border-red-900/60 text-red-600 dark:text-red-400 hover:bg-red-50 dark:hover:bg-red-950/40 flex items-center justify-center gap-1.5 text-xs font-semibold"
              title={t('detail.delete')}
            >
              <Trash2 className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
