import React, { useMemo } from 'react';
import { useHabit } from '../context/HabitContext';
import { formatDateKey, getTodayKey, getWeekDays, formatShortDate } from '../utils/date';
import { getDailyProgress } from '../utils/streak';

export const DateStrip: React.FC = () => {
  const { selectedDate, setSelectedDate, settings, habits, completions, t, language } = useHabit();
  const todayKey = getTodayKey();
  const selectedKey = formatDateKey(selectedDate);

  const weekDays = useMemo(() => getWeekDays(selectedDate, settings.weekStart), [selectedDate, settings.weekStart]);
  const jumpToToday = () => setSelectedDate(new Date());
  const isTodaySelected = selectedKey === todayKey;

  return (
    <div className="bg-white dark:bg-slate-900 rounded-2xl p-3 border border-slate-200/80 dark:border-slate-800 shadow-sm transition-all duration-200 hover:shadow-md">
      <div className="flex items-center justify-between mb-2 px-1 gap-2">
        <span className="text-xs font-semibold uppercase tracking-wider text-slate-400 dark:text-slate-500">{t('date.weeklySchedule')}</span>
        {!isTodaySelected && (
          <button onClick={jumpToToday} className="text-xs font-bold text-rose-600 dark:text-rose-300 hover:underline">{t('date.jumpToday')}</button>
        )}
      </div>

      <div className="grid grid-cols-7 gap-1.5">
        {weekDays.map((day) => {
          const key = formatDateKey(day);
          const isSelected = key === selectedKey;
          const isToday = key === todayKey;
          const progress = getDailyProgress(habits, completions, day);
          const dayLabel = day.toLocaleDateString(language === 'bn' ? 'bn-BD' : language === 'hi' ? 'hi-IN' : 'en-US', { weekday: 'narrow' });

          return (
            <button
              key={key}
              type="button"
              onClick={() => setSelectedDate(day)}
              className={`min-w-0 rounded-xl border p-2 flex flex-col items-center gap-1 transition-all duration-200 active:scale-95 ${
                isSelected
                  ? 'border-transparent bg-gradient-to-br from-violet-600 to-blue-600 text-white ring-1 ring-violet-400 shadow-md shadow-violet-600/20'
                  : 'border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 hover:border-rose-300 dark:hover:border-rose-800'
              }`}
            >
              <span className={`text-[10px] font-semibold ${isSelected ? 'text-white/75' : 'text-slate-400 dark:text-slate-500'}`}>{dayLabel}</span>
              <span className={`text-sm font-extrabold tabular-nums ${isSelected ? 'text-white' : isToday ? 'text-rose-600 dark:text-rose-300' : 'text-slate-700 dark:text-slate-300'}`}>{day.getDate()}</span>
              <span className={`w-1.5 h-1.5 rounded-full ${isSelected ? 'bg-white' : progress.totalCount === 0 ? 'bg-slate-200 dark:bg-slate-700' : progress.completedCount === progress.totalCount ? 'bg-emerald-500' : progress.completedCount > 0 ? 'bg-amber-500' : key < todayKey ? 'bg-rose-400' : 'bg-slate-200 dark:bg-slate-700'}`} />
            </button>
          );
        })}
      </div>
      <p className="text-[10px] text-slate-400 mt-2 px-1 truncate">{formatShortDate(selectedDate, language)}</p>
    </div>
  );
};
