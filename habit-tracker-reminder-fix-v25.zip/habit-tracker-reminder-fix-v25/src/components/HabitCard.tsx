import React from 'react';
import { useHabit } from '../context/HabitContext';
import { Habit } from '../types';
import { formatDateKey, formatTime12h } from '../utils/date';
import { COLOR_OPTIONS } from '../utils/defaults';
import { calculateHabitStats, isHabitCompletedOnDate } from '../utils/streak';
import { translateCategory } from '../utils/i18n';
import { DynamicIcon, Check, Clock, Flame, FileText } from './DynamicIcon';

interface HabitCardProps { habit: Habit; }

function darkenHex(hex: string, amount = 0.13): string {
  const value = hex.replace('#', '');
  if (!/^[0-9a-fA-F]{6}$/.test(value)) return hex;
  const channels = [0, 2, 4].map((offset) => Math.max(0, Math.round(parseInt(value.slice(offset, offset + 2), 16) * (1 - amount))));
  return `#${channels.map((channel) => channel.toString(16).padStart(2, '0')).join('')}`;
}

export const HabitCard: React.FC<HabitCardProps> = ({ habit }) => {
  const { completions, selectedDate, toggleHabitCompletion, setSelectedHabitForDetail, openNoteModal, getHabitNote, t, language } = useHabit();
  const dateKey = formatDateKey(selectedDate);
  const isCompleted = isHabitCompletedOnDate(habit.id, dateKey, completions);
  const stats = calculateHabitStats(habit, completions, selectedDate);
  const existingNote = getHabitNote(habit.id, dateKey);
  const colorConfig = COLOR_OPTIONS.find((c) => c.id === habit.color) || COLOR_OPTIONS[0];
  const foreground = colorConfig.darkText ? '#3d3108' : '#ffffff';
  const subtleForeground = colorConfig.darkText ? 'rgba(61,49,8,0.76)' : 'rgba(255,255,255,0.82)';
  const checkColor = colorConfig.hex;
  const cardBackground = colorConfig.darkText
    ? 'linear-gradient(145deg, #fde047 0%, #facc15 52%, #eab308 100%)'
    : `linear-gradient(145deg, ${colorConfig.hex} 0%, ${darkenHex(colorConfig.hex)} 100%)`;

  const handleToggle = (e: React.MouseEvent) => { e.stopPropagation(); toggleHabitCompletion(habit.id, dateKey); };
  const handleNoteClick = (e: React.MouseEvent) => { e.stopPropagation(); openNoteModal(habit, dateKey); };

  return (
    <article
      onClick={() => setSelectedHabitForDetail(habit)}
      role="button"
      tabIndex={0}
      onKeyDown={(e) => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); setSelectedHabitForDetail(habit); } }}
      aria-label={habit.name}
      className={`habit-color-card group relative flex min-h-[158px] min-w-0 flex-col overflow-hidden rounded-[22px] p-3.5 sm:p-4 cursor-pointer transition-all duration-200 active:scale-[0.985] hover:-translate-y-0.5 hover:shadow-lg ${isCompleted ? 'ring-2 ring-white/65 shadow-md' : 'shadow-sm'}`}
      style={{ background: cardBackground, color: foreground }}
    >
      <div className="pointer-events-none absolute -right-7 -top-7 h-24 w-24 rounded-full border-[15px] border-white/10" />
      <div className="pointer-events-none absolute -bottom-10 -left-8 h-24 w-24 rounded-full bg-white/10 blur-sm" />

      <div className="relative z-10 flex items-start justify-between gap-2">
        <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-2xl border border-white/25 bg-white/20 shadow-sm backdrop-blur-sm">
          <DynamicIcon name={habit.icon} className="h-5 w-5 stroke-[2.2]" />
        </div>
        <div className="flex items-center gap-1.5">
          <button
            type="button"
            onClick={handleNoteClick}
            title={existingNote ? t('habit.note') : t('habit.note')}
            aria-label={t('habit.note')}
            className={`flex h-8 w-8 items-center justify-center rounded-full border border-white/25 transition-all active:scale-90 ${existingNote ? 'bg-white/35' : 'bg-white/10 hover:bg-white/25'}`}
            style={{ color: foreground }}
          >
            <FileText className="h-4 w-4" />
          </button>
          <button
            type="button"
            onClick={handleToggle}
            aria-label={isCompleted ? t('habit.incomplete', { name: habit.name }) : t('habit.complete', { name: habit.name })}
            className={`flex h-8 w-8 shrink-0 items-center justify-center rounded-full border transition-all duration-200 active:scale-90 ${isCompleted ? 'border-white bg-white shadow-sm' : 'border-white/75 bg-white/20 hover:bg-white/35'}`}
            style={{ color: isCompleted ? checkColor : foreground }}
          >
            <Check className={`h-4 w-4 stroke-[3] transition-transform ${isCompleted ? 'scale-100' : 'scale-75 opacity-60'}`} />
          </button>
        </div>
      </div>

      <div className="relative z-10 mt-3 min-w-0">
        <h3 className="line-clamp-2 min-h-[2.5rem] break-words text-[14px] font-extrabold leading-5 sm:text-[15px]" style={{ color: foreground }}>
          {habit.name}
        </h3>
        <p className="mt-0.5 truncate text-[10px] font-semibold uppercase tracking-wide" style={{ color: subtleForeground }}>
          {translateCategory(language, habit.category)}
        </p>
      </div>

      <div className="relative z-10 mt-auto flex min-w-0 items-center justify-between gap-1.5 pt-3 text-[11px] font-bold" style={{ color: foreground }}>
        <span className="inline-flex min-w-0 items-center gap-1 rounded-full bg-white/15 px-2 py-1">
          <Flame className="h-3.5 w-3.5 shrink-0 fill-current" />
          <span className="tabular-nums">{stats.currentStreak}</span>
        </span>
        {habit.reminderEnabled && habit.reminderTime ? (
          <span className="inline-flex min-w-0 items-center gap-1 truncate rounded-full bg-white/15 px-2 py-1" title={formatTime12h(habit.reminderTime, language)}>
            <Clock className="h-3 w-3 shrink-0" />
            <span className="truncate tabular-nums">{formatTime12h(habit.reminderTime, language)}</span>
          </span>
        ) : (
          <span className="text-[10px] font-semibold" style={{ color: subtleForeground }}>{isCompleted ? '✓' : ''}</span>
        )}
      </div>
    </article>
  );
};
