/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { HabitProvider, useHabit } from './context/HabitContext';
import { Header } from './components/Header';
import { BottomNav } from './components/BottomNav';
import { FloatingActionButton } from './components/FloatingActionButton';
import { HomeView } from './components/HomeView';
import { HabitsManagerView } from './components/HabitsManagerView';
import { CalendarView } from './components/CalendarView';
import { StatsView } from './components/StatsView';
import { SettingsView } from './components/SettingsView';
import { HabitModal } from './components/HabitModal';
import { HabitDetailModal } from './components/HabitDetailModal';
import { NotificationCenterModal } from './components/NotificationCenterModal';
import { OnboardingModal } from './components/OnboardingModal';
import { HabitNoteModal } from './components/HabitNoteModal';
import { AchievementsModal } from './components/AchievementsModal';
import { SplashScreen } from './components/SplashScreen';

const AppContent: React.FC = () => {
  const {
    activeTab,
    isNoteModalOpen,
    noteTarget,
    closeNoteModal,
    isAchievementsOpen,
    setIsAchievementsOpen,
  } = useHabit();

  return (
    <div className="app-shell bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 flex flex-col font-sans transition-colors selection:bg-emerald-500 selection:text-white">
      {/* Top Header */}
      <Header />

      {/* Main Content Area */}
      <main className={`flex-1 w-full max-w-2xl mx-auto px-3 sm:px-4 pt-4 ${activeTab === 'home' || activeTab === 'habits' ? 'main-pad-fab' : 'main-pad-nav'}`}>
        {activeTab === 'home' && <HomeView />}
        {activeTab === 'habits' && <HabitsManagerView />}
        {activeTab === 'calendar' && <CalendarView />}
        {activeTab === 'stats' && <StatsView />}
        {activeTab === 'settings' && <SettingsView />}
      </main>

      {/* Floating Action Button for Home & Habits screens */}
      <FloatingActionButton />

      {/* Persistent Bottom Tab Bar */}
      <BottomNav />

      {/* Modals & Dialogs */}
      <HabitModal />
      <HabitDetailModal />
      <NotificationCenterModal />
      <OnboardingModal />

      {/* Offline Habit Reflection Note Modal */}
      {isNoteModalOpen && noteTarget && (
        <HabitNoteModal
          habit={noteTarget.habit}
          dateKey={noteTarget.dateKey}
          onClose={closeNoteModal}
        />
      )}

      {/* Offline Milestones & Badges Modal */}
      {isAchievementsOpen && (
        <AchievementsModal onClose={() => setIsAchievementsOpen(false)} />
      )}
    </div>
  );
};

export default function App() {
  return (
    <HabitProvider>
      <AppContent />
      <SplashScreen />
    </HabitProvider>
  );
}
