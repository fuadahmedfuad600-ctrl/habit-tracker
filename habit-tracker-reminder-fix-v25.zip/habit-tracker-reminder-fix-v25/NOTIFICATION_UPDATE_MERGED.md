# Notification update integration notes

- Replaced `src/utils/notifications.ts` with the supplied recurring-per-habit reminder synchronization logic.
- Replaced `android/app/src/main/java/com/habittracker/app/ReminderReceiver.java` and `ReminderScheduler.java` with the supplied native notification implementation.
- Added a compatibility bridge in `ReminderScheduler.java` for older dated reminders saved under the `items` preference key. This cancels old dated alarms when new recurring rules arrive and can restore legacy pending reminders on reboot until the web bundle syncs.
- The native scheduler can also recognize the old `{id, title, body, at}` payload. This prevents a stale embedded JavaScript bundle from misinterpreting older reminders as new recurring rules.
- The app's bundled web assets are generated build output. Run `npm install` and `npm run build:android` from this folder (the folder containing `package.json`) before creating the APK, so the updated TypeScript is actually bundled into Android.
- Existing UI, heatmap, habit creation logic, theme, and app assets were otherwise left as supplied in the original ZIP.

Validation limitation: the dependency installation could not complete in this environment, so the updated web bundle and APK were not built here. Run the documented build steps on a computer with npm dependencies available, then review the build output before installing the APK.
