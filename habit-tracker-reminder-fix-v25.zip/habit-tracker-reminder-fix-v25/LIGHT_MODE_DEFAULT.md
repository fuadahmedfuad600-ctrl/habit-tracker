# Default Light Mode

This update changes the app's default appearance to Light mode. Existing saved Dark mode choices are preserved. Older saved System/default settings are migrated to Light so an update does not unexpectedly launch in dark mode. Users can still choose Dark or System manually in Settings.

Only the theme default and its startup migration were changed. Habit data and notification behavior were left untouched.
