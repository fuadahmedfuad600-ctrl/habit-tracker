# Reminder bug fix (v1.0.25)

## What was checked (v24)
- Native alarms already use one PendingIntent request code + one notification ID per habit
  (derived from the habit ID), so alarms of different habits do not overwrite each other.

## Defects fixed
1. `src/utils/notifications.ts` - the JS sync returned early (or aborted) when the permission step,
   battery prompt or old-alarm cleanup failed, so `scheduleReminders()` was never called. Habits that
   were armed in an earlier successful sync kept firing; habits added later were never armed.
   Every step is now independent and alarms are always (re)armed.
2. `ReminderReceiver.java` - the next occurrence is now armed BEFORE the notification is shown
   (inside try/catch), so one failure can no longer stop a habit from repeating.
3. Time / time-zone changes, OEM quick-boot and exact-alarm permission changes now rebuild all alarms
   (`AndroidManifest.xml` + `ReminderReceiver.java`).
4. Debug logging (Logcat tags `ReminderScheduler`, `ReminderReceiver`, and `[HabitReminder]` from JS):
   habit ID, alarm ID, scheduled local time + time zone, TRIGGER event, NOTIFY result
   (notifications allowed, channel importance, showing in tray).
5. New native method `getScheduleDebug()` returns which alarms are armed and when each fires next.

## Logcat filter
adb logcat -s ReminderScheduler ReminderReceiver chromium:I Capacitor/Console:I
