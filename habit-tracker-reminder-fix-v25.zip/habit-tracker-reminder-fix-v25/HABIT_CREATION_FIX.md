# Multiple habit creation fix

The create-habit modal now deliberately resets its open state before reopening. This makes the form lifecycle reinitialize when a new habit is requested, including Android WebView cases where the prior modal close/open state may not have refreshed cleanly.

The change is applied both to `src/context/HabitContext.tsx` and the bundled JavaScript loaded by the Android Gradle project at `android/app/src/main/assets/public/assets/`.

The existing Light Mode default and notification scheduling changes are retained. No habit data is deleted or migrated by this fix.


Android version metadata is bumped to `versionCode 21` / `versionName 1.0.21` for this updated build.
