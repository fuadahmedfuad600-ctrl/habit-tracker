@echo off
setlocal
cd /d "%~dp0"
echo === Habit Tracker local-notifications build repair ===
if not exist package.json (
  echo Run this BAT from the extracted project root where package.json exists.
  pause
  exit /b 1
)
if exist node_modules rmdir /s /q node_modules
if exist android\.gradle rmdir /s /q android\.gradle
if exist android\build rmdir /s /q android\build
call npm install
if errorlevel 1 goto :error
call node scripts\patch-local-notifications.cjs
if errorlevel 1 goto :error
call npx cap sync android
if errorlevel 1 goto :error
echo.
echo Repair completed. Open the android folder in Android Studio and Sync Project with Gradle Files.
echo Use Gradle JDK = jbr-21.
pause
exit /b 0
:error
echo.
echo Repair failed. Read the command output above.
pause
exit /b 1
