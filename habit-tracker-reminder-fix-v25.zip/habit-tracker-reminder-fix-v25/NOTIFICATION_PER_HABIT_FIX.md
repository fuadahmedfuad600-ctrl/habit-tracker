# Per-habit reminder hardening (retained in v1.0.24)

## What changed

- Each enabled, non-archived habit is stored as its own repeating native Android reminder rule.
- The native scheduler now derives a stable alarm request ID from each habit ID and enforces uniqueness across a sync batch. This protects Android `PendingIntent` identity from ID collisions.
- The receiver reschedules only the habit whose alarm just fired; other habits' alarms remain independent.
- Native scheduling writes per-habit details to Logcat under `ReminderScheduler`, including the habit ID, alarm ID, and next scheduled local time.
- The Android receiver stores the last 50 fired reminders. When the app is reopened, these are copied into the in-app notification bell history without creating another system notification.
- The Reminder time control includes +/- 1 hour and +/- 5 minute buttons plus the standard time picker.
- The v1.0.24 UI update adds a consistent multi-colour design throughout the main pages and buttons. The five-item bottom navigation remains unchanged. Existing light/dark modes and core screens remain.

## Version

- `versionCode`: 24
- `versionName`: 1.0.24

## Build on Windows

1. Open a terminal in the extracted project root (the folder containing `package.json`).
2. Run `npm install`.
3. Run `npm run build:android` so the Android `assets/public` bundle matches the editable source.
4. Open the `android` folder in Android Studio, sync Gradle, then choose **Build > Build APK(s)**.

## Device test checklist

1. Create two or more habits with reminders at different times.
2. Save, close the app, and verify that each reminder arrives at its own time.
3. Edit only the second habit's time and verify the first habit's time does not change.
4. Change app language and verify subsequent reminder text follows that language.
5. Reopen the app and verify the fired reminders appear in the bell history only once.
6. If a reminder is still late/missing, inspect Logcat for `ReminderScheduler` and check Android notification/exact-alarm permissions and the device's battery restrictions.

The JavaScript/source checks pass in the provided environment, but a final Android APK build could not be performed here because package/Gradle downloads were blocked by unavailable network DNS. Device delivery should be verified after building and installing the APK.
