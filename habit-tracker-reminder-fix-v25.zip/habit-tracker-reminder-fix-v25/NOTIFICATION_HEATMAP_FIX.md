# Notification and Habit Consistency Heatmap Fix (v21)

- The Android WebView bundle now uses the registered native `ReminderSettings` plugin for background habit alarms, matching the Android `ReminderScheduler` implementation included in the project.
- Each active habit reminder is expanded into dated alarm entries for the next 14 days. IDs are collision-checked within each sync batch so one habit cannot overwrite another habit's PendingIntent due to an ID collision.
- Scheduling sync requests remain serialized so an older habit snapshot cannot replace a newer set of habits.
- Notification messages continue to follow the language selected in app settings (English, Bangla, or Hindi).
- The Habit Consistency Heatmap now uses a constrained weekday column and four flexible date columns. Selected/today outlines are inset into their own cells and do not scale into adjacent cells; weekday labels truncate instead of overflowing.
- Both source files and Android's offline bundled JS/CSS assets were updated.
- Android version metadata: `versionCode 21`, `versionName 1.0.21`.

## Validation

The bundled JavaScript syntax was checked with Node.js. A full Gradle/APK build could not be run in this environment because npm dependencies cannot be downloaded (DNS/network failure). Build the project in Android Studio, then test two habits with different reminder times on a real device.
