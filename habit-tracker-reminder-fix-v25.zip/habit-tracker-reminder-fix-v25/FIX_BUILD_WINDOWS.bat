@echo off
setlocal
cd /d "%~dp0"

echo ================================================
echo Habit Tracker - Update Web Bundle and Android
echo ================================================

echo.
echo [1/4] Checking Java...
java -version
if errorlevel 1 (
  echo Java was not found. Install/use Android Studio's Embedded JDK 17 or higher.
  pause
  exit /b 1
)

echo.
echo [2/4] Checking Node.js and npm...
node --version
if errorlevel 1 (
  echo Node.js was not found. Install Node.js LTS, then reopen this script.
  pause
  exit /b 1
)
npm --version
if errorlevel 1 (
  echo npm was not found. Repair the Node.js installation.
  pause
  exit /b 1
)

echo.
echo [3/4] Installing project dependencies...
call npm install
if errorlevel 1 (
  echo npm install failed. Check your internet connection and Node.js/npm installation.
  pause
  exit /b 1
)

echo.
echo [4/4] Building the web bundle and syncing Android assets...
call npm run build:android
if errorlevel 1 (
  echo Web build or Capacitor Android sync failed. Read the error above before building the APK.
  pause
  exit /b 1
)

echo.
echo DONE. Open the android folder in Android Studio, sync Gradle, then choose Build APK(s).
pause
