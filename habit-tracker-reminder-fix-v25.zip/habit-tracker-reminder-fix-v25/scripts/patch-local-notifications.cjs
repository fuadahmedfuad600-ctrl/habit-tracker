// Kept as an optional repair utility for environments that may have an
// already-installed, locally modified @capacitor/local-notifications package.
// It restores the official Android Gradle module configuration for v8.3.1.
const fs = require('fs');
const path = require('path');

const file = path.join('node_modules', '@capacitor', 'local-notifications', 'android', 'build.gradle');
if (!fs.existsSync(file)) process.exit(0);

const official = `ext {

    capacitorVersion = System.getenv('CAPACITOR_VERSION')
    junitVersion = project.hasProperty('junitVersion') ? rootProject.ext.junitVersion : '4.13.2'
    androidxAppCompatVersion = project.hasProperty('androidxAppCompatVersion') ? rootProject.ext.androidxAppCompatVersion : '1.7.1'
    androidxJunitVersion = project.hasProperty('androidxJunitVersion') ? rootProject.ext.androidxJunitVersion : '1.3.0'
    androidxEspressoCoreVersion = project.hasProperty('androidxEspressoCoreVersion') ? rootProject.ext.androidxEspressoCoreVersion : '3.7.0'
}

buildscript {
    ext.kotlin_version = project.hasProperty('kotlin_version') ? rootProject.ext.kotlin_version : '2.0.21'
    repositories {
        google()
        mavenCentral()
        maven {
            url = "https://plugins.gradle.org/m2/"
        }
    }
    dependencies {
        classpath 'com.android.tools.build:gradle:8.13.0'
        classpath "org.jetbrains.kotlin:kotlin-gradle-plugin:$kotlin_version"
        if (System.getenv("CAP_PLUGIN_PUBLISH") == "true") {
            classpath 'io.github.gradle-nexus:publish-plugin:1.3.0'
        }
    }
}

apply plugin: 'com.android.library'
if (project.extensions.findByName('kotlin') == null) {
    apply plugin: 'kotlin-android'
}

if (System.getenv("CAP_PLUGIN_PUBLISH") == "true") {
    apply plugin: 'io.github.gradle-nexus.publish-plugin'
    apply from: file('../scripts/android/publish-root.gradle')
    apply from: file('../scripts/android/publish-module.gradle')
}

android {
    namespace = "com.capacitorjs.plugins.localnotifications"
    compileSdk = project.hasProperty('compileSdkVersion') ? rootProject.ext.compileSdkVersion : 36
    defaultConfig {
        minSdkVersion project.hasProperty('minSdkVersion') ? rootProject.ext.minSdkVersion : 24
        targetSdkVersion project.hasProperty('targetSdkVersion') ? rootProject.ext.targetSdkVersion : 36
        versionCode 1
        versionName "1.0"
        testInstrumentationRunner "androidx.test.runner.AndroidJUnitRunner"
    }
    buildTypes {
        release {
            minifyEnabled false
            proguardFiles getDefaultProguardFile('proguard-android-optimize.txt'), 'proguard-rules.pro'
        }
    }
    lintOptions {
        abortOnError = false
    }
    compileOptions {
        sourceCompatibility JavaVersion.VERSION_21
        targetCompatibility JavaVersion.VERSION_21
    }
    publishing {
        singleVariant("release")
    }
}

kotlin {
    jvmToolchain(21)
}

repositories {
    google()
    mavenCentral()
}

dependencies {
    implementation fileTree(dir: 'libs', include: ['*.jar'])
    if (System.getenv("CAP_PLUGIN_PUBLISH") == "true") {
        implementation "com.capacitorjs:core:$capacitorVersion"
    } else {
        implementation project(':capacitor-android')
    }
    implementation "androidx.appcompat:appcompat:$androidxAppCompatVersion"
    testImplementation "junit:junit:$junitVersion"
    androidTestImplementation "androidx.test.ext:junit:$androidxJunitVersion"
    androidTestImplementation "androidx.test.espresso:espresso-core:$androidxEspressoCoreVersion"
}
`;

const current = fs.readFileSync(file, 'utf8').replace(/\r\n/g, '\n');
if (current !== official) {
  fs.writeFileSync(file, official, 'utf8');
  console.log('Restored the official @capacitor/local-notifications Android Gradle configuration.');
}
