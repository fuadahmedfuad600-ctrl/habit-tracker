# Habit Tracker - Android Studio APK Build Guide (অ্যান্ড্রয়েড স্টুডিও দিয়ে APK তৈরির গাইড)

এই অ্যাপটি Android Studio দিয়ে সরাসরি APK তৈরি করার জন্য সম্পূর্ণ রেডি করা হয়েছে।

---

## 🚀 কিভাবে Android Studio দিয়ে APK তৈরি করবেন (Step-by-Step)

### ধাপ ১: প্রজেক্ট ওপেন করুন
1. আপনার কম্পিউটারে **Android Studio** চালু করুন।
2. **Open** এ ক্লিক করুন।
3. প্রজেক্টের রুট থেকে **`android`** ফোল্ডারটি সিলেক্ট করে **OK** দিন।

### ধাপ ২: Gradle Sync হতে দিন
- Android Studio প্রোজেক্ট ওপেন করার সাথে সাথে প্রয়োজনীয় Gradle প্লাগইন এবং ডিপেন্ডেন্সি ডাউনলোড ও সিঙ্ক করবে। নিচে প্রগ্রেস বার শেষ হওয়া পর্যন্ত কয়েক সেকেন্ড অপেক্ষা করুন।

### ধাপ ৩: APK বিল্ড করুন (Build APK)
1. Android Studio-এর উপরের মেনু থেকে **Build** এ ক্লিক করুন।
2. **Build Bundle(s) / APK(s)** এ মাউস নিন।
3. **Build APK(s)** এ ক্লিক করুন।

### ধাপ ৪: APK ফাইলটি সংগ্রহ করুন
- বিল্ড সম্পন্ন হলে নিচের ডান কোণায় একটি নোটিফিকেশন আসবে: **"APK(s) generated successfully"** এবং পাশে **locate** বাটন থাকবে।
- অথবা সরাসরি আপনার ফাইলের এই লোকেশনে APK পাবেন:
  ```
  android/app/build/outputs/apk/debug/app-debug.apk
  ```
- এই `app-debug.apk` ফাইলটি আপনার যেকোনো অ্যান্ড্রয়েড ফোনে ইনস্টল করে ব্যবহার করতে পারবেন!

---

## 🛠️ ওয়েব কোডে কোনো পরিবর্তন করলে কিভাবে Android Studio-তে আপডেট করবেন?

যদি আপনি ওয়েব কোডে বা ডিজাইনে কোনো পরিবর্তন করেন, তবে টার্মিনালে এই কমান্ডটি চালান:

```bash
npm run build:android
```

এই কমান্ডটি:
1. Vite দিয়ে প্রোডাকশন ওয়েব কোড বানাবে (`npm run build`).
2. স্বয়ংক্রিয়ভাবে Android Studio-এর `android/app/src/main/assets/public` ফোল্ডারে লেটেস্ট কোড সিঙ্ক করবে (`npx cap sync android`).

এরপর Android Studio-তে গিয়ে শুধু আবার **Build > Build APK(s)** দিলেই নতুন APK তৈরি হয়ে যাবে!

---

## 🔔 ব্যাকগ্রাউন্ড নোটিফিকেশন ও অডিও সাউন্ড (Background Notifications & Sound)
- **কাস্টম অডিও সাউন্ড:** নোটিফিকেশনের মিষ্টি ক্রিস্টাল বেল সাউন্ডটি অ্যান্ড্রয়েডের নেটিভ রুট ডিরেক্টরিতে কনফিগার করা হয়েছে: `android/app/src/main/res/raw/notification.wav`।
- **অ্যাপ বন্ধ থাকলেও নোটিফিকেশন (Killed/Closed App Support):** 
  - অ্যাপটি চালু না থাকলেও বা ব্যাকগ্রাউন্ড থেকে সরিয়ে দিলেও অ্যান্ড্রয়েডের নেটিভ `AlarmManager` ও `SCHEDULE_EXACT_ALARM` পারমিশনের মাধ্যমে নির্ধারিত সময় অনুযায়ী নোটিফিকেশন পৌঁছাবে।
  - ডিভাইস ডুয়াল স্লিপ বা ব্যাটারি সেভার মোডে থাকলেও `allowWhileIdle` ফ্ল্যাগ নোটিফিকেশন বাজিয়ে তুলবে।
  - মোবাইল রিস্টার্ট হলে `RECEIVE_BOOT_COMPLETED` এর মাধ্যমে অ্যালার্মগুলো স্বয়ংক্রিয়ভাবে পুনরায় সেট হয়ে যাবে।

---

## 📱 প্রজেক্ট কনফিগারেশন তথ্য
- **App Name:** Habit Tracker
- **Package ID:** `com.habittracker.app`
- **Minimum Android SDK:** 22 (Android 5.1+)
- **Target Android SDK:** 34+ (Latest Android)
- **Offline Support:** সম্পূর্ণ অফলাইন সমর্থন (Local Storage & IndexedDB)
- **Platform:** Capacitor 6 / 7 + Native Android Studio Wrapper
