package com.habittracker.app;

import android.app.AlarmManager;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.media.AudioAttributes;
import android.net.Uri;
import android.os.Build;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONObject;

import androidx.core.app.NotificationManagerCompat;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;
import java.util.TimeZone;

/**
 * Stores one repeating reminder rule per habit and keeps a single pending
 * "alarm clock" alarm for each of them. When an alarm fires, ReminderReceiver
 * asks this class to schedule that habit's next occurrence, so reminders keep
 * arriving every day without the app ever being opened again.
 *
 * One alarm per habit also keeps the app far below Android's pending-alarm
 * limit, which is what silently dropped reminders for later habits before.
 */
final class ReminderScheduler {

    /** Filter Logcat with: adb logcat -s ReminderScheduler ReminderReceiver */
    static final String TAG = "ReminderScheduler";
    static final String ACTION_REMINDER = "com.habittracker.app.ACTION_HABIT_REMINDER";
    static final String CHANNEL_ID = "habit_reminders_alarm";
    static final String CHANNEL_ID_QUIET = "habit_reminders_alarm_quiet";
    static final long[] VIBRATION_PATTERN = new long[] {0, 350, 200, 350};

    private static final String PREFS = "habit_reminders";
    private static final String KEY_RULES = "rules";
    // Legacy key used by v21 builds that stored a dated alarm for each reminder.
    private static final String KEY_ITEMS = "items";
    private static final String KEY_VIBRATE = "vibrate";

    /** How far ahead to look for a habit's next matching day. */
    private static final int SEARCH_DAYS = 8;

    /** Slack used right after a reminder fired, so the same day is not scheduled twice. */
    private static final long NEXT_OCCURRENCE_SLACK_MS = 60000L;

    private ReminderScheduler() {}

    static boolean isVibrationEnabled(Context context) {
        return context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean(KEY_VIBRATE, true);
    }

    static void setVibrationEnabled(Context context, boolean enabled) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean(KEY_VIBRATE, enabled).apply();
    }

    /** Notification channels cannot change vibration later, so there is one channel per mode. */
    static void ensureChannel(Context context) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return;
        NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm == null) return;

        Uri sound = Uri.parse("android.resource://" + context.getPackageName() + "/" + R.raw.notification);
        AudioAttributes attrs = new AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_NOTIFICATION)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build();

        if (nm.getNotificationChannel(CHANNEL_ID) == null) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID, "Habit reminders", NotificationManager.IMPORTANCE_HIGH);
            channel.setDescription("Reminders for your habits");
            channel.enableVibration(true);
            channel.setVibrationPattern(VIBRATION_PATTERN);
            channel.setSound(sound, attrs);
            nm.createNotificationChannel(channel);
        }

        if (nm.getNotificationChannel(CHANNEL_ID_QUIET) == null) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID_QUIET, "Habit reminders (no vibration)", NotificationManager.IMPORTANCE_HIGH);
            channel.setDescription("Reminders for your habits without vibration");
            channel.enableVibration(false);
            channel.setSound(sound, attrs);
            nm.createNotificationChannel(channel);
        }
    }

    /** Replaces every stored habit rule with [{id, habitId, title, body, hour, minute, daily, days}]. */
    static synchronized JSONArray scheduleAll(Context context, JSONArray reminders) {
        Log.i(TAG, "scheduleAll: received " + (reminders == null ? 0 : reminders.length())
                + " habit reminder rule(s), timezone=" + TimeZone.getDefault().getID());
        cancelAll(context);
        if (reminders == null) return new JSONArray();

        // Older bundled JavaScript sends dated entries ({id, title, body, at});
        // the updated bundle sends recurring rules ({id, hour, minute, daily, days}).
        // Accept both formats so building from Android Studio with a stale web bundle
        // cannot silently turn every reminder into an 8:00 AM reminder.
        boolean legacyDatedItems = false;
        if (reminders.length() > 0) {
            JSONObject first = reminders.optJSONObject(0);
            legacyDatedItems = first != null && first.has("at") && !first.has("hour");
        }

        SharedPreferences.Editor editor = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit();
        if (legacyDatedItems) {
            editor.putString(KEY_ITEMS, reminders.toString()).putString(KEY_RULES, "[]");
        } else {
            // Assign native alarm IDs from habit identity and enforce uniqueness here as
            // well as in JavaScript. This keeps every habit's PendingIntent independent.
            JSONArray normalized = normalizeRuleIds(reminders);
            editor.putString(KEY_RULES, normalized.toString()).putString(KEY_ITEMS, "[]");
        }
        editor.apply();
        return scheduleStored(context);
    }

    /**
     * Make each native reminder ID stable for a habit and unique in the full sync batch.
     * PendingIntent extras do not form part of identity, so the request code must be unique.
     */
    private static JSONArray normalizeRuleIds(JSONArray reminders) {
        JSONArray normalized = new JSONArray();
        Set<Integer> usedIds = new HashSet<>();
        if (reminders == null) return normalized;

        for (int i = 0; i < reminders.length(); i++) {
            JSONObject original = reminders.optJSONObject(i);
            if (original == null) continue;
            try {
                JSONObject rule = new JSONObject(original.toString());
                String habitId = rule.optString("habitId", "");
                int candidate = !habitId.isEmpty()
                        ? (habitId.hashCode() & 0x7fffffff)
                        : (rule.optInt("id", i + 1) & 0x7fffffff);
                if (candidate == 0) candidate = i + 1;
                while (!usedIds.add(candidate)) {
                    candidate = candidate >= Integer.MAX_VALUE ? 1 : candidate + 1;
                }
                rule.put("id", candidate);
                normalized.put(rule);
            } catch (Exception error) {
                Log.w(TAG, "Skipping invalid reminder rule at index " + i, error);
            }
        }
        return normalized;
    }

    /**
     * Schedules the next occurrence of every stored habit (used on start-up, after a reboot,
     * an app update, a clock change or a time-zone change). Returns one entry per armed alarm.
     */
    static synchronized JSONArray scheduleStored(Context context) {
        ensureChannel(context);
        JSONArray report = new JSONArray();
        JSONArray rules = storedRules(context);
        if (rules.length() == 0) {
            // Also restores the pending dated alarms from older app versions after reboot/update.
            scheduleLegacyStored(context);
            return report;
        }
        int scheduledCount = 0;
        long now = System.currentTimeMillis();
        for (int i = 0; i < rules.length(); i++) {
            // A malformed rule must not prevent the other habits from being scheduled.
            // Do not subtract a grace window here: it could re-fire a reminder that just fired
            // when the app syncs again within the next minute.
            try {
                JSONObject rule = rules.getJSONObject(i);
                long at = scheduleRule(context, rule, now);
                if (at > 0) {
                    scheduledCount++;
                    JSONObject item = new JSONObject();
                    item.put("habitId", rule.optString("habitId", ""));
                    item.put("alarmId", rule.getInt("id"));
                    item.put("at", at);
                    item.put("atLocal", formatTime(at));
                    report.put(item);
                }
            } catch (Exception ruleError) {
                Log.w(TAG, "Skipping invalid habit reminder at index " + i, ruleError);
            }
        }
        Log.i(TAG, "Scheduled " + scheduledCount + " of " + rules.length() + " habit reminders"
                + " (notificationsAllowed=" + areNotificationsAllowed(context)
                + ", exactAlarmAllowed=" + canScheduleExact(context)
                + ", timezone=" + TimeZone.getDefault().getID() + ")");
        return report;
    }

    /** Queues the following occurrence of one habit right after its reminder fired. */
    static synchronized void scheduleNext(Context context, int ruleId) {
        JSONArray rules = storedRules(context);
        for (int i = 0; i < rules.length(); i++) {
            try {
                JSONObject rule = rules.getJSONObject(i);
                if (rule.getInt("id") == ruleId) {
                    scheduleRule(context, rule, System.currentTimeMillis() + NEXT_OCCURRENCE_SLACK_MS);
                    return;
                }
            } catch (Exception ignored) {
                // Malformed entry: nothing to reschedule for it.
            }
        }
    }

    static synchronized void cancelAll(Context context) {
        AlarmManager am = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        JSONArray rules = storedRules(context);
        Log.i(TAG, "cancelAll: cancelling " + rules.length() + " stored habit alarm(s) before re-arming");
        for (int i = 0; i < rules.length(); i++) {
            try {
                int id = rules.getJSONObject(i).getInt("id");
                PendingIntent pi = alarmIntent(context, id, null, null, null, PendingIntent.FLAG_NO_CREATE);
                if (pi != null) {
                    if (am != null) am.cancel(pi);
                    pi.cancel();
                }
            } catch (Exception ignored) {
                // Corrupt entry: nothing to cancel for it.
            }
        }
        // Cancel all dated alarms created by v21 and earlier before replacing their schedule.
        JSONArray legacyItems = storedLegacyItems(context);
        for (int i = 0; i < legacyItems.length(); i++) {
            try {
                int id = legacyItems.getJSONObject(i).getInt("id");
                PendingIntent pi = alarmIntent(context, id, null, null, null, PendingIntent.FLAG_NO_CREATE);
                if (pi != null) {
                    if (am != null) am.cancel(pi);
                    pi.cancel();
                }
            } catch (Exception ignored) {
                // Keep cancellation resilient if a legacy entry is malformed.
            }
        }
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
                .putString(KEY_RULES, "[]")
                .putString(KEY_ITEMS, "[]")
                .apply();
    }

    /** Re-schedules the old dated-item format only until the updated web bundle syncs new rules. */
    private static void scheduleLegacyStored(Context context) {
        AlarmManager am = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (am == null) return;
        JSONArray items = storedLegacyItems(context);
        long now = System.currentTimeMillis();
        int scheduledCount = 0;
        for (int i = 0; i < items.length(); i++) {
            try {
                JSONObject item = items.getJSONObject(i);
                long at = item.getLong("at");
                if (at <= now) continue;
                int id = item.getInt("id");
                PendingIntent pi = alarmIntent(context, id, item.optString("title"), item.optString("body"),
                        null, PendingIntent.FLAG_UPDATE_CURRENT);
                Intent open = new Intent(context, MainActivity.class);
                open.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
                PendingIntent show = PendingIntent.getActivity(context, id, open,
                        PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
                try {
                    am.setAlarmClock(new AlarmManager.AlarmClockInfo(at, show), pi);
                } catch (Exception exactError) {
                    Log.w(TAG, "Legacy exact alarm refused; falling back to inexact", exactError);
                    am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi);
                }
                scheduledCount++;
            } catch (Exception itemError) {
                Log.w(TAG, "Skipping invalid legacy reminder at index " + i, itemError);
            }
        }
        Log.i(TAG, "Restored " + scheduledCount + " legacy dated reminders");
    }

    private static JSONArray storedLegacyItems(Context context) {
        String stored = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY_ITEMS, "[]");
        try {
            return new JSONArray(stored);
        } catch (Exception error) {
            return new JSONArray();
        }
    }

    /** Arms one habit's alarm. Returns the trigger time in ms, or -1 if no alarm could be armed. */
    private static long scheduleRule(Context context, JSONObject rule, long notBefore) throws Exception {
        int id = rule.getInt("id");
        String habitId = rule.optString("habitId", "");
        long at = nextOccurrence(rule, notBefore);

        PendingIntent pi = alarmIntent(
                context, id,
                rule.optString("title", "Habit reminder"),
                rule.optString("body", ""),
                habitId,
                PendingIntent.FLAG_UPDATE_CURRENT);

        AlarmManager am = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (am == null) {
            Log.e(TAG, "AlarmManager unavailable; habitId=" + habitId + " NOT scheduled");
            return -1;
        }

        Intent open = new Intent(context, MainActivity.class);
        open.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent show = PendingIntent.getActivity(
                context, id, open, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        String mode;
        try {
            // "Alarm clock" alarms survive battery saver and Doze, like the Clock app's alarms.
            am.setAlarmClock(new AlarmManager.AlarmClockInfo(at, show), pi);
            mode = "alarmClock";
        } catch (Exception exactError) {
            // Some devices refuse exact alarms; an inexact alarm still reaches the user.
            Log.w(TAG, "Exact alarm refused for habitId=" + habitId + ", falling back to an inexact alarm", exactError);
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi);
            mode = "inexact";
        }
        Log.i(TAG, "SCHEDULED habitId=" + habitId + " alarmId=" + id
                + " rule=" + String.format(Locale.US, "%02d:%02d", rule.optInt("hour", 8), rule.optInt("minute", 0))
                + (rule.optBoolean("daily", true) ? " daily" : " days=" + rule.optJSONArray("days"))
                + " -> " + formatTime(at) + " mode=" + mode);
        return at;
    }

    /** Local, human-readable time including the offset and zone, e.g. 2026-10-11 20:00:00 +0600 (BDT). */
    static String formatTime(long millis) {
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss Z '('z')'", Locale.US);
        format.setTimeZone(TimeZone.getDefault());
        return format.format(new Date(millis));
    }

    static boolean areNotificationsAllowed(Context context) {
        try {
            return NotificationManagerCompat.from(context).areNotificationsEnabled();
        } catch (Exception error) {
            return true;
        }
    }

    /** Only informational: alarm-clock alarms do not need the exact-alarm permission. */
    static boolean canScheduleExact(Context context) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) return true;
        AlarmManager am = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        return am != null && am.canScheduleExactAlarms();
    }

    /** One entry per stored habit rule: is its alarm armed, and when should it fire next? */
    static synchronized JSONArray debugState(Context context) {
        JSONArray out = new JSONArray();
        JSONArray rules = storedRules(context);
        long now = System.currentTimeMillis();
        for (int i = 0; i < rules.length(); i++) {
            try {
                JSONObject rule = rules.getJSONObject(i);
                int id = rule.getInt("id");
                PendingIntent existing = alarmIntent(context, id, null, null, null, PendingIntent.FLAG_NO_CREATE);
                long next = nextOccurrence(rule, now);
                JSONObject item = new JSONObject();
                item.put("habitId", rule.optString("habitId", ""));
                item.put("alarmId", id);
                item.put("time", String.format(Locale.US, "%02d:%02d", rule.optInt("hour", 8), rule.optInt("minute", 0)));
                item.put("daily", rule.optBoolean("daily", true));
                item.put("alarmArmed", existing != null);
                item.put("nextAtLocal", formatTime(next));
                out.put(item);
            } catch (Exception ignored) {
                // Skip a malformed rule in the diagnostic dump.
            }
        }
        return out;
    }

    private static PendingIntent alarmIntent(
            Context context, int id, String title, String body, String habitId, int flags) {
        Intent intent = new Intent(context, ReminderReceiver.class);
        intent.setAction(ACTION_REMINDER);
        intent.putExtra("id", id);
        if (title != null) intent.putExtra("title", title);
        if (body != null) intent.putExtra("body", body);
        if (habitId != null) intent.putExtra("habitId", habitId);
        return PendingIntent.getBroadcast(context, id, intent, flags | PendingIntent.FLAG_IMMUTABLE);
    }

    /** The next moment (ms) at which this habit's reminder should fire, at or after {@code notBefore}. */
    private static long nextOccurrence(JSONObject rule, long notBefore) {
        int hour = rule.optInt("hour", 8);
        int minute = rule.optInt("minute", 0);
        boolean daily = rule.optBoolean("daily", true);
        JSONArray days = rule.optJSONArray("days");

        Calendar calendar = Calendar.getInstance();
        for (int offset = 0; offset <= SEARCH_DAYS; offset++) {
            calendar.setTimeInMillis(notBefore);
            calendar.add(Calendar.DAY_OF_YEAR, offset);
            calendar.set(Calendar.HOUR_OF_DAY, hour);
            calendar.set(Calendar.MINUTE, minute);
            calendar.set(Calendar.SECOND, 0);
            calendar.set(Calendar.MILLISECOND, 0);

            long at = calendar.getTimeInMillis();
            if (at < notBefore) continue;
            // Calendar.DAY_OF_WEEK is 1 = Sunday; the app stores 0 = Sunday.
            if (!daily && !containsDay(days, calendar.get(Calendar.DAY_OF_WEEK) - 1)) continue;
            return at;
        }
        return notBefore + 24L * 60L * 60L * 1000L;
    }

    private static boolean containsDay(JSONArray days, int day) {
        if (days == null) return false;
        for (int i = 0; i < days.length(); i++) {
            if (days.optInt(i, -1) == day) return true;
        }
        return false;
    }

    private static JSONArray storedRules(Context context) {
        String stored = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY_RULES, "[]");
        try {
            return new JSONArray(stored);
        } catch (Exception error) {
            return new JSONArray();
        }
    }
}