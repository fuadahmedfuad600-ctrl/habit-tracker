package com.habittracker.app;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.PowerManager;
import android.provider.Settings;

import com.getcapacitor.JSArray;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;

import org.json.JSONArray;
import com.getcapacitor.annotation.CapacitorPlugin;

/** Helps reminders keep working while the app is closed (battery optimisation settings). */
@CapacitorPlugin(name = "ReminderSettings")
public class ReminderSettingsPlugin extends Plugin {

    @PluginMethod
    public void isBatteryOptimizationIgnored(PluginCall call) {
        boolean ignored = true;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            PowerManager pm = (PowerManager) getContext().getSystemService(Context.POWER_SERVICE);
            ignored = pm != null && pm.isIgnoringBatteryOptimizations(getContext().getPackageName());
        }
        JSObject result = new JSObject();
        result.put("ignored", ignored);
        call.resolve(result);
    }

    @PluginMethod
    public void requestIgnoreBatteryOptimization(PluginCall call) {
        try {
            Intent intent = new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS);
            intent.setData(Uri.parse("package:" + getContext().getPackageName()));
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            getContext().startActivity(intent);
        } catch (Exception first) {
            try {
                Intent fallback = new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS);
                fallback.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                getContext().startActivity(fallback);
            } catch (Exception second) {
                openSettingsInternal();
            }
        }
        call.resolve();
    }

    @PluginMethod
    public void scheduleReminders(PluginCall call) {
        JSArray reminders = call.getArray("reminders");
        JSONArray report = ReminderScheduler.scheduleAll(getContext(), reminders);
        JSObject result = new JSObject();
        result.put("scheduled", report.length());
        result.put("alarms", report);
        result.put("notificationsAllowed", ReminderScheduler.areNotificationsAllowed(getContext()));
        result.put("exactAlarmAllowed", ReminderScheduler.canScheduleExact(getContext()));
        call.resolve(result);
    }

    /** Diagnostic: which habit alarms are armed right now and when each fires next. */
    @PluginMethod
    public void getScheduleDebug(PluginCall call) {
        JSObject result = new JSObject();
        result.put("alarms", ReminderScheduler.debugState(getContext()));
        result.put("notificationsAllowed", ReminderScheduler.areNotificationsAllowed(getContext()));
        result.put("exactAlarmAllowed", ReminderScheduler.canScheduleExact(getContext()));
        call.resolve(result);
    }


    @PluginMethod
    public void getFiredReminders(PluginCall call) {
        String stored = getContext().getSharedPreferences("habit_reminders", Context.MODE_PRIVATE)
                .getString("fired_history", "[]");
        JSObject result = new JSObject();
        try {
            result.put("reminders", new JSONArray(stored));
        } catch (Exception error) {
            result.put("reminders", new JSArray());
        }
        call.resolve(result);
    }

    @PluginMethod
    public void setVibrationEnabled(PluginCall call) {
        boolean enabled = Boolean.TRUE.equals(call.getBoolean("enabled", true));
        ReminderScheduler.setVibrationEnabled(getContext(), enabled);
        call.resolve();
    }

    @PluginMethod
    public void cancelReminders(PluginCall call) {
        ReminderScheduler.cancelAll(getContext());
        call.resolve();
    }

    @PluginMethod
    public void openAppSettings(PluginCall call) {
        openSettingsInternal();
        call.resolve();
    }

    private void openSettingsInternal() {
        try {
            Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
            intent.setData(Uri.parse("package:" + getContext().getPackageName()));
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            getContext().startActivity(intent);
        } catch (Exception ignored) {
            // Nothing else to try.
        }
    }
}
