package com.habittracker.app;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.service.notification.StatusBarNotification;
import android.util.Log;

import androidx.core.app.NotificationCompat;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.TimeZone;

public class ReminderReceiver extends BroadcastReceiver {

    private static final String TAG = "ReminderReceiver";

    /** System events after which every pending alarm must be rebuilt from the stored habits. */
    private static boolean isRescheduleAction(String action) {
        return Intent.ACTION_BOOT_COMPLETED.equals(action)
                || Intent.ACTION_MY_PACKAGE_REPLACED.equals(action)
                // Some OEMs (Xiaomi/HyperOS, HTC) send these instead of / in addition to BOOT_COMPLETED.
                || "android.intent.action.QUICKBOOT_POWERON".equals(action)
                || "com.htc.intent.action.QUICKBOOT_POWERON".equals(action)
                // Alarms are stored as absolute times, so a clock or time-zone change shifts them.
                || Intent.ACTION_TIME_CHANGED.equals(action)
                || Intent.ACTION_TIMEZONE_CHANGED.equals(action)
                // The user granted/revoked the "alarms & reminders" special access.
                || "android.app.action.SCHEDULE_EXACT_ALARM_PERMISSION_STATE_CHANGED".equals(action);
    }

    @Override
    public void onReceive(Context context, Intent intent) {
        String action = intent == null ? null : intent.getAction();
        if (action == null) return;

        // Pending alarms do not survive a reboot or an app update, so rebuild them from the stored habits.
        if (isRescheduleAction(action)) {
            Log.i(TAG, "System event " + action + " -> rebuilding every habit alarm");
            try {
                // Make sure the JVM uses the zone the phone is in now, not the one cached earlier.
                if (Intent.ACTION_TIMEZONE_CHANGED.equals(action)) TimeZone.setDefault(null);
                ReminderScheduler.scheduleStored(context);
            } catch (Exception error) {
                Log.e(TAG, "Could not rebuild habit alarms after " + action, error);
            }
            return;
        }

        if (!ReminderScheduler.ACTION_REMINDER.equals(action)) return;

        int id = intent.getIntExtra("id", 0);
        String title = intent.getStringExtra("title");
        String body = intent.getStringExtra("body");
        String habitId = intent.getStringExtra("habitId");
        Log.i(TAG, "TRIGGER habitId=" + habitId + " alarmId=" + id
                + " firedAt=" + ReminderScheduler.formatTime(System.currentTimeMillis()));

        // 1) Queue this habit's next occurrence FIRST. If anything below fails, the habit still
        //    keeps repeating on later days instead of silently stopping after one reminder.
        try {
            ReminderScheduler.scheduleNext(context, id);
        } catch (Exception error) {
            Log.e(TAG, "Could not schedule the next occurrence for habitId=" + habitId, error);
        }

        // 2) Show this habit's own notification (its own notification ID, so habits never replace each other).
        try {
            ReminderScheduler.ensureChannel(context);
            rememberFiredReminder(context, id, habitId, title, body);
            showNotification(context, id, habitId, title, body);
        } catch (Exception error) {
            Log.e(TAG, "NOTIFY FAILED habitId=" + habitId + " notificationId=" + id, error);
        }
    }

    private static void showNotification(Context context, int id, String habitId, String title, String body) {
        Intent open = new Intent(context, MainActivity.class);
        open.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent contentIntent = PendingIntent.getActivity(
                context, id, open, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        boolean vibrate = ReminderScheduler.isVibrationEnabled(context);
        String channelId = vibrate ? ReminderScheduler.CHANNEL_ID : ReminderScheduler.CHANNEL_ID_QUIET;
        String safeBody = body == null ? "" : body;

        NotificationCompat.Builder builder = new NotificationCompat.Builder(context, channelId)
                .setSmallIcon(R.drawable.ic_stat_habit)
                .setColor(0xFF2878F0)
                .setContentTitle(title == null ? "Habit reminder" : title)
                .setContentText(safeBody)
                .setStyle(new NotificationCompat.BigTextStyle().bigText(safeBody))
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setCategory(NotificationCompat.CATEGORY_REMINDER)
                .setAutoCancel(true)
                .setVibrate(vibrate ? ReminderScheduler.VIBRATION_PATTERN : new long[] {0})
                .setContentIntent(contentIntent);

        NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm == null) {
            Log.e(TAG, "NOTIFY FAILED habitId=" + habitId + ": NotificationManager unavailable");
            return;
        }

        boolean allowed = ReminderScheduler.areNotificationsAllowed(context);
        int channelImportance = -1;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = nm.getNotificationChannel(channelId);
            if (channel != null) channelImportance = channel.getImportance();
        }

        nm.notify(id, builder.build());

        boolean shown = false;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            try {
                for (StatusBarNotification active : nm.getActiveNotifications()) {
                    if (active.getId() == id) {
                        shown = true;
                        break;
                    }
                }
            } catch (Exception ignored) {
                // Some OEM builds refuse to list notifications; the other fields are still useful.
            }
        }
        Log.i(TAG, "NOTIFY habitId=" + habitId + " notificationId=" + id
                + " appNotificationsAllowed=" + allowed
                + " channel=" + channelId + " channelImportance=" + channelImportance
                + " showingInTray=" + shown);
        if (!allowed) {
            Log.w(TAG, "Android is blocking this app's notifications (Settings > Apps > Habit Tracker > Notifications).");
        }
    }

    private static void rememberFiredReminder(Context context, int id, String habitId, String title, String body) {
        final String prefsName = "habit_reminders";
        final String historyKey = "fired_history";
        SharedPreferences preferences = context.getSharedPreferences(prefsName, Context.MODE_PRIVATE);
        JSONArray history;
        try {
            history = new JSONArray(preferences.getString(historyKey, "[]"));
        } catch (Exception ignored) {
            history = new JSONArray();
        }
        JSONObject item = new JSONObject();
        try {
            item.put("id", id);
            item.put("habitId", habitId == null ? "" : habitId);
            item.put("title", title == null ? "Habit reminder" : title);
            item.put("body", body == null ? "" : body);
            item.put("timestamp", System.currentTimeMillis());
            history.put(item);
            while (history.length() > 50) history.remove(0);
            preferences.edit().putString(historyKey, history.toString()).apply();
        } catch (Exception error) {
            android.util.Log.w("ReminderReceiver", "Could not persist reminder history", error);
        }
    }
}
