package com.habittracker.app;

import android.graphics.Color;
import android.os.Bundle;

import androidx.core.view.WindowCompat;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        registerPlugin(ReminderSettingsPlugin.class);
        super.onCreate(savedInstanceState);

        // Edge-to-edge (fullscreen) layout. Capacitor's built-in SystemBars plugin
        // measures the status/navigation bars and exposes them to the web UI
        // (env(safe-area-inset-*) and --safe-area-inset-* CSS variables).
        WindowCompat.setDecorFitsSystemWindows(getWindow(), false);
        getWindow().setStatusBarColor(Color.TRANSPARENT);
        getWindow().setNavigationBarColor(Color.TRANSPARENT);
    }
}
